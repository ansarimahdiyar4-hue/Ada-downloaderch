package com.bepar.vpn.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Small local connection history; it never stores server credentials or traffic contents. */
data class ConnectionLogEntry(
    val timestamp: Long,
    val phase: String,
    val message: String
)

object ConnectionLogStore {
    private const val PREFS = "bepar_connection_history"
    private const val KEY_ENTRIES = "entries_v1"
    private const val MAX_ENTRIES = 60

    @Synchronized
    fun load(context: Context): List<ConnectionLogEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY_ENTRIES, null) ?: return emptyList()
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val timestamp = item.optLong("timestamp", 0L)
                    val phase = item.optString("phase")
                    val storedMessage = item.optString("message")
                    val message = when (phase) {
                        "CONNECTED" -> "VPN connected"
                        "CONNECTING" -> "Connecting to server"
                        "RECONNECTING" -> "Reconnecting"
                        "DISCONNECTED" -> "VPN disconnected"
                        else -> storedMessage.take(180)
                    }
                    if (timestamp > 0L && phase.isNotBlank()) {
                        add(ConnectionLogEntry(timestamp, phase, message))
                    }
                }
            }.sortedByDescending { it.timestamp }
        }.getOrDefault(emptyList())
    }

    @Synchronized
    fun record(context: Context, phase: String, message: String) {
        val cleanMessage = message.trim().take(180)
        val existing = load(context)
        val latest = existing.firstOrNull()
        if (latest != null && latest.phase == phase && latest.message == cleanMessage &&
            System.currentTimeMillis() - latest.timestamp < 5_000L
        ) return

        val updated = (listOf(ConnectionLogEntry(System.currentTimeMillis(), phase, cleanMessage)) + existing)
            .take(MAX_ENTRIES)
        val array = JSONArray()
        updated.forEach { entry ->
            array.put(
                JSONObject()
                    .put("timestamp", entry.timestamp)
                    .put("phase", entry.phase)
                    .put("message", entry.message)
            )
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_ENTRIES, array.toString()).apply()
    }

    @Synchronized
    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY_ENTRIES).apply()
    }
}
