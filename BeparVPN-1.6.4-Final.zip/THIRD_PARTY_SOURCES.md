# Bepar VPN automatic server sources

The Android Auto mode imports server configuration links from four public GitHub projects:

1. [0xRadikal / Free-v2ray-Configs](https://github.com/0xRadikal/Free-v2ray-Configs) — MIT; verified configs feed.
2. [MustafaBaqer / VestraNet-Nodes](https://github.com/MustafaBaqer/VestraNet-Nodes) — MIT; mixed Xray/V2Ray subscription feed.
3. [barry-far / V2ray-Config](https://github.com/barry-far/V2ray-Config) — MIT; aggregated subscription feed.
4. [MatinGhanbari / v2ray-configs](https://github.com/MatinGhanbari/v2ray-configs) — MIT; curated `super-sub` feed.

Feeds are fetched over HTTPS from `raw.githubusercontent.com` first, with an HTTPS jsDelivr mirror as fallback for networks where GitHub Raw is unreachable. Mirror caches can lag behind the source repository. Profiles are converted locally to Xray outbounds. Invalid entries are discarded; duplicate outbounds from successful feeds are collapsed; failed feeds keep their last cached profiles. Public feeds are mostly dead servers, so each refresh converts a random sample of up to 200 profiles per source (plus the servers kept last time), TCP-probes them on the physical network, re-tests the fastest ones a second time, and stores only the live servers with the lowest connect time: 10 per source by default (5/10/15/20 in Settings, with an optional max-ping limit).

## Refresh timing

All four selected repositories describe a 15-minute update cadence. Bepar VPN checks them every 15 minutes using WorkManager and a connected-network constraint. Android may defer a run because of Doze, battery optimization, network availability, or vendor background restrictions. Therefore this is a **15-minute minimum target, not an exact timer**. Auto connect also refreshes when the saved feed snapshot is older than 15 minutes.

## Selection and diagnostics

Auto mode samples up to 80 saved profiles across the source groups and measures TCP connection latency on the available non-VPN network; the five or six fastest are then started one by one and verified with a real HTTPS request through the tunnel. This is a TCP connect-time estimate, not ICMP ping and not an end-to-end Xray handshake test. UDP-only transports are not ranked by the TCP probe. The Logs screen can run a separate, bounded 1 MB HTTPS download sample through the active tunnel; it is an indicative download estimate only, not a full upload/download benchmark and not a per-server speed ranking.

## Privacy and trust

Server links are public third-party configuration data. Profiles are stored locally encrypted with Android Keystore AES-GCM, and feed downloads use HTTPS. This does not make a third-party VPN operator trustworthy: operators may observe connection metadata and traffic not protected end-to-end by the destination application protocol. Do not use unknown public servers for banking, passwords, or sensitive accounts. Country names shown in the app are taken from source-provided flag labels when available; they are not an independently verified IP-geolocation result. The app does not send server IP addresses to a third-party geolocation API. When the primary host is unavailable, the jsDelivr CDN is contacted as the configured mirror; that CDN also receives the request IP and basic request metadata.
