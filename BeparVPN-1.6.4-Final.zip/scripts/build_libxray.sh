#!/usr/bin/env bash
# Build the Android AAR with the official XTLS/libXray build script.
# Requirements: git, Python 3, Go, Android SDK/NDK, Java, and a working Android toolchain.
set -Eeuo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
LIBXRAY_REF="${LIBXRAY_REF:-v26.10.31}"
WORK_DIR="$(mktemp -d)"
cleanup() { rm -rf "$WORK_DIR"; }
trap cleanup EXIT

if ! command -v git >/dev/null 2>&1; then echo "git is required" >&2; exit 1; fi
if ! command -v python3 >/dev/null 2>&1; then echo "Python 3 is required" >&2; exit 1; fi
ANDROID_SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
if [[ -z "$ANDROID_SDK_ROOT" ]]; then
  echo "Set ANDROID_HOME or ANDROID_SDK_ROOT before building libXray." >&2
  exit 1
fi
export ANDROID_HOME="$ANDROID_SDK_ROOT"
if [[ -z "${ANDROID_NDK_HOME:-}" && -d "$ANDROID_SDK_ROOT/ndk" ]]; then
  NDK_DIR="$(find "$ANDROID_SDK_ROOT/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"
  if [[ -n "$NDK_DIR" ]]; then export ANDROID_NDK_HOME="$NDK_DIR"; fi
fi
if [[ -z "${ANDROID_NDK_HOME:-}" || ! -d "$ANDROID_NDK_HOME" ]]; then
  echo "Install an Android NDK and set ANDROID_NDK_HOME (or install it under $ANDROID_SDK_ROOT/ndk)." >&2
  exit 1
fi

echo "Cloning official XTLS/libXray at ${LIBXRAY_REF}..."
git clone --depth 1 --branch "$LIBXRAY_REF" https://github.com/XTLS/libXray.git "$WORK_DIR/libXray"

# The upstream project explicitly recommends its own builder over a custom gomobile command.
echo "Building Android libXray AAR with the upstream build script..."
(
  cd "$WORK_DIR/libXray"
  python3 build/main.py android
)

AAR_PATH="$WORK_DIR/libXray/libXray.aar"
if [[ ! -s "$AAR_PATH" ]]; then
  echo "The upstream build completed without the expected libXray.aar output." >&2
  exit 1
fi

mkdir -p "$ROOT_DIR/app/libs"
install -m 0644 "$AAR_PATH" "$ROOT_DIR/app/libs/libXray.aar"
echo "AAR installed at app/libs/libXray.aar"
