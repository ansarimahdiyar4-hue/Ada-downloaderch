package com.bepar.vpn.core

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.URL

/** Xray's local expvar counters. These measure traffic forwarded by the proxy outbound. */
data class XrayTrafficSnapshot(
    val uploadBytes: Long,
    val downloadBytes: Long
)

object XrayMetricsReader {
    /** Ask libXray for an unused localhost TCP port before the core starts. */
    fun allocatePort(): Int {
        val fromLibXray = runCatching {
            val response = XrayApi.invoke("getFreePorts", JSONObject().put("count", 1))
            val ports = response.optJSONObject("data")?.optJSONArray("ports")
                ?: throw IllegalStateException("libXray did not return an available metrics port.")
            ports.optInt(0).takeIf { it in 1024..65535 }
                ?: throw IllegalStateException("libXray returned an invalid metrics port.")
        }.getOrNull()
        if (fromLibXray != null) return fromLibXray

        // Last-resort ephemeral port. Like libXray's helper, this is a short-lived selection,
        // not a reservation; Xray binds it immediately afterwards.
        return ServerSocket(0).use { it.localPort }
    }

    /** Returns null while Xray is starting/stopped or if metrics are not yet available. */
    fun read(port: Int): XrayTrafficSnapshot? {
        if (port !in 1..65535) return null
        var connection: HttpURLConnection? = null
        return try {
            connection = (URL("http://127.0.0.1:$port/debug/vars").openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 450
                readTimeout = 650
                useCaches = false
                setRequestProperty("Connection", "close")
            }
            if (connection.responseCode !in 200..299) return null
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(body)
            val proxy = root.optJSONObject("stats")
                ?.optJSONObject("outbound")
                ?.optJSONObject("proxy") ?: return null
            val upload = proxy.optLong("uplink", -1L)
            val download = proxy.optLong("downlink", -1L)
            if (upload < 0L || download < 0L) null else XrayTrafficSnapshot(upload, download)
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }
}
