package com.bepar.vpn.data

enum class ServerOrigin {
    MANUAL,
    BUILT_IN;

    companion object {
        fun fromStorage(value: String?): ServerOrigin =
            if (value.equals("built_in", ignoreCase = true)) BUILT_IN else MANUAL
    }
}

data class ServerNode(
    val id: String,
    val name: String,
    val protocol: String,
    val host: String,
    /** Xray outbound JSON only. The VPN service wraps it in a complete Xray config. */
    val outboundJson: String,
    /** Values are present only when the provider returns a subscription-userinfo header. */
    val subscriptionTotalBytes: Long? = null,
    val subscriptionUploadBytes: Long? = null,
    val subscriptionDownloadBytes: Long? = null,
    /** Unix epoch seconds, as defined by the subscription-userinfo header. */
    val subscriptionExpireAtSeconds: Long? = null,
    val subscriptionFetchedAtMillis: Long? = null,
    val subscriptionUrl: String? = null,
    /** Real Xray outbound HTTP-probe latency; null means it has not passed a real proxy test. */
    val pingMillis: Long? = null,
    val pingCheckedAtMillis: Long? = null,
    /** Identifies whether the profile was imported by the user or fetched by Bepar feeds. */
    val origin: ServerOrigin = ServerOrigin.MANUAL,
    /** User pin retained across subscription refreshes. */
    val isFavorite: Boolean = false
)
