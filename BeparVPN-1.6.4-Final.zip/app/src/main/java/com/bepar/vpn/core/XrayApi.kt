package com.bepar.vpn.core

import android.util.Base64
import android.net.Network
import libXray.LibXray
import org.json.JSONArray
import org.json.JSONObject
import com.bepar.vpn.data.NodeStore
import com.bepar.vpn.data.ServerNode
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

/** Adapter for the structured API exposed by the official XTLS/libXray Android AAR. */
object XrayApi {
    private const val API_VERSION = 3
    private const val MAX_SUBSCRIPTION_BYTES = 15 * 1024 * 1024
    private const val MAX_HTTPS_REDIRECTS = 4

    fun invoke(method: String, payload: JSONObject = JSONObject()): JSONObject {
        val request = JSONObject()
            .put("apiVersion", API_VERSION)
            .put("method", method)
            .put("payload", payload)

        val rawResponse = try {
            LibXray.invoke(request.toString())
        } catch (error: LinkageError) {
            // UnsatisfiedLinkError / NoClassDefFoundError: the native Xray core is missing or incompatible.
            throw IllegalStateException("Xray core could not be loaded (${error.javaClass.simpleName}). Rebuild the app with libXray.aar.")
        }
        val response = JSONObject(rawResponse)
        if (!response.optBoolean("success", false)) {
            val message = response.optString("error").ifBlank { "Xray operation failed" }
            throw IllegalStateException(message)
        }
        return response
    }

    /**
     * Accepts newline-separated share links, an Xray JSON profile, or an HTTPS
     * subscription URL. Legacy VMess QR-code links are converted locally because
     * current libXray intentionally accepts VMess-AEAD links, not the old format.
     */
    data class ImportResult(
        val nodes: List<ServerNode>,
        val subscriptionInfoAvailable: Boolean
    )

    private data class SubscriptionInfo(
        val totalBytes: Long?,
        val uploadBytes: Long?,
        val downloadBytes: Long?,
        val expireAtSeconds: Long?,
        val fetchedAtMillis: Long,
        val sourceUrl: String?
    )

    private data class SubscriptionFetch(
        val content: String,
        val info: SubscriptionInfo?,
        val sourceUrl: String?
    )


    data class OutboundPingResult(
        val node: ServerNode,
        val success: Boolean,
        val latencyMillis: Long?,
        val error: String? = null
    )

    /**
     * Measures latency through Xray itself (HTTP HEAD via the selected outbound), not a raw TCP
     * handshake to the server port. libXray accepts at most five configs in one pingBatch call.
     * Call only while there is no managed runXray instance active.
     */
    fun pingOutbounds(
        profiles: List<ServerNode>,
        timeoutSeconds: Int = 5,
        onBatchCompleted: ((completed: Int, total: Int) -> Unit)? = null
    ): List<OutboundPingResult> {
        if (profiles.isEmpty()) return emptyList()
        require(timeoutSeconds in 1..20) { "Ping timeout must be between 1 and 20 seconds." }
        val output = ArrayList<OutboundPingResult>(profiles.size)
        val batches = profiles.chunked(5)
        var completed = 0

        for (batch in batches) {
            val configs = JSONArray()
            batch.forEach { node ->
                val outbound = JSONObject(node.outboundJson)
                val config = JSONObject().put("outbounds", JSONArray().put(outbound))
                configs.put(JSONObject().put("xrayJson", config.toString()))
            }

            try {
                val response = invoke(
                    "pingBatch",
                    JSONObject()
                        .put("configs", configs)
                        .put("timeout", timeoutSeconds)
                        .put("url", "https://cp.cloudflare.com/")
                )
                val results = response.optJSONObject("data")?.optJSONArray("results")
                batch.forEachIndexed { index, node ->
                    val item = results?.optJSONObject(index)
                    val success = item?.optBoolean("success", false) == true
                    val delay = item?.optLong("delay", -1L) ?: -1L
                    val validDelay = delay.takeIf { success && it in 0L..9_999L }
                    output += OutboundPingResult(
                        node = node,
                        success = validDelay != null,
                        latencyMillis = validDelay,
                        error = if (validDelay == null) {
                            item?.optString("error")?.takeIf(String::isNotBlank) ?: "Xray outbound probe failed."
                        } else null
                    )
                }
            } catch (error: Exception) {
                batch.forEach { node ->
                    output += OutboundPingResult(
                        node = node,
                        success = false,
                        latencyMillis = null,
                        error = error.message?.take(120) ?: "Xray outbound probe failed."
                    )
                }
            }
            completed += batch.size
            onBatchCompleted?.invoke(completed, profiles.size)
        }
        return output
    }

    fun importNodes(input: String): List<ServerNode> = importConfig(input).nodes

    fun importConfig(
        input: String,
        physicalNetwork: Network? = null,
        maxNodes: Int = 1_500,
        /** Convert a random sample of the lines instead of the first [maxNodes] (large public feeds). */
        shuffle: Boolean = false
    ): ImportResult {
        require(input.isNotBlank()) { "The configuration input is empty." }
        require(maxNodes in 1..5_000) { "Invalid profile import limit." }
        val fetched = resolveSubscription(input.trim(), physicalNetwork)
        val source = normalizeSubscriptionContent(fetched.content)
        require(source.toByteArray(Charsets.UTF_8).size <= MAX_SUBSCRIPTION_BYTES) {
            "The configuration exceeds the 15 MB size limit."
        }

        val trimmedSource = source.trim()
        val isJsonDocument = trimmedSource.startsWith("{") || trimmedSource.startsWith("[")
        val outbounds = if (isJsonDocument) {
            parseJsonOutbounds(trimmedSource)
        } else {
            val lines = source.lineSequence()
                .map { it.trim() }
                .filter { it.isNotEmpty() && !it.startsWith("//") && !it.startsWith("#") }
                .distinct()
                .toList()
                .let { if (shuffle) it.shuffled() else it }
            val converted = mutableListOf<JSONObject>()
            val remaining = mutableListOf<String>()

            for (line in lines) {
                if (line.startsWith("vmess://", ignoreCase = true)) {
                    val oldVmess = tryParseLegacyVmess(line)
                    if (oldVmess != null) {
                        converted += oldVmess
                        if (converted.size >= maxNodes) break
                        continue
                    }
                }
                remaining += line
            }

            if (remaining.isNotEmpty() && converted.size < maxNodes) {
                // Convert in bounded batches. If one malformed/unsupported entry
                // poisons a batch, bisect it until valid entries can still be kept.
                remaining.chunked(32).forEach { batch ->
                    if (converted.size < maxNodes) {
                        appendConvertedBatch(batch, converted, maxNodes)
                    }
                }
            }
            converted.take(maxNodes)
        }

        if (outbounds.isEmpty()) {
            throw IllegalArgumentException(
                "No server was found. Import a VLESS, VMess, Trojan, Shadowsocks, SOCKS or Hysteria2 link, or an Xray JSON file."
            )
        }

        val info = fetched.info
        val nodes = outbounds.mapIndexed { index, outbound ->
            val protocol = outbound.optString("protocol", "xray").ifBlank { "xray" }
            val host = findHost(outbound) ?: ""
            val tag = outbound.optString("tag").trim()
            val display = tag
                .takeIf { it.isNotBlank() && !it.equals("proxy", true) }
                ?: listOf(protocol.uppercase(), host).filter { it.isNotBlank() }.joinToString(" • ")
                    .ifBlank { "Server ${index + 1}" }

            ServerNode(
                id = NodeStore.newId(),
                name = display,
                protocol = protocol,
                host = host,
                outboundJson = outbound.toString(),
                subscriptionTotalBytes = info?.totalBytes,
                subscriptionUploadBytes = info?.uploadBytes,
                subscriptionDownloadBytes = info?.downloadBytes,
                subscriptionExpireAtSeconds = info?.expireAtSeconds,
                subscriptionFetchedAtMillis = info?.fetchedAtMillis,
                subscriptionUrl = fetched.sourceUrl
            )
        }
        return ImportResult(nodes, info != null)
    }

    private fun appendConvertedBatch(
        lines: List<String>,
        output: MutableList<JSONObject>,
        maxNodes: Int
    ) {
        if (lines.isEmpty() || output.size >= maxNodes) return
        try {
            val response = invoke(
                "convertShareLinksToXrayJson",
                JSONObject().put("text", lines.joinToString("\n"))
            )
            val data = response.optJSONObject("data")
                ?: throw IllegalArgumentException("The server converter returned an invalid result.")
            val array = data.optJSONArray("outbounds")
                ?: throw IllegalArgumentException("No compatible server was found in the input.")
            for (index in 0 until array.length()) {
                val outbound = array.optJSONObject(index) ?: continue
                output += outbound
                if (output.size >= maxNodes) break
            }
        } catch (error: Exception) {
            if (lines.size == 1) return
            val middle = lines.size / 2
            appendConvertedBatch(lines.subList(0, middle), output, maxNodes)
            appendConvertedBatch(lines.subList(middle, lines.size), output, maxNodes)
        }
    }

    private fun parseJsonOutbounds(json: String): List<JSONObject> {
        val parsed = org.json.JSONTokener(json).nextValue()
        val candidates = when (parsed) {
            is JSONObject -> {
                val outbounds = parsed.optJSONArray("outbounds")
                when {
                    outbounds != null -> (0 until outbounds.length()).mapNotNull(outbounds::optJSONObject)
                    parsed.optJSONObject("outbound") != null -> listOf(parsed.getJSONObject("outbound"))
                    parsed.has("protocol") && parsed.optJSONObject("settings") != null -> listOf(parsed)
                    else -> emptyList()
                }
            }
            is JSONArray -> (0 until parsed.length()).mapNotNull(parsed::optJSONObject)
            else -> emptyList()
        }

        val builtInProtocols = setOf("freedom", "blackhole", "dns", "loopback", "tun")
        val usable = candidates.filter { outbound ->
            val protocol = outbound.optString("protocol").trim()
            protocol.isNotBlank() && !builtInProtocols.contains(protocol.lowercase())
        }
        require(usable.isNotEmpty()) {
            "The JSON file must contain at least one supported proxy outbound."
        }
        return usable
    }

    private fun resolveSubscription(text: String, physicalNetwork: Network?): SubscriptionFetch {
        if (!text.startsWith("https://", ignoreCase = true) || text.contains('\n')) {
            return SubscriptionFetch(text, null, null)
        }

        var currentUrl = URL(text)
        repeat(MAX_HTTPS_REDIRECTS + 1) { redirectCount ->
            require(currentUrl.protocol.equals("https", ignoreCase = true)) {
                "Subscription URLs must use HTTPS."
            }
            val connection = (physicalNetwork?.openConnection(currentUrl)
                ?: currentUrl.openConnection()) as HttpURLConnection
            try {
                connection.requestMethod = "GET"
                connection.connectTimeout = 12_000
                connection.readTimeout = 18_000
                // Follow redirects manually so a token-bearing subscription URL is
                // never sent to an HTTP destination before the scheme is checked.
                connection.instanceFollowRedirects = false
                connection.setRequestProperty("Accept", "text/plain, application/json, */*")
                connection.setRequestProperty("User-Agent", "BeparVPN-Android/1.6.3")

                val code = connection.responseCode
                if (code in 300..399) {
                    if (redirectCount == MAX_HTTPS_REDIRECTS) {
                        throw IllegalStateException("The subscription redirected too many times.")
                    }
                    val location = connection.getHeaderField("Location")
                        ?: throw IllegalStateException("The subscription returned an invalid redirect.")
                    val redirectUrl = URL(currentUrl, location)
                    require(redirectUrl.protocol.equals("https", ignoreCase = true)) {
                        "A subscription URL must not redirect from HTTPS to HTTP."
                    }
                    currentUrl = redirectUrl
                    return@repeat
                }
                if (code !in 200..299) {
                    throw IllegalStateException("Subscription download failed (HTTP $code).")
                }

                val userInfoHeader = connection.getHeaderField("subscription-userinfo")
                    ?: connection.getHeaderField("Subscription-Userinfo")
                val bytes = connection.inputStream.use { input ->
                    val output = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total = 0
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= MAX_SUBSCRIPTION_BYTES) { "The subscription exceeds the allowed size." }
                        output.write(buffer, 0, count)
                    }
                    output.toByteArray()
                }
                return SubscriptionFetch(
                    content = bytes.toString(Charsets.UTF_8).trim(),
                    info = parseSubscriptionUserInfo(userInfoHeader, text),
                    sourceUrl = text
                )
            } finally {
                connection.disconnect()
            }
        }
        throw IllegalStateException("Could not download the subscription.")
    }


    /** Some subscription providers return a base64-encoded list of share links. */
    private fun normalizeSubscriptionContent(content: String): String {
        val trimmed = content.trim().removePrefix("\uFEFF")
        if (trimmed.isEmpty() || trimmed.startsWith("{") || trimmed.startsWith("[")) return trimmed
        val withoutHeaders = trimmed.lineSequence()
            .map { it.trim() }
            .filterNot { it.startsWith("#") || it.startsWith("//") }
            .joinToString("\n")
        if (containsSupportedShareScheme(withoutHeaders)) return withoutHeaders

        val compact = withoutHeaders.filterNot(Char::isWhitespace)
        if (compact.length < 16) return trimmed
        val decoded = sequenceOf(
            Base64.DEFAULT,
            Base64.URL_SAFE or Base64.NO_WRAP,
            Base64.NO_WRAP
        ).mapNotNull { flags ->
            runCatching { Base64.decode(compact, flags).toString(Charsets.UTF_8).trim() }.getOrNull()
        }.firstOrNull { candidate ->
            candidate.isNotBlank() && containsSupportedShareScheme(candidate) &&
                candidate.count { it == '\uFFFD' } == 0
        }
        return decoded ?: withoutHeaders.ifBlank { trimmed }
    }

    private fun containsSupportedShareScheme(text: String): Boolean {
        val schemes = listOf("vless://", "vmess://", "trojan://", "ss://", "socks://", "hysteria2://", "hy2://")
        return text.lineSequence().any { line ->
            val value = line.trim().lowercase()
            schemes.any(value::startsWith)
        }
    }

    private fun parseSubscriptionUserInfo(header: String?, sourceUrl: String?): SubscriptionInfo? {
        if (header.isNullOrBlank()) return null
        val values = header.split(';')
            .mapNotNull { part ->
                val pair = part.trim().split('=', limit = 2)
                if (pair.size != 2) null else pair[0].trim().lowercase() to pair[1].trim().toLongOrNull()
            }
            .toMap()

        val total = values["total"]?.takeIf { it >= 0L }
        val upload = values["upload"]?.takeIf { it >= 0L }
        val download = values["download"]?.takeIf { it >= 0L }
        val expire = values["expire"]?.takeIf { it >= 0L }
        if (total == null && upload == null && download == null && expire == null) return null
        return SubscriptionInfo(
            totalBytes = total,
            uploadBytes = upload,
            downloadBytes = download,
            expireAtSeconds = expire,
            fetchedAtMillis = System.currentTimeMillis(),
            sourceUrl = sourceUrl
        )
    }

    private fun tryParseLegacyVmess(link: String): JSONObject? {
        return try {
            val body = link.substringAfter("vmess://", "").substringBefore('#').trim()
            if (body.isBlank()) return null
            val decoded = try {
                Base64.decode(body, Base64.DEFAULT).toString(Charsets.UTF_8)
            } catch (_: Exception) {
                Base64.decode(body, Base64.URL_SAFE or Base64.NO_WRAP).toString(Charsets.UTF_8)
            }
            val old = JSONObject(decoded)
            val address = old.optString("add").trim()
            val port = old.optString("port").toIntOrNull() ?: old.optInt("port", 0)
            val userId = old.optString("id").trim()
            if (address.isBlank() || port !in 1..65535 || userId.isBlank()) return null

            val transport = old.optString("net", "tcp").lowercase().ifBlank { "tcp" }
            // Do not silently rewrite removed HTTP/2 transports into a different protocol.
            if (transport !in setOf("tcp", "ws", "grpc", "kcp")) return null
            val stream = JSONObject().put("network", transport)
            val host = old.optString("host").trim()
            val path = old.optString("path").trim()
            val headerType = old.optString("type", "none").ifBlank { "none" }

            when (transport) {
                "tcp" -> {
                    if (headerType == "http") {
                        stream.put(
                            "tcpSettings",
                            JSONObject().put(
                                "header",
                                JSONObject().put(
                                    "type", "http"
                                ).put(
                                    "request",
                                    JSONObject()
                                        .put("version", "1.1")
                                        .put("method", "GET")
                                        .put("path", JSONArray().put(path.ifBlank { "/" }))
                                        .put("headers", JSONObject().put("Host", JSONArray().put(host.ifBlank { address })))
                                )
                            )
                        )
                    } else {
                        stream.put("tcpSettings", JSONObject().put("header", JSONObject().put("type", "none")))
                    }
                }
                "ws" -> {
                    val headers = JSONObject()
                    if (host.isNotBlank()) headers.put("Host", host)
                    stream.put(
                        "wsSettings",
                        JSONObject()
                            .put("path", path.ifBlank { "/" })
                            .put("headers", headers)
                    )
                }
                "grpc" -> {
                    stream.put(
                        "grpcSettings",
                        JSONObject()
                            .put("serviceName", path.trimStart('/'))
                            .put("multiMode", false)
                    )
                }
                "kcp" -> {
                    stream.put(
                        "kcpSettings",
                        JSONObject()
                            .put("mtu", 1350)
                            .put("tti", 20)
                            .put("uplinkCapacity", 5)
                            .put("downlinkCapacity", 20)
                            .put("congestion", false)
                            .put("readBufferSize", 2)
                            .put("writeBufferSize", 2)
                            .put("header", JSONObject().put("type", headerType))
                    )
                }
                else -> return null
            }

            val tls = old.optString("tls").equals("tls", true)
            if (tls) {
                val serverName = old.optString("sni").ifBlank { host.ifBlank { address } }
                stream.put("security", "tls")
                stream.put(
                    "tlsSettings",
                    JSONObject()
                        .put("serverName", serverName)
                        .put("allowInsecure", false)
                )
            } else {
                stream.put("security", "none")
            }

            val user = JSONObject()
                .put("id", userId)
                .put("alterId", old.optInt("aid", 0))
                .put("security", old.optString("scy", "auto").ifBlank { "auto" })

            val settings = JSONObject().put(
                "vnext",
                JSONArray().put(
                    JSONObject()
                        .put("address", address)
                        .put("port", port)
                        .put("users", JSONArray().put(user))
                )
            )

            val fragment = link.substringAfter('#', "").takeIf { it.isNotBlank() }
                ?.let { URLDecoder.decode(it, Charsets.UTF_8.name()) }
            JSONObject()
                .put("tag", fragment ?: "VMess $address:$port")
                .put("protocol", "vmess")
                .put("settings", settings)
                .put("streamSettings", stream)
        } catch (_: Exception) {
            null
        }
    }

    private fun findHost(value: Any?): String? {
        return when (value) {
            is JSONObject -> {
                val preferred = listOf("address", "server", "host", "add")
                for (key in preferred) {
                    val candidate = value.optString(key).trim()
                    if (candidate.isNotBlank() && candidate.length < 256) return candidate
                }
                val keys = value.keys()
                while (keys.hasNext()) {
                    val found = findHost(value.opt(keys.next()))
                    if (!found.isNullOrBlank()) return found
                }
                null
            }
            is JSONArray -> {
                for (i in 0 until value.length()) {
                    val found = findHost(value.opt(i))
                    if (!found.isNullOrBlank()) return found
                }
                null
            }
            else -> null
        }
    }
}
