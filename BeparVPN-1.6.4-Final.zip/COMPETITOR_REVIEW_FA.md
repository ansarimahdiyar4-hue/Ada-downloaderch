# بررسی ده برنامه مشابه برای بهبود Bepar VPN

تاریخ بررسی: ۸ نوامبر ۲۰۲۶. این مقایسه از مستندات رسمی پروژه‌ها، راهنمای سازندگان و صفحات رسمی پشتیبانی تهیه شده است. هدف، استخراج الگوهای تجربه کاربری و قابلیت است؛ نه کپی کد یا برند.

| برنامه | الگوی قابل اقتباس | تصمیم برای Bepar VPN |
|---|---|---|
| Hiddify | انتخاب خودکار بر پایه کمترین تأخیر، پروفایل و به‌روزرسانی اشتراک، چند پروتکل و تم تیره/روشن | Auto موجود حفظ شد؛ جستجو و مرتب‌سازی فهرست‌ها تکمیل شد. |
| v2rayNG | کلاینت Android متکی به Xray/v2fly و انتشارهای امضاشده | هسته Xray و واردکردن لینک/اشتراک حفظ شد؛ برای انتشار Release باید امضای ثابت و بررسی اصالت AAR/APK برقرار باشد. |
| NekoBox | گروه/اشتراک پروفایل، پشتیبانی از قالب‌ها و URL test | تفکیک منبع داخلی و دستی حفظ شد؛ جستجو، علاقه‌مندی و sort اضافه شد. |
| FlClash | پروفایل‌ها، latency test، لاگ زنده، پشتیبان‌گیری/بازیابی، Quick Settings و per-app proxy | لاگ/ترافیک/Quick Settings و split tunneling موجود هستند؛ نیاز به مرحله بعدی برای پشتیبان‌گیری رمزگذاری‌شده و نمودارهای زنده باقی است. |
| Clash Meta for Android | rule-based routing، proxy groups، auto fallback/load balancing | حالت Auto فعلی از fallback استفاده می‌کند؛ مسیریابی قانون‌محور گسترده هنوز قابلیت آتی است. |
| sing-box for Android | سرویس VPN/TUN و سرعت لحظه‌ای اعلان | ساختار VpnService، TUN و شمارنده واقعی Xray موجود است؛ نمایش سرعت در اعلان می‌تواند در مرحله بعد اضافه شود. |
| Proton VPN | اتصال خودکار، split tunneling و Kill Switch/Always-on | split tunneling و پیوند به تنظیمات Always-on اندروید در Bepar موجود است؛ Kill Switch باید در تنظیمات خود Android فعال شود. |
| Mullvad VPN | نصب امضاشده، split tunneling و تأکید بر ارزیابی امنیتی | ذخیره‌سازی محلی رمزگذاری‌شده موجود است؛ فرایند audit و امضای Release باید پیش از انتشار عمومی انجام شود. |
| Windscribe | انتخاب پروتکل، DNS leak protection، firewall kill switch و split tunneling | DNS و split tunneling موجود است؛ هیچ وعده‌ای برای kill switch مستقل داده نمی‌شود و باید از قابلیت سیستم Android استفاده شود. |
| WG Tunnel | auto-tunneling در تغییر شبکه، handshake monitoring، kill switch و Quick Settings | reconnect و Quick Settings در Bepar وجود دارند؛ برای health monitoring دقیق‌تر باید state موتور و آزمون تونل هم‌زمان ثبت شوند. |

## آنچه در نسخه 1.6.4 اضافه شد

- علاقه‌مندی پایدار برای هر پروفایل.
- جستجو در نام سرور، hostname و protocol.
- فیلتر علاقه‌مندی‌ها.
- مرتب‌سازی با latency واقعی ذخیره‌شده، نام و پروتکل.
- حفظ علامت علاقه‌مندی هنگام merge و refresh منابع.

## مهم‌ترین شکاف‌های باقی‌مانده برای نسخه عمومی

1. **Backup امن قابل انتقال:** فایل پشتیبان باید با رمز عبور کاربر و AES-GCM رمزگذاری شود؛ خروجی متنی ساده کانفیگ‌ها ممکن است حاوی UUID، رمز یا کلید خصوصی باشد و نباید بی‌هشدار صادر شود.
2. **نمودارهای زنده و اعلان سرعت:** داده‌های واقعی Xray باید با محدودیت نرخ به‌روزرسانی در UI/notification نمایش داده شوند.
3. **قواعد مسیریابی پیشرفته:** دامنه/IP/app rules و گروه‌های fallback باید از طریق هسته و schema معتبر پیاده‌سازی شوند، نه صرفاً UI.
4. **امنیت Release:** کلید امضای Release باید بیرون مخزن GitHub نگه داشته شود؛ build artifact دیباگ برای انتشار عمومی کافی نیست.
5. **آزمون‌های واقعی:** تست روی Wi-Fi و سیم‌کارت‌های مختلف، IPv4/IPv6، تغییر شبکه، DNS، UDP و پروفایل‌های مختلف لازم است. هیچ اپی نمی‌تواند اتصال همیشگی به سرورهای عمومی ناشناس را تضمین کند.

## منابع

- Hiddify: https://github.com/hiddify/hiddify-app (automatic node selection, delay-based selection, profiles, subscription update, protocol formats).
- v2rayNG: https://github.com/2dust/v2rayNG (Android Xray/v2fly client; signed release files).
- NekoBox: https://github.com/MatsuriDayo/NekoBoxForAndroid (protocols and subscription formats).
- FlClash: https://github.com/azpanel/FlClash (profiles, latency tests, logs, backup/restore, per-app proxy, quick settings).
- Clash Meta for Android: https://f-droid.org/en/packages/com.github.metacubex.clash.meta/ (rule-based routing, remote groups, fallback and latency selection).
- sing-box Android features: https://sing-box.sagernet.org/clients/android/features/ (VpnService/TUN and per-app route capabilities).
- Proton VPN Android: https://protonvpn.com/support/best-android-vpn-app and https://protonvpn.com/support/always-on-vpn (auto-connect options, split tunneling and Android always-on/kill switch).
- Mullvad Android: https://mullvad.net/en/download/vpn/android (split tunneling, signed APK, audits).
- Windscribe: https://windscribe.com/features/split-tunneling and https://windscribe.com/install/mobile/android (split tunneling, DNS leak protection, firewall).
- WG Tunnel: https://github.com/wgtunnel/android (auto-tunneling, handshake monitoring, split tunneling, lockdown and Quick Settings).

## روش‌شناسی و احتیاط

این مرور، مستندات و معرفی قابلیت‌ها را بررسی می‌کند؛ ادعای آزمایش همه اپ‌ها روی دستگاه یا شبکه یکسان ندارد. وجود یک قابلیت در صفحه معرفی، به معنی تضمین عملکرد آن در همه کشورها، اپراتورها یا سرورها نیست.
