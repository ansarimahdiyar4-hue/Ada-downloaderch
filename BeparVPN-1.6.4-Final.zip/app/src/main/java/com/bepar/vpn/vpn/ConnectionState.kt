package com.bepar.vpn.vpn

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class VpnPhase {
    DISCONNECTED,
    CONNECTING,
    CONNECTED,
    RECONNECTING,
    ERROR
}

data class VpnUiState(
    val phase: VpnPhase = VpnPhase.DISCONNECTED,
    val message: String = "Ready to connect"
)

object ConnectionState {
    private val mutable = MutableStateFlow(VpnUiState())
    val state: StateFlow<VpnUiState> = mutable.asStateFlow()

    fun update(phase: VpnPhase, message: String) {
        mutable.value = VpnUiState(phase, message)
    }
}
