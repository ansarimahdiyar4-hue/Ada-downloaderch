package com.bepar.vpn.data

import android.content.Context
import android.os.SystemClock

/** Non-secret connection preferences and local traffic counters. */
object AppPreferences {
    private const val PREFS = "bepar_app_preferences"
    private const val KEY_AUTO_RECONNECT = "auto_reconnect"
    private const val KEY_DNS_HOST = "dns_host"
    private const val KEY_VPN_ACTIVE = "vpn_active"
    private const val KEY_VPN_CONNECTING = "vpn_connecting"
    private const val KEY_SESSION_START = "session_start"
    private const val KEY_SESSION_ACTIVE = "session_active"
    private const val KEY_SESSION_UPLOAD_BYTES = "session_upload_bytes_v2"
    private const val KEY_SESSION_DOWNLOAD_BYTES = "session_download_bytes_v2"
    private const val KEY_SESSION_FINAL_UPLOAD_BYTES = "session_final_upload_bytes_v2"
    private const val KEY_SESSION_FINAL_DOWNLOAD_BYTES = "session_final_download_bytes_v2"
    private const val KEY_SESSION_FINAL_BYTES = "session_final_bytes"
    private const val KEY_SESSION_FINAL_DURATION = "session_final_duration"

    data class SessionUsage(
        val bytes: Long,
        val durationMillis: Long,
        val startedAtMillis: Long,
        val uploadBytes: Long = 0L,
        val downloadBytes: Long = 0L
    )

    private const val KEY_LANDING_SEEN = "landing_seen"
    private const val KEY_AUTO_MODE = "auto_mode"
    private const val KEY_THEME_ID = "ui_theme_id"
    private const val KEY_LANGUAGE = "ui_language"
    private const val KEY_START_TAB = "ui_start_tab"

    val THEME_OPTIONS = listOf("purple", "blue", "emerald", "rose", "amber", "ice")
    val LANGUAGE_OPTIONS = listOf("fa", "en")
    val START_TAB_OPTIONS = listOf("HOME", "PROFILES", "LOGS", "SETTINGS")

    fun themeId(context: Context): String =
        prefs(context).getString(KEY_THEME_ID, "purple")?.takeIf { it in THEME_OPTIONS } ?: "purple"

    fun setThemeId(context: Context, themeId: String) {
        require(themeId in THEME_OPTIONS) { "Unsupported theme" }
        prefs(context).edit().putString(KEY_THEME_ID, themeId).apply()
    }

    fun language(context: Context): String =
        prefs(context).getString(KEY_LANGUAGE, "fa")?.takeIf { it in LANGUAGE_OPTIONS } ?: "fa"

    fun setLanguage(context: Context, language: String) {
        require(language in LANGUAGE_OPTIONS) { "Unsupported language" }
        prefs(context).edit().putString(KEY_LANGUAGE, language).apply()
    }

    fun startTab(context: Context): String =
        prefs(context).getString(KEY_START_TAB, "HOME")?.takeIf { it in START_TAB_OPTIONS } ?: "HOME"

    fun setStartTab(context: Context, tab: String) {
        require(tab in START_TAB_OPTIONS) { "Unsupported start tab" }
        prefs(context).edit().putString(KEY_START_TAB, tab).apply()
    }

    private const val KEY_SETUP_PROMPTED = "setup_prompted"

    fun setupPrompted(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SETUP_PROMPTED, false)

    fun setSetupPrompted(context: Context) {
        prefs(context).edit().putBoolean(KEY_SETUP_PROMPTED, true).apply()
    }

    fun landingSeen(context: Context): Boolean =
        prefs(context).getBoolean(KEY_LANDING_SEEN, false)

    fun setLandingSeen(context: Context) {
        prefs(context).edit().putBoolean(KEY_LANDING_SEEN, true).apply()
    }

    /** Auto (default) lets the app pick and verify a working server; Manual uses the selected one. */
    fun autoMode(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_MODE, true)

    fun setAutoMode(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_MODE, enabled).apply()
    }

    fun autoReconnect(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_RECONNECT, true)

    fun setAutoReconnect(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_RECONNECT, enabled).apply()
    }

    // ---- Operator compatibility ------------------------------------------------------

    /** auto = adapt to the network (recommended), standard = no tricks, fragment / strong = anti-DPI. */
    val COMPAT_MODES = listOf("auto", "standard", "fragment", "strong")
    private const val KEY_COMPAT_MODE = "compat_mode"
    private const val KEY_LAST_GOOD_CELLULAR = "last_good_tuning_cellular"
    private const val KEY_LAST_GOOD_OTHER = "last_good_tuning_other"

    fun compatMode(context: Context): String =
        prefs(context).getString(KEY_COMPAT_MODE, "auto")?.takeIf { it in COMPAT_MODES } ?: "auto"

    fun setCompatMode(context: Context, mode: String) {
        require(mode in COMPAT_MODES) { "Unsupported compatibility mode" }
        prefs(context).edit().putString(KEY_COMPAT_MODE, mode).apply()
    }

    /** The tuning that last produced a verified connection on this kind of network (cellular / other). */
    fun lastGoodTuning(context: Context, cellular: Boolean): String? =
        prefs(context).getString(if (cellular) KEY_LAST_GOOD_CELLULAR else KEY_LAST_GOOD_OTHER, null)

    fun setLastGoodTuning(context: Context, cellular: Boolean, name: String) {
        prefs(context).edit()
            .putString(if (cellular) KEY_LAST_GOOD_CELLULAR else KEY_LAST_GOOD_OTHER, name)
            .apply()
    }

    fun dnsHost(context: Context): String =
        prefs(context).getString(KEY_DNS_HOST, "1.1.1.1")
            ?.takeIf { it in ALLOWED_DNS }
            ?: "1.1.1.1"

    fun setDnsHost(context: Context, host: String) {
        require(host in ALLOWED_DNS) { "Unsupported DNS resolver" }
        prefs(context).edit().putString(KEY_DNS_HOST, host).apply()
    }

    // ---- Server list / feed settings -------------------------------------------------

    /** Selectable values for the Settings screen. 0 in [MAX_PING_OPTIONS] means "no limit". */
    val UPDATE_INTERVAL_OPTIONS = listOf(15, 30, 60, 180)
    val SERVERS_PER_SOURCE_OPTIONS = listOf(5, 10, 15, 20)
    val MAX_PING_OPTIONS = listOf(500, 1000, 1500, 0)
    val DNS_OPTIONS = listOf("1.1.1.1", "8.8.8.8", "9.9.9.9", "94.140.14.14", "208.67.222.222")

    private const val DEFAULT_UPDATE_INTERVAL = 15
    private const val DEFAULT_SERVERS_PER_SOURCE = 10
    private const val DEFAULT_MAX_PING = 1000

    private const val KEY_AUTO_UPDATE = "feed_auto_update"
    private const val KEY_UPDATE_INTERVAL = "feed_update_interval_minutes"
    private const val KEY_SERVERS_PER_SOURCE = "feed_servers_per_source"
    private const val KEY_MAX_PING = "feed_max_ping_ms"
    private const val KEY_CONNECT_ON_START = "connect_on_app_start"
    private const val KEY_BYPASS_APPS = "bypass_apps"

    /** Background refresh of the public server lists (WorkManager). Manual refresh always works. */
    fun autoUpdate(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AUTO_UPDATE, true)

    fun setAutoUpdate(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_AUTO_UPDATE, enabled).apply()
    }

    fun updateIntervalMinutes(context: Context): Int =
        prefs(context).getInt(KEY_UPDATE_INTERVAL, DEFAULT_UPDATE_INTERVAL)
            .takeIf { it in UPDATE_INTERVAL_OPTIONS } ?: DEFAULT_UPDATE_INTERVAL

    fun setUpdateIntervalMinutes(context: Context, minutes: Int) {
        require(minutes in UPDATE_INTERVAL_OPTIONS) { "Unsupported update interval" }
        prefs(context).edit().putInt(KEY_UPDATE_INTERVAL, minutes).apply()
    }

    /** How many live, lowest-ping servers are kept from each public source. */
    fun serversPerSource(context: Context): Int =
        prefs(context).getInt(KEY_SERVERS_PER_SOURCE, DEFAULT_SERVERS_PER_SOURCE)
            .takeIf { it in SERVERS_PER_SOURCE_OPTIONS } ?: DEFAULT_SERVERS_PER_SOURCE

    fun setServersPerSource(context: Context, count: Int) {
        require(count in SERVERS_PER_SOURCE_OPTIONS) { "Unsupported server count" }
        prefs(context).edit().putInt(KEY_SERVERS_PER_SOURCE, count).apply()
    }

    /** Timeout/threshold for lightweight TCP feed screening only; this is not the displayed VPN ping. 0 = no limit. */
    fun maxPingMillis(context: Context): Int =
        prefs(context).getInt(KEY_MAX_PING, DEFAULT_MAX_PING)
            .takeIf { it in MAX_PING_OPTIONS } ?: DEFAULT_MAX_PING

    fun setMaxPingMillis(context: Context, millis: Int) {
        require(millis in MAX_PING_OPTIONS) { "Unsupported ping limit" }
        prefs(context).edit().putInt(KEY_MAX_PING, millis).apply()
    }

    fun connectOnStart(context: Context): Boolean =
        prefs(context).getBoolean(KEY_CONNECT_ON_START, false)

    fun setConnectOnStart(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_CONNECT_ON_START, enabled).apply()
    }

    /** Package names that skip the VPN (split tunneling). Applied the next time the tunnel is built. */
    fun bypassApps(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_BYPASS_APPS, null)?.toSet() ?: emptySet()

    fun setBypassApps(context: Context, packages: Set<String>) {
        prefs(context).edit().putStringSet(KEY_BYPASS_APPS, HashSet(packages)).apply()
    }

    fun isVpnActive(context: Context): Boolean =
        prefs(context).getBoolean(KEY_VPN_ACTIVE, false)

    fun isVpnConnecting(context: Context): Boolean =
        prefs(context).getBoolean(KEY_VPN_CONNECTING, false)

    fun setVpnStatus(context: Context, active: Boolean, connecting: Boolean) {
        prefs(context).edit()
            .putBoolean(KEY_VPN_ACTIVE, active)
            .putBoolean(KEY_VPN_CONNECTING, connecting)
            .apply()
    }

    /** Starts a new session; byte counters are populated from Xray's actual proxy metrics. */
    fun beginSession(context: Context) {
        prefs(context).edit()
            .putLong(KEY_SESSION_START, SystemClock.elapsedRealtime())
            .putLong(KEY_SESSION_UPLOAD_BYTES, 0L)
            .putLong(KEY_SESSION_DOWNLOAD_BYTES, 0L)
            .putLong(KEY_SESSION_FINAL_BYTES, 0L)
            .putLong(KEY_SESSION_FINAL_UPLOAD_BYTES, 0L)
            .putLong(KEY_SESSION_FINAL_DOWNLOAD_BYTES, 0L)
            .putLong(KEY_SESSION_FINAL_DURATION, 0L)
            .putBoolean(KEY_SESSION_ACTIVE, true)
            .apply()
    }

    /** Adds deltas read from Xray metrics, never the VPN app's unrelated UID traffic. */
    fun addSessionTraffic(context: Context, uploadDelta: Long, downloadDelta: Long) {
        if (uploadDelta <= 0L && downloadDelta <= 0L) return
        val snapshot = prefs(context)
        if (!snapshot.getBoolean(KEY_SESSION_ACTIVE, false)) return
        val upload = saturatingAdd(snapshot.getLong(KEY_SESSION_UPLOAD_BYTES, 0L), uploadDelta.coerceAtLeast(0L))
        val download = saturatingAdd(snapshot.getLong(KEY_SESSION_DOWNLOAD_BYTES, 0L), downloadDelta.coerceAtLeast(0L))
        snapshot.edit()
            .putLong(KEY_SESSION_UPLOAD_BYTES, upload)
            .putLong(KEY_SESSION_DOWNLOAD_BYTES, download)
            .apply()
    }

    fun endSession(context: Context) {
        val usage = sessionUsage(context)
        val editor = prefs(context).edit().putBoolean(KEY_SESSION_ACTIVE, false)
        if (usage != null) {
            editor.putLong(KEY_SESSION_FINAL_BYTES, usage.bytes)
                .putLong(KEY_SESSION_FINAL_UPLOAD_BYTES, usage.uploadBytes)
                .putLong(KEY_SESSION_FINAL_DOWNLOAD_BYTES, usage.downloadBytes)
                .putLong(KEY_SESSION_FINAL_DURATION, usage.durationMillis)
        }
        editor.apply()
    }

    fun sessionUsage(context: Context): SessionUsage? {
        val snapshot = prefs(context)
        val started = snapshot.getLong(KEY_SESSION_START, 0L)
        if (started <= 0L) return null
        val active = snapshot.getBoolean(KEY_SESSION_ACTIVE, false)
        val upload = if (active) snapshot.getLong(KEY_SESSION_UPLOAD_BYTES, 0L)
            else snapshot.getLong(KEY_SESSION_FINAL_UPLOAD_BYTES, 0L)
        val download = if (active) snapshot.getLong(KEY_SESSION_DOWNLOAD_BYTES, 0L)
            else snapshot.getLong(KEY_SESSION_FINAL_DOWNLOAD_BYTES, 0L)
        val bytes = saturatingAdd(upload, download)
        val duration = if (active) {
            val now = SystemClock.elapsedRealtime()
            if (now < started) 0L else now - started
        } else snapshot.getLong(KEY_SESSION_FINAL_DURATION, 0L)
        return SessionUsage(
            bytes = bytes,
            durationMillis = duration.coerceAtLeast(0L),
            startedAtMillis = System.currentTimeMillis(),
            uploadBytes = upload,
            downloadBytes = download
        )
    }

    private fun saturatingAdd(left: Long, right: Long): Long =
        if (Long.MAX_VALUE - left < right) Long.MAX_VALUE else left + right

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private val ALLOWED_DNS: Set<String> get() = DNS_OPTIONS.toSet()
}
