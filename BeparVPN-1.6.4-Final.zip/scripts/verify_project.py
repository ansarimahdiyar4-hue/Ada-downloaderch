#!/usr/bin/env python3
"""Fast static integrity checks for the Bepar VPN Android source tree.

This script does not replace Gradle assemble, Android lint, instrumentation tests,
or a real VPN connection test on a physical Android device.
"""
from __future__ import annotations

import re
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

try:
    from PIL import Image
except ImportError as exc:
    raise SystemExit("Pillow is required: python -m pip install Pillow") from exc

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / "app"
RES = APP / "src/main/res"
errors: list[str] = []
checks = 0


def check(condition: bool, message: str) -> None:
    global checks
    checks += 1
    if not condition:
        errors.append(message)


# Parse every Android XML resource and manifest.
xml_files = sorted(RES.rglob("*.xml"))
for path in xml_files:
    try:
        ET.parse(path)
        check(True, f"XML parses: {path.relative_to(ROOT)}")
    except ET.ParseError as exc:
        check(False, f"Invalid XML {path.relative_to(ROOT)}: {exc}")

# Validate icon bitmaps and non-empty adaptive foreground.
icon_files = sorted(RES.glob("mipmap-*/ic_launcher*.png"))
check(len(icon_files) == 10, f"Expected 10 launcher PNGs (normal + round across five densities), found {len(icon_files)}")
for path in icon_files:
    try:
        with Image.open(path) as image:
            image.verify()
        with Image.open(path) as image:
            check(image.mode in ("RGBA", "RGB") and image.width == image.height, f"Launcher icon must be square RGBA/RGB: {path}")
            check(image.width > 0, f"Launcher icon must not be empty: {path}")
    except Exception as exc:  # Pillow's format/decoder exceptions vary by build.
        check(False, f"Invalid launcher image {path.relative_to(ROOT)}: {exc}")

foreground = RES / "drawable-nodpi/bepar_launcher_foreground.png"
check(foreground.exists(), "Adaptive foreground image exists")
if foreground.exists():
    try:
        with Image.open(foreground) as image:
            image.verify()
        with Image.open(foreground) as image:
            check(image.mode == "RGBA", "Adaptive icon foreground keeps transparency")
            check(image.width == image.height and image.width >= 432, "Adaptive foreground has a suitable square canvas")
    except Exception as exc:
        check(False, f"Invalid adaptive foreground: {exc}")

# Ensure launcher resources point at an existing foreground and the obsolete logo is gone.
for path in (RES / "mipmap-anydpi-v26/ic_launcher.xml", RES / "mipmap-anydpi-v26/ic_launcher_round.xml"):
    content = path.read_text(encoding="utf-8")
    check("@drawable/bepar_launcher_foreground" in content, f"Adaptive launcher references new brand: {path.name}")
check(not (RES / "drawable-nodpi/bepar_windows_brand.png").exists(), "Obsolete letter-logo asset removed")
check(not any("bepar_windows_brand" in p.read_text(encoding="utf-8", errors="ignore") for p in ROOT.rglob("*.xml")), "No XML points at obsolete logo")

# Check app coordinates and native library build hand-off.
gradle = (APP / "build.gradle.kts").read_text(encoding="utf-8")
check('versionCode = 13' in gradle and 'versionName = "1.6.4"' in gradle, "App version is 1.6.4 / versionCode 13")
check('minSdk = 24' in gradle, "Minimum Android API is 24 for the Quick Settings tile service")
check("buildConfig = true" in gradle, "BuildConfig generation is enabled for About screen version text")
check((APP / "libs/libXray.aar").exists() or "libXray.aar" in gradle, "libXray dependency is declared or bundled")
main_activity = (APP / "src/main/java/com/bepar/vpn/MainActivity.kt").read_text(encoding="utf-8")
check('private const val' not in main_activity or 'private fun LogoMark' in main_activity, "Compose source has an app logo composable")
check('val shield = Path()' in main_activity and 'val b = Path()' not in main_activity, "Compose logo uses shield mark, not letter glyph")
selector = (APP / "src/main/java/com/bepar/vpn/data/BestServerSelector.kt").read_text(encoding="utf-8")
check("FEED_PROBE_THREADS = 24" in selector, "Feed probing concurrency is bounded")
check((APP / "src/main/java/com/bepar/vpn/vpn/BeparVpnService.kt").exists(), "VPN service source exists")
check((APP / "src/main/java/com/bepar/vpn/core/XrayConfigBuilder.kt").exists(), "Xray config builder source exists")

# Profile management: favourites survive encrypted persistence and feed refresh.
server_node = (APP / "src/main/java/com/bepar/vpn/data/ServerNode.kt").read_text(encoding="utf-8")
node_store = (APP / "src/main/java/com/bepar/vpn/data/NodeStore.kt").read_text(encoding="utf-8")
check("val isFavorite: Boolean = false" in server_node, "Server model contains a backward-compatible favourite flag")
check('optBoolean("isFavorite", false)' in node_store and '.put("isFavorite", profile.isFavorite)' in node_store, "Favourite state is encrypted-persisted with old data defaulting false")
check("fun setFavorite(" in node_store and "isFavorite = existing.isFavorite" in node_store, "Favourites survive user updates and matching feed refreshes")
check('uiText("Search servers")' in main_activity and 'favoritesOnly' in main_activity, "Server screen supports local search and favourite filtering")
check('"name" -> filtered.sortedWith' in main_activity and '"protocol" -> filtered.sortedWith' in main_activity, "Server list supports name/protocol sorting alongside measured latency")

# Connection correctness: displayed ping must be a real outbound probe, and "connected"
# must require a live Core plus HTTPS through the system TUN.
xray_api = (APP / "src/main/java/com/bepar/vpn/core/XrayApi.kt").read_text(encoding="utf-8")
service = (APP / "src/main/java/com/bepar/vpn/vpn/BeparVpnService.kt").read_text(encoding="utf-8")
tunnel_probe = (APP / "src/main/java/com/bepar/vpn/core/TunnelProbe.kt").read_text(encoding="utf-8")
metrics = (APP / "src/main/java/com/bepar/vpn/core/XrayMetricsReader.kt").read_text(encoding="utf-8")
check('chunked(5)' in xray_api and '"pingBatch"' in xray_api, "Real Xray ping is sent in API-safe batches of five")
check('item?.optBoolean("success", false)' in xray_api and 'it in 0L..9_999L' in xray_api, "Only successful outbound latency measurements are accepted")
check('TunnelProbe.quickCheck()' in service and 'getXrayState' in service, "Service verifies both Xray runtime and HTTPS tunnel")
check('setUnderlyingNetworks' in service and 'AUTO_FALLBACK_ATTEMPTS = 8' in service, "Underlying Android network is tracked and fallback tries up to eight profiles")
check('code in 200..299' in tunnel_probe and 'api.github.com/zen' in tunnel_probe, "Tunnel verification accepts valid HTTPS 2xx from independent endpoints")
check('127.0.0.1:$port/debug/vars' in metrics and 'optJSONObject("proxy")' in metrics, "Traffic counters are read from Xray proxy metrics")

if errors:
    print(f"FAILED: {len(errors)} issue(s) across {checks} checks")
    for error in errors:
        print(f" - {error}")
    sys.exit(1)

print(f"PASS: {checks} static integrity checks")
print("Note: Gradle build, Android lint, libXray runtime, and real-device VPN checks are separate.")
