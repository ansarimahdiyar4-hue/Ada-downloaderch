package com.bepar.vpn.vpn

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Intent
import android.graphics.drawable.Icon
import android.net.VpnService
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService
import androidx.annotation.RequiresApi
import androidx.core.content.ContextCompat
import com.bepar.vpn.MainActivity
import com.bepar.vpn.R
import com.bepar.vpn.data.AppPreferences

/**
 * Quick Settings switch for Bepar VPN.
 * First use opens the app only when Android's VPN consent dialog is still required.
 * Once consent is granted, later taps toggle the VPN directly from Quick Settings.
 */
@RequiresApi(Build.VERSION_CODES.N)
class BeparVpnTileService : TileService() {

    override fun onStartListening() {
        super.onStartListening()
        updateTile()
    }

    override fun onClick() {
        super.onClick()

        if (VpnService.prepare(this) != null) {
            launchAppForVpnConsent()
            return
        }

        val wasRunning = AppPreferences.isVpnActive(this) || AppPreferences.isVpnConnecting(this)
        val serviceIntent = Intent(this, BeparVpnService::class.java).apply {
            action = BeparVpnService.ACTION_TOGGLE_BEST
        }
        try {
            ContextCompat.startForegroundService(this, serviceIntent)
        } catch (error: Exception) {
            android.widget.Toast.makeText(
                this,
                error.message ?: "Could not start Bepar VPN.",
                android.widget.Toast.LENGTH_LONG
            ).show()
            updateTile()
            return
        }
        getQsTile()?.let { tile ->
            tile.state = Tile.STATE_ACTIVE
            tile.label = "Bepar VPN"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                tile.subtitle = if (wasRunning) "Disconnecting…" else "Connecting…"
            }
            tile.contentDescription = if (wasRunning) "Bepar VPN is disconnecting" else "Bepar VPN is connecting to the best server"
            tile.updateTile()
        }
    }

    private fun launchAppForVpnConsent() {
        val intent = Intent(this, MainActivity::class.java).apply {
            action = MainActivity.ACTION_QUICK_CONNECT
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val pendingIntent = PendingIntent.getActivity(
                this,
                1401,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            startActivityAndCollapse(pendingIntent)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(intent)
        }
    }

    private fun updateTile() {
        val tile = getQsTile() ?: return
        val connecting = AppPreferences.isVpnConnecting(this)
        val manager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val capabilities = manager.activeNetwork?.let(manager::getNetworkCapabilities)
        val osVpnActive = capabilities?.hasTransport(NetworkCapabilities.TRANSPORT_VPN) == true
        var active = AppPreferences.isVpnActive(this) && osVpnActive
        if (AppPreferences.isVpnActive(this) && !osVpnActive && !connecting) {
            AppPreferences.endSession(this)
            AppPreferences.setVpnStatus(this, active = false, connecting = false)
            active = false
        }
        tile.state = if (active || connecting) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        tile.label = "Bepar VPN"
        tile.icon = Icon.createWithResource(this, R.drawable.ic_qs_bepar_vpn)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            tile.subtitle = when {
                connecting -> "Connecting…"
                active -> "Connected"
                else -> "Disconnected"
            }
        }
        tile.contentDescription = when {
            connecting -> "Bepar VPN is connecting"
            active -> "Bepar VPN is connected. Tap to disconnect."
            else -> "Bepar VPN is disconnected. Tap to connect to the best server."
        }
        tile.updateTile()
    }

    companion object {
        fun requestRefresh(context: android.content.Context) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                runCatching {
                    TileService.requestListeningState(
                        context,
                        ComponentName(context, BeparVpnTileService::class.java)
                    )
                }
            }
        }
    }
}
