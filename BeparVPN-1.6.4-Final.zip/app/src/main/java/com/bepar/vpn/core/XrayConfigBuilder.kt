package com.bepar.vpn.core

import org.json.JSONArray
import org.json.JSONObject

/**
 * One combination of operator-compatibility tricks. [fragment] splits the TLS ClientHello into
 * small pieces (defeats the SNI/DPI filtering most mobile operators and ISPs use); the numbers are
 * Xray's "length" and "interval" ranges in bytes / milliseconds.
 */
enum class Tuning(val id: String, val fragment: Boolean, val length: String, val interval: String) {
    STANDARD("standard", false, "", ""),
    FRAGMENT("fragment", true, "100-200", "10-20"),
    STRONG("strong", true, "10-40", "15-30");

    companion object {
        fun fromId(id: String?): Tuning? = values().firstOrNull { it.id == id }
    }
}

object XrayConfigBuilder {
    /** Conservative MTU also survives Wi-Fi-to-cellular handoffs without rebuilding Android's TUN. */
    const val TUN_MTU = 1280
    const val TUN_MTU_CELLULAR = 1280

    private val UDP_BASED_PROTOCOLS = setOf("hysteria", "hysteria2", "tuic", "wireguard")
    private val TLS_CAPABLE_PROTOCOLS = setOf("vless", "vmess", "trojan", "shadowsocks")
    private val NON_TCP_NETWORKS = setOf("kcp", "mkcp", "quic")

    /** True when a TLS-hello fragment can be applied to this outbound (TCP-based, TLS or REALITY). */
    fun supportsFragment(outboundJson: String): Boolean = try {
        val o = JSONObject(outboundJson)
        val protocol = o.optString("protocol").lowercase()
        val stream = o.optJSONObject("streamSettings")
        val network = stream?.optString("network", "tcp")?.lowercase() ?: "tcp"
        val security = stream?.optString("security", "none")?.lowercase() ?: "none"
        protocol in TLS_CAPABLE_PROTOCOLS && protocol !in UDP_BASED_PROTOCOLS &&
            network !in NON_TCP_NETWORKS && (security == "tls" || security == "reality")
    } catch (_: Exception) {
        false
    }

    fun build(
        outboundJson: String,
        tunFd: Int,
        assetDirectory: String,
        dnsHost: String = "1.1.1.1",
        tuning: Tuning = Tuning.STANDARD,
        mtu: Int = TUN_MTU,
        metricsPort: Int = 49227
    ): String {
        require(tunFd >= 0) { "Invalid TUN file descriptor" }
        val proxyOutbound = JSONObject(outboundJson)
        val protocol = proxyOutbound.optString("protocol")
        require(protocol.isNotBlank()) { "The server protocol is missing from the configuration." }
        proxyOutbound.put("tag", "proxy")

        val useFragment = tuning.fragment && supportsFragment(outboundJson)
        if (useFragment) {
            // Route the proxy's own TCP dialing through a "freedom" outbound that fragments the TLS hello.
            val stream = proxyOutbound.optJSONObject("streamSettings") ?: JSONObject().also {
                proxyOutbound.put("streamSettings", it)
            }
            val sockopt = stream.optJSONObject("sockopt") ?: JSONObject().also { stream.put("sockopt", it) }
            sockopt.put("dialerProxy", "fragment")
        }

        val outbounds = JSONArray()
            .put(proxyOutbound)
            .put(
                JSONObject()
                    .put("tag", "direct")
                    .put("protocol", "freedom")
                    .put("settings", JSONObject())
            )
            .put(
                JSONObject()
                    .put("tag", "block")
                    .put("protocol", "blackhole")
                    .put("settings", JSONObject())
            )
        if (useFragment) {
            outbounds.put(
                JSONObject()
                    .put("tag", "fragment")
                    .put("protocol", "freedom")
                    .put(
                        "settings",
                        JSONObject()
                            .put("domainStrategy", "AsIs")
                            .put(
                                "fragment",
                                JSONObject()
                                    .put("packets", "tlshello")
                                    .put("length", tuning.length)
                                    .put("interval", tuning.interval)
                            )
                    )
            )
        }

        val inbound = JSONObject()
            .put("tag", "bepar-tun")
            .put("protocol", "tun")
            .put("port", 0)
            .put(
                "settings",
                JSONObject()
                    .put("name", "bepar0")
                    .put("mtu", mtu)
            )

        val routingRule = JSONObject()
            .put("type", "field")
            .put("inboundTag", JSONArray().put("bepar-tun"))
            .put("outboundTag", "proxy")

        return JSONObject()
            .put("log", JSONObject().put("loglevel", "warning"))
            .put(
                "env",
                JSONObject()
                    // libXray's current Android integration reads the externally-owned TUN fd here.
                    .put("xray.tun.fd", tunFd.toString())
                    .put("XRAY_LOCATION_ASSET", assetDirectory)
            )
            .put("inbounds", JSONArray().put(inbound))
            .put("outbounds", outbounds)
            .put(
                "routing",
                JSONObject()
                    .put("domainStrategy", "AsIs")
                    .put("rules", JSONArray().put(routingRule))
            )
            .put(
                "dns",
                JSONObject()
                    .put("servers", JSONArray().put(dnsHost).put(if (dnsHost == "8.8.8.8") "1.1.1.1" else "8.8.8.8"))
                    .put("queryStrategy", "UseIP")
            )
            // Xray expvar metrics expose real proxy in/out byte counters.
            .put("stats", JSONObject())
            .put(
                "policy",
                JSONObject().put(
                    "system",
                    JSONObject()
                        .put("statsInboundUplink", true)
                        .put("statsInboundDownlink", true)
                        .put("statsOutboundUplink", true)
                        .put("statsOutboundDownlink", true)
                )
            )
            .put("metrics", JSONObject().put("listen", "127.0.0.1:$metricsPort"))
            .toString()
    }
}
