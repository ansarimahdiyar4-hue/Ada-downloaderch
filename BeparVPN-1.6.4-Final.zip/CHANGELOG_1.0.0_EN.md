# 1.0.0

- Landing screen: animated welcome on first launch, short branded splash afterwards.
- Auto is now a first-class mode (AUTO / MANUAL switch on Home). The power button follows the mode.
- Auto really verifies servers: refreshes feeds, ranks by TCP latency, starts Xray on the best candidates and
  checks HTTPS through the tunnel; dead servers are skipped automatically (up to 6 attempts).
- Manual connect now also runs an internet check and tells you honestly if the server has no traffic.
- New animated power button: press spring, connecting ripples + orbiting arc, connect shockwave, idle glow.
- Crash fixes: startForeground is called immediately on every service start path (prevents
  ForegroundServiceDidNotStartInTimeException); native/linkage errors from libXray are caught (they are Errors,
  not Exceptions); executor tasks can no longer kill the process.
- 3D visuals: rotating wireframe globe with orbiting nodes (landing + behind the power button), depth-faded back side,
  glassy bevelled power button with specular highlight, floor shadow, press tilt (rotationX), idle parallax sway and a
  coin-flip (rotationY) when the tunnel connects.
- First-run setup dialog: allow notifications and disable battery optimization.
