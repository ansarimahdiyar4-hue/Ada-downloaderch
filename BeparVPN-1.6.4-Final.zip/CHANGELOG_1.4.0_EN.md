# Bepar VPN Android 1.4.0

## Quick Settings
- Added an Android Quick Settings toggle tile for Bepar VPN.
- Android 13+ can prompt the user to add the tile; older Android versions use the Quick Settings Edit screen.
- First use opens the app only when Android VPN consent is still required. Later tile taps toggle connect-to-best-server / disconnect.
- Tile state is refreshed through active TileService mode when the VPN service publishes state changes.

## Best server selection
- Ranks eligible profiles by TCP connection handshake time, using completion-order collection within a bounded probe window.
- Resolves hostnames and binds probe sockets to the physical Wi-Fi/mobile Network so probes do not loop into the VPN TUN.
- Skips UDP-only protocols/transports; if no physical network or TCP endpoint is testable, uses the saved profile.
- This is a connection-establishment probe, not a throughput/speed guarantee.

## Usage and subscription metadata
- Adds local per-session app-UID traffic estimate and session duration.
- Parses HTTPS `subscription-userinfo` headers for total/upload/download/expiry where the provider supplies them.
- Supports Base64-encoded HTTPS subscription bodies, validates each redirect before following it, and retains the original HTTPS URL for future refreshes.
- Replaces stale profiles from a refreshed subscription while retaining unrelated profiles; displays `Not provided` when plan quota/expiry metadata is absent rather than inventing values.

## UI and settings
- Refined the standard power glyph and 8-tooth settings gear glyph.
- Kept compact English screens and removed nonessential helper text.
- Quick Settings switch shortcut is available in Settings.

## Validation limits
- Structural Python checks, XML parsing, ZIP integrity and Kotlin parser-level syntax scan are performed before handoff.
- A full Android Gradle build and device test still require GitHub Actions and a phone with a valid VPN profile.
