package com.bepar.vpn.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.Constraints
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import androidx.work.BackoffPolicy
import java.util.concurrent.TimeUnit
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AutoFeedRefreshWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {
    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        try {
            val network = BestServerSelector.findPhysicalNetwork(applicationContext)
            val result = RemoteConfigFeedRepository.refreshAll(applicationContext, network)
            if (result.hasSuccess) Result.success() else Result.retry()
        } catch (_: Exception) {
            Result.retry()
        }
    }
}

object AutoFeedRefreshScheduler {
    private fun constraints() = Constraints.Builder()
        .setRequiredNetworkType(NetworkType.CONNECTED)
        .build()

    /** (Re)schedules the background refresh from the Settings values; cancels it when auto-update is off. */
    fun schedule(context: Context) {
        val manager = WorkManager.getInstance(context)
        if (!AppPreferences.autoUpdate(context)) {
            manager.cancelUniqueWork(RemoteConfigFeedRepository.WORK_NAME)
            return
        }
        val request = PeriodicWorkRequestBuilder<AutoFeedRefreshWorker>(
            AppPreferences.updateIntervalMinutes(context).toLong(),
            TimeUnit.MINUTES
        )
            .setConstraints(constraints())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        manager.enqueueUniquePeriodicWork(
            RemoteConfigFeedRepository.WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            request
        )
    }

    fun enqueueInitialRefresh(context: Context) {
        val request = OneTimeWorkRequestBuilder<AutoFeedRefreshWorker>()
            .setConstraints(constraints())
            .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 30, TimeUnit.SECONDS)
            .build()
        WorkManager.getInstance(context).enqueueUniqueWork(
            "${RemoteConfigFeedRepository.WORK_NAME}-initial",
            ExistingWorkPolicy.KEEP,
            request
        )
    }
}
