# راهنمای ساخت Bepar VPN 1.6.4

## محتویات بسته
- `BeparVPN-1.6.4-Final.zip`: سورس کامل Android.
- `.github/workflows/build-apk.yml`: فایل GitHub Actions آماده.

## ساختار لازم در مخزن GitHub

هر دو مورد باید در ریشه Repository باشند:

```text
repository/
├── BeparVPN-1.6.4-Final.zip
└── .github/
    └── workflows/
        └── build-apk.yml
```

## اجرا
1. محتویات این Build Kit را در ریشه Repository قرار بده.
2. فایل workflow باید دقیقاً در مسیر `.github/workflows/build-apk.yml` باشد.
3. Commit changes را ثبت کن.
4. در تب Actions، گردش‌کار `Build Bepar VPN 1.6.4` را باز کن و Run workflow را اجرا کن.
5. پس از موفقیت job، Artifact با نام `BeparVPN-1.6.4-Final-APK` را دانلود کن. داخل ZIP خروجی `app-debug.apk` است.

این Workflow از JDK 17، Go 1.27.3، Android SDK 35، NDK 27.2.12479018 و Gradle 8.13 استفاده می‌کند. پکیج منسوخ‌شده Android SDK با نام `tools` درخواست نمی‌شود. Lint گزارش تشخیصی تولید می‌کند اما مانع APK assembly نمی‌شود؛ تست Unit و کامپایل APK اجباری‌اند.

## تغییرات 1.6.4
- علاقه‌مندی پایدار برای هر سرور.
- جستجو در نام، hostname و protocol.
- فیلتر علاقه‌مندی‌ها.
- مرتب‌سازی بر اساس latency اندازه‌گیری‌شده، نام و پروتکل.
- حفظ علاقه‌مندی‌ها هنگام ادغام پروفایل‌های تکراری و تازه‌سازی منابع.
- نسخه برنامه 1.6.4 / versionCode 13.

## محدودیت اعتبارسنجی
اسکریپت بررسی ایستا در محیط تحویل اجرا شده است. در این محیط Gradle/Android SDK/NDK و دستگاه فیزیکی برای کامپایل و آزمایش کامل موجود نیستند؛ موفقیت Build و کارکرد واقعی VPN باید در GitHub Actions و روی گوشی بررسی شود. سبز شدن build به‌تنهایی سلامت همه سرورها یا اتصال همه اپراتورها را تضمین نمی‌کند.
