package com.bepar.vpn.data

import android.content.Context
import android.net.Network
import com.bepar.vpn.core.XrayApi
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/** Public community feeds. Profiles are treated as untrusted third-party endpoints. */
data class RemoteConfigSource(
    val id: String,
    val title: String,
    val url: String,
    val fallbackUrls: List<String> = emptyList()
)

data class RemoteConfigSourceStatus(
    val id: String,
    val title: String,
    val profileCount: Int,
    val lastSuccessAt: Long,
    val lastError: String?,
    /** Lowest TCP connect time among the servers kept from this source; 0 when unknown. */
    val bestPingMillis: Long = 0L
)

data class RemoteConfigRefreshResult(
    val successfulSources: Int,
    val failedSources: Int,
    val importedProfiles: Int,
    val totalProfiles: Int,
    val completedAt: Long
) {
    val hasSuccess: Boolean get() = successfulSources > 0
}

/**
 * Fetches four independent, public GitHub subscriptions and converts links to Xray outbounds.
 * Public feeds are mostly dead, so only a bounded random sample is converted, every candidate is
 * TCP-reachability-filtered for TCP transports while retaining UDP candidates. The feed-stage TCP
 * measurement is never exposed as a proxy ping; only native libXray outbound probes populate the
 * visible ping field when a user connects. Up to [AppPreferences.serversPerSource] profiles are kept.
 * Only profiles owned by each feed are replaced. A failed feed, or one with no live server,
 * never deletes its previously imported servers.
 */
object RemoteConfigFeedRepository {
    /** Default (and shortest) refresh interval; the user can pick a longer one in Settings. */
    const val REFRESH_INTERVAL_MINUTES = 15L
    const val WORK_NAME = "bepar-remote-config-refresh"
    val refreshEvents = kotlinx.coroutines.flow.MutableStateFlow(0L)

    val sources = listOf(
        RemoteConfigSource(
            id = "radikal-verified",
            title = "Radikal Verified",
            url = "https://raw.githubusercontent.com/0xRadikal/Free-v2ray-Configs/main/verified/configs.txt",
            fallbackUrls = listOf("https://cdn.jsdelivr.net/gh/0xRadikal/Free-v2ray-Configs@main/verified/configs.txt")
        ),
        RemoteConfigSource(
            id = "vestranet-mix",
            title = "VestraNet Mix",
            url = "https://raw.githubusercontent.com/MustafaBaqer/VestraNet-Nodes/main/subscriptions/mix-normal.txt",
            fallbackUrls = listOf("https://cdn.jsdelivr.net/gh/MustafaBaqer/VestraNet-Nodes@main/subscriptions/mix-normal.txt")
        ),
        RemoteConfigSource(
            id = "barry-far-all",
            title = "Barry-Far Network",
            url = "https://raw.githubusercontent.com/barry-far/V2ray-Config/main/All_Configs_Sub.txt",
            fallbackUrls = listOf("https://cdn.jsdelivr.net/gh/barry-far/V2ray-Config@main/All_Configs_Sub.txt")
        ),
        RemoteConfigSource(
            id = "matin-super",
            title = "Matin Super Nodes",
            url = "https://raw.githubusercontent.com/MatinGhanbari/v2ray-configs/main/subscriptions/v2ray/super-sub.txt",
            fallbackUrls = listOf("https://cdn.jsdelivr.net/gh/MatinGhanbari/v2ray-configs@main/subscriptions/v2ray/super-sub.txt")
        )
    )

    private const val PREFS = "bepar_remote_feed_state"
    private const val KEY_LAST_SUCCESS = "last_success_at"
    private const val KEY_LAST_ATTEMPT = "last_attempt_at"
    private const val KEY_STATUS = "source_status_v1"
    private const val KEY_POLICY = "feed_policy_version"
    private const val POLICY_VERSION = 3
    /** Candidates converted per feed before probing; only the live, fastest few are stored. */
    private const val CANDIDATE_POOL_PER_SOURCE = 200
    private const val NO_LIMIT_TIMEOUT_MS = 2_500

    fun lastSuccessfulRefresh(context: Context): Long =
        prefs(context).getLong(KEY_LAST_SUCCESS, 0L)

    fun lastAttempt(context: Context): Long =
        prefs(context).getLong(KEY_LAST_ATTEMPT, 0L)

    /** True once after an update that changed how servers are selected, so old long lists get pruned. */
    fun needsPolicyMigration(context: Context): Boolean =
        prefs(context).getInt(KEY_POLICY, 0) != POLICY_VERSION

    fun isRefreshDue(context: Context, now: Long = System.currentTimeMillis()): Boolean {
        if (needsPolicyMigration(context)) return true
        val hasFeedServers = NodeStore.load(context).any { node -> sources.any { it.url == node.subscriptionUrl } }
        if (!hasFeedServers) return true
        // With auto-update off, only an empty list triggers a download; the Refresh button always works.
        if (!AppPreferences.autoUpdate(context)) return false
        val last = lastSuccessfulRefresh(context)
        val interval = TimeUnit.MINUTES.toMillis(AppPreferences.updateIntervalMinutes(context).toLong())
        return last <= 0L || now - last >= interval
    }

    fun sourceStatuses(context: Context): List<RemoteConfigSourceStatus> {
        val raw = prefs(context).getString(KEY_STATUS, null) ?: return sources.map {
            RemoteConfigSourceStatus(it.id, it.title, 0, 0L, null)
        }
        val stored = runCatching {
            val array = JSONArray(raw)
            buildMap {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    if (id.isNotBlank()) put(
                        id,
                        RemoteConfigSourceStatus(
                            id = id,
                            title = item.optString("title"),
                            profileCount = item.optInt("profileCount", 0).coerceAtLeast(0),
                            lastSuccessAt = item.optLong("lastSuccessAt", 0L).coerceAtLeast(0L),
                            lastError = item.optString("lastError").takeIf { it.isNotBlank() },
                            bestPingMillis = item.optLong("bestPingMillis", 0L).coerceAtLeast(0L)
                        )
                    )
                }
            }
        }.getOrDefault(emptyMap())
        return sources.map { source ->
            stored[source.id] ?: RemoteConfigSourceStatus(source.id, source.title, 0, 0L, null)
        }
    }

    /** Blocking; call from Dispatchers.IO, a Worker, or the VPN service worker thread. */
    @Synchronized
    fun refreshAll(context: Context, physicalNetwork: Network? = null): RemoteConfigRefreshResult {
        val oldStatuses = sourceStatuses(context).associateBy { it.id }.toMutableMap()
        NodeStore.markBuiltInBySubscriptionUrls(context, sources.map { it.url }.toSet())
        if (needsPolicyMigration(context)) {
            // Older app versions stored TCP handshake times as if they were VPN ping values.
            // Remove those values; only native Xray outbound probes may populate pingMillis now.
            NodeStore.clearPingMeasurements(context)
        }
        val perSource = AppPreferences.serversPerSource(context)
        val maxPing = AppPreferences.maxPingMillis(context)
        // A TCP connect that takes longer than the limit counts as "not good enough", so the
        // limit doubles as the probe timeout (and dead hosts cost less waiting time).
        val connectTimeout = if (maxPing == 0) NO_LIMIT_TIMEOUT_MS else maxPing.coerceIn(300, NO_LIMIT_TIMEOUT_MS)

        // 1) Download each feed and convert a random sample. Servers kept from the previous
        //    refresh are re-tested too, so good ones stay instead of being swapped every time.
        val previousByUrl = NodeStore.load(context)
            .filter { !it.subscriptionUrl.isNullOrBlank() }
            .groupBy { it.subscriptionUrl.orEmpty() }
        val candidates = LinkedHashMap<String, List<ServerNode>>()
        val failures = HashMap<String, String>()
        sources.forEach { source ->
            try {
                val result = importSourceWithMirror(source, physicalNetwork)
                val fresh = result.nodes.filter { it.host.isNotBlank() && it.outboundJson.isNotBlank() }
                val pool = (fresh + previousByUrl[source.url].orEmpty()).distinctBy { it.outboundJson }
                require(pool.isNotEmpty()) { "The source returned no supported profiles." }
                candidates[source.url] = pool
            } catch (error: Exception) {
                failures[source.id] = (error.message ?: error.javaClass.simpleName).take(160)
            }
        }

        // 2) Use TCP only as a cheap reachability hint for TCP transports. This is not a VPN ping.
        val firstPass = BestServerSelector.probeGroups(candidates, physicalNetwork, connectTimeout)
        val shortlist = candidates.mapValues { (url, pool) ->
            val tcpCandidates = firstPass[url].orEmpty().take(perSource * 2).map { it.node }
            val udpCandidates = pool.filter(::isUdpCandidate).take(2)
            (tcpCandidates + udpCandidates).distinctBy { it.outboundJson }
        }.filterValues { it.isNotEmpty() }
        val secondPass = BestServerSelector.probeGroups(
            shortlist, physicalNetwork, connectTimeout, BestServerSelector.FEED_CONFIRM_BUDGET_MS
        )
        val confirmed = LinkedHashMap<String, List<Pair<ServerNode, Long>>>()
        candidates.keys.forEach { url ->
            val firstById = firstPass[url].orEmpty().associateBy { it.node.id }
            confirmed[url] = secondPass[url].orEmpty()
                .mapNotNull { probe ->
                    val a = firstById[probe.node.id]?.latencyMillis ?: return@mapNotNull null
                    val b = probe.latencyMillis ?: return@mapNotNull null
                    probe.node to ((a + b) / 2L).coerceAtLeast(1L)
                }
                .sortedBy { it.second }
        }

        // 3) Keep the best few per feed (a server is stored once, under the first feed that has it).
        val successfulUpdates = linkedMapOf<String, List<ServerNode>>()
        val seen = HashSet<String>()
        val stamped = System.currentTimeMillis()
        var successfulSources = 0
        var failedSources = 0
        var imported = 0

        sources.forEach { source ->
            val confirmedTcp = confirmed[source.url].orEmpty().map { it.first }
            val pool = candidates[source.url].orEmpty()
            // Reserve a small share for UDP transports (Hysteria2/TUIC/WireGuard). They cannot be
            // assessed by a TCP socket handshake, but native libXray can test their real outbound.
            val udpCandidates = pool.filter(::isUdpCandidate).take(minOf(2, perSource))
            val tcpLimit = (perSource - udpCandidates.size).coerceAtLeast(0)
            val selectedTcp = confirmedTcp.take(tcpLimit)
            val selectedIds = (selectedTcp + udpCandidates).mapTo(hashSetOf()) { it.id }
            val fallback = pool.filterNot { it.id in selectedIds }
                .take((perSource - selectedTcp.size - udpCandidates.size).coerceAtLeast(0))
            val chosen = (selectedTcp + udpCandidates + fallback)
                .distinctBy { it.outboundJson }
                .take(perSource)
                .filter { seen.add(it.outboundJson) }
            val failure = failures[source.id]
            if (failure == null && chosen.isNotEmpty()) {
                // Do not persist the TCP handshake sample as a server ping. A real Xray ping is
                // measured when Auto/manual connect invokes libXray.pingBatch.
                successfulUpdates[source.url] = chosen.map { item ->
                    item.copy(pingMillis = null, pingCheckedAtMillis = null)
                }
                successfulSources++
                imported += chosen.size
                oldStatuses[source.id] = RemoteConfigSourceStatus(
                    source.id,
                    source.title,
                    chosen.size,
                    stamped,
                    null,
                    0L
                )
            } else {
                failedSources++
                val message = failure ?: "The source returned no usable candidate profiles."
                val previous = oldStatuses[source.id]
                oldStatuses[source.id] = RemoteConfigSourceStatus(
                    source.id,
                    source.title,
                    previous?.profileCount ?: 0,
                    previous?.lastSuccessAt ?: 0L,
                    message.take(160),
                    previous?.bestPingMillis ?: 0L
                )
            }
        }

        if (successfulUpdates.isNotEmpty()) {
            NodeStore.replaceSubscriptionsBatch(context, successfulUpdates)
        }

        val completed = System.currentTimeMillis()
        val combined = JSONArray()
        sources.forEach { source ->
            val status = oldStatuses[source.id] ?: RemoteConfigSourceStatus(source.id, source.title, 0, 0L, null)
            combined.put(
                JSONObject()
                    .put("id", status.id)
                    .put("title", status.title)
                    .put("profileCount", status.profileCount)
                    .put("lastSuccessAt", status.lastSuccessAt)
                    .put("lastError", status.lastError ?: "")
                    .put("bestPingMillis", status.bestPingMillis)
            )
        }
        val editor = prefs(context).edit()
            .putLong(KEY_LAST_ATTEMPT, completed)
            .putString(KEY_STATUS, combined.toString())
        if (successfulSources > 0) {
            editor.putLong(KEY_LAST_SUCCESS, completed).putInt(KEY_POLICY, POLICY_VERSION)
        }
        editor.apply()
        refreshEvents.value = refreshEvents.value + 1L

        val allProfiles = NodeStore.load(context)
        val importedTotal = allProfiles.count { node -> sources.any { it.url == node.subscriptionUrl } }
        return RemoteConfigRefreshResult(
            successfulSources = successfulSources,
            failedSources = failedSources,
            importedProfiles = imported,
            totalProfiles = importedTotal,
            completedAt = completed
        )
    }

    private fun isUdpCandidate(node: ServerNode): Boolean = runCatching {
        val protocol = node.protocol.lowercase()
        val network = JSONObject(node.outboundJson)
            .optJSONObject("streamSettings")
            ?.optString("network")
            ?.lowercase()
            .orEmpty()
        protocol in setOf("hysteria", "hysteria2", "tuic", "wireguard") ||
            network in setOf("kcp", "mkcp", "quic")
    }.getOrDefault(false)

    /** Try the canonical GitHub Raw URL first, then its HTTPS jsDelivr mirror. */
    private fun importSourceWithMirror(source: RemoteConfigSource, physicalNetwork: Network?): XrayApi.ImportResult {
        var lastError: Exception? = null
        for (endpoint in listOf(source.url) + source.fallbackUrls) {
            try {
                return XrayApi.importConfig(
                    input = endpoint,
                    physicalNetwork = physicalNetwork,
                    maxNodes = CANDIDATE_POOL_PER_SOURCE,
                    shuffle = true
                )
            } catch (error: Exception) {
                lastError = error
            }
        }
        throw IllegalStateException(
            lastError?.message ?: "The source and its HTTPS mirror are unavailable."
        )
    }

    /** Refresh only when the 15-minute freshness window has elapsed. */
    @Synchronized
    fun refreshIfDue(context: Context, physicalNetwork: Network? = null): RemoteConfigRefreshResult? =
        if (isRefreshDue(context)) refreshAll(context, physicalNetwork) else null

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
