package com.bepar.vpn.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.security.KeyStore
import java.util.UUID
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Stores profiles encrypted with an AES-256-GCM key held by Android Keystore.
 * The key itself is never written to app preferences or exported from Keystore.
 */
object NodeStore {
    private const val PREFS = "bepar_secure_store"
    private const val BLOB_KEY = "profiles_blob_v1"
    private const val KEY_ALIAS = "bepar_vpn_profiles_aes_gcm"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_TAG_BITS = 128
    private const val GCM_IV_BYTES = 12

    @Synchronized
    fun load(context: Context): List<ServerNode> {
        val blob = prefs(context).getString(BLOB_KEY, null) ?: return emptyList()
        return try {
            val root = JSONObject(decrypt(blob))
            val array = root.optJSONArray("profiles") ?: JSONArray()
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    val outbound = item.optString("outbound")
                    if (id.isBlank() || outbound.isBlank()) continue
                    add(
                        ServerNode(
                            id = id,
                            name = item.optString("name", "Unnamed server"),
                            protocol = item.optString("protocol", "xray"),
                            host = item.optString("host", ""),
                            outboundJson = outbound,
                            subscriptionTotalBytes = item.optLongOrNull("subscriptionTotalBytes"),
                            subscriptionUploadBytes = item.optLongOrNull("subscriptionUploadBytes"),
                            subscriptionDownloadBytes = item.optLongOrNull("subscriptionDownloadBytes"),
                            subscriptionExpireAtSeconds = item.optLongOrNull("subscriptionExpireAtSeconds"),
                            subscriptionFetchedAtMillis = item.optLongOrNull("subscriptionFetchedAtMillis"),
                            subscriptionUrl = item.optString("subscriptionUrl").takeIf { it.isNotBlank() },
                            pingMillis = item.optLongOrNull("pingMillis"),
                            pingCheckedAtMillis = item.optLongOrNull("pingCheckedAtMillis"),
                            origin = ServerOrigin.fromStorage(item.optString("origin", "manual")),
                            isFavorite = item.optBoolean("isFavorite", false)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            // A corrupted/invalidated Keystore key must not crash the VPN UI.
            emptyList()
        }
    }

    @Synchronized
    fun selectedId(context: Context): String? {
        val blob = prefs(context).getString(BLOB_KEY, null) ?: return null
        return try {
            JSONObject(decrypt(blob)).optString("selectedId").takeIf { it.isNotBlank() }
        } catch (_: Exception) {
            null
        }
    }

    @Synchronized
    fun selected(context: Context): ServerNode? {
        val id = selectedId(context) ?: return null
        return load(context).firstOrNull { it.id == id }
    }

    @Synchronized
    fun save(context: Context, profiles: List<ServerNode>, selectedId: String?) {
        val root = JSONObject().put("selectedId", selectedId ?: "")
        val array = JSONArray()
        profiles.forEach { profile ->
            array.put(
                JSONObject()
                    .put("id", profile.id)
                    .put("name", profile.name)
                    .put("protocol", profile.protocol)
                    .put("host", profile.host)
                    .put("outbound", profile.outboundJson)
                    .putNullableLong("subscriptionTotalBytes", profile.subscriptionTotalBytes)
                    .putNullableLong("subscriptionUploadBytes", profile.subscriptionUploadBytes)
                    .putNullableLong("subscriptionDownloadBytes", profile.subscriptionDownloadBytes)
                    .putNullableLong("subscriptionExpireAtSeconds", profile.subscriptionExpireAtSeconds)
                    .putNullableLong("subscriptionFetchedAtMillis", profile.subscriptionFetchedAtMillis)
                    .put("subscriptionUrl", profile.subscriptionUrl ?: "")
                    .putNullableLong("pingMillis", profile.pingMillis)
                    .putNullableLong("pingCheckedAtMillis", profile.pingCheckedAtMillis)
                    .put("origin", if (profile.origin == ServerOrigin.BUILT_IN) "built_in" else "manual")
                    .put("isFavorite", profile.isFavorite)
            )
        }
        root.put("profiles", array)
        val encrypted = encrypt(root.toString())
        prefs(context).edit().putString(BLOB_KEY, encrypted).apply()
    }

    @Synchronized
    fun add(
        context: Context,
        nodes: List<ServerNode>,
        incomingOrigin: ServerOrigin = ServerOrigin.MANUAL
    ): Pair<List<ServerNode>, String?> {
        val old = load(context)
        val oldByOutbound = old.associateBy { it.outboundJson }
        val incomingByOutbound = nodes.associateBy { it.outboundJson }
        val merged = LinkedHashMap<String, ServerNode>()
        old.forEach { merged[it.outboundJson] = it }
        incomingByOutbound.forEach { (outbound, fresh) ->
            val existing = oldByOutbound[outbound]
            merged[outbound] = if (existing == null) {
                fresh.copy(origin = incomingOrigin)
            } else {
                val hasFreshPlanSnapshot = fresh.subscriptionFetchedAtMillis != null
                fresh.copy(
                    id = existing.id,
                    subscriptionTotalBytes = if (hasFreshPlanSnapshot) fresh.subscriptionTotalBytes else existing.subscriptionTotalBytes,
                    subscriptionUploadBytes = if (hasFreshPlanSnapshot) fresh.subscriptionUploadBytes else existing.subscriptionUploadBytes,
                    subscriptionDownloadBytes = if (hasFreshPlanSnapshot) fresh.subscriptionDownloadBytes else existing.subscriptionDownloadBytes,
                    subscriptionExpireAtSeconds = if (hasFreshPlanSnapshot) fresh.subscriptionExpireAtSeconds else existing.subscriptionExpireAtSeconds,
                    subscriptionFetchedAtMillis = fresh.subscriptionFetchedAtMillis ?: existing.subscriptionFetchedAtMillis,
                    subscriptionUrl = fresh.subscriptionUrl ?: existing.subscriptionUrl,
                    pingMillis = fresh.pingMillis ?: existing.pingMillis,
                    pingCheckedAtMillis = fresh.pingCheckedAtMillis ?: existing.pingCheckedAtMillis,
                    origin = existing.origin,
                    isFavorite = existing.isFavorite
                )
            }
        }
        val combined = merged.values.toList()
        val previousSelection = selectedId(context)
        val newSelection = previousSelection?.takeIf { id -> combined.any { it.id == id } }
            ?: combined.firstOrNull()?.id
        save(context, combined, newSelection)
        return combined to newSelection
    }

    /**
     * Replaces the profiles owned by one subscription URL after a refresh.
     * Unrelated manually imported profiles are kept. Existing IDs are retained
     * for unchanged outbounds so the active selection remains stable.
     */
    @Synchronized
    fun replaceSubscription(
        context: Context,
        sourceUrl: String,
        incomingNodes: List<ServerNode>
    ): Pair<List<ServerNode>, String?> {
        require(sourceUrl.isNotBlank()) { "Subscription URL is missing." }
        require(incomingNodes.isNotEmpty()) { "The subscription returned no profiles." }

        val current = load(context)
        val previousSelection = selectedId(context)
        val incomingOutbounds = incomingNodes.mapTo(hashSetOf()) { it.outboundJson }
        // Include exact duplicate outbounds from older app versions which did not
        // persist subscription URLs yet. This prevents duplicate rows after upgrade.
        val ownedProfiles = current.filter {
            it.subscriptionUrl == sourceUrl || (it.subscriptionUrl.isNullOrBlank() && it.outboundJson in incomingOutbounds)
        }
        val previousByOutbound = ownedProfiles.associateBy { it.outboundJson }
        val inheritedPlan = ownedProfiles.firstOrNull { it.subscriptionUrl == sourceUrl }
            ?: ownedProfiles.firstOrNull()

        val refreshed = incomingNodes.map { fresh ->
            val old = previousByOutbound[fresh.outboundJson]
            val hasFreshPlanSnapshot = fresh.subscriptionFetchedAtMillis != null
            fresh.copy(
                id = old?.id ?: fresh.id,
                subscriptionTotalBytes = if (hasFreshPlanSnapshot) fresh.subscriptionTotalBytes else old?.subscriptionTotalBytes ?: inheritedPlan?.subscriptionTotalBytes,
                subscriptionUploadBytes = if (hasFreshPlanSnapshot) fresh.subscriptionUploadBytes else old?.subscriptionUploadBytes ?: inheritedPlan?.subscriptionUploadBytes,
                subscriptionDownloadBytes = if (hasFreshPlanSnapshot) fresh.subscriptionDownloadBytes else old?.subscriptionDownloadBytes ?: inheritedPlan?.subscriptionDownloadBytes,
                subscriptionExpireAtSeconds = if (hasFreshPlanSnapshot) fresh.subscriptionExpireAtSeconds else old?.subscriptionExpireAtSeconds ?: inheritedPlan?.subscriptionExpireAtSeconds,
                subscriptionFetchedAtMillis = fresh.subscriptionFetchedAtMillis ?: old?.subscriptionFetchedAtMillis ?: inheritedPlan?.subscriptionFetchedAtMillis,
                subscriptionUrl = fresh.subscriptionUrl ?: sourceUrl,
                origin = old?.origin ?: fresh.origin,
                isFavorite = old?.isFavorite ?: false
            )
        }

        val ownedIds = ownedProfiles.mapTo(hashSetOf()) { it.id }
        val untouched = current.filterNot { it.id in ownedIds }
        val combined = untouched + refreshed
        val selectionFromRefreshed = ownedProfiles.firstOrNull { it.id == previousSelection }
            ?.let { previous -> refreshed.firstOrNull { it.outboundJson == previous.outboundJson }?.id }
        val newSelection = selectionFromRefreshed
            ?: previousSelection?.takeIf { id -> combined.any { it.id == id } }
            ?: refreshed.firstOrNull()?.id

        save(context, combined, newSelection)
        return combined to newSelection
    }


    /**
     * Atomically refreshes several public sources. Manual imports are preserved;
     * failed sources are omitted from updates and therefore keep their old rows.
     * Duplicate outbounds are collapsed across the refreshed feeds.
     */
    @Synchronized
    fun replaceSubscriptionsBatch(
        context: Context,
        updates: Map<String, List<ServerNode>>
    ): Pair<List<ServerNode>, String?> {
        require(updates.isNotEmpty()) { "No successful source updates were provided." }
        updates.forEach { (url, nodes) ->
            require(url.startsWith("https://", ignoreCase = true)) { "Feed URLs must use HTTPS." }
            require(nodes.isNotEmpty()) { "A feed returned no profiles." }
        }

        val current = load(context)
        val previousSelection = selectedId(context)
        val updatedUrls = updates.keys
        val refreshedOld = current.filter { it.subscriptionUrl != null && it.subscriptionUrl in updatedUrls }
        val refreshedOldIds = refreshedOld.mapTo(hashSetOf()) { it.id }
        val manualAndOther = current.filterNot { it.id in refreshedOldIds }
        val manualOutbounds = manualAndOther.mapTo(hashSetOf()) { it.outboundJson }
        val oldByOutbound = refreshedOld.associateBy { it.outboundJson }
        val resultByOutbound = LinkedHashMap<String, ServerNode>()

        for ((sourceUrl, nodes) in updates) {
            for (fresh in nodes) {
                if (fresh.outboundJson in manualOutbounds) continue
                if (resultByOutbound.containsKey(fresh.outboundJson)) continue
                val old = oldByOutbound[fresh.outboundJson]
                val hasFreshPlan = fresh.subscriptionFetchedAtMillis != null
                resultByOutbound[fresh.outboundJson] = fresh.copy(
                    id = old?.id ?: fresh.id,
                    subscriptionTotalBytes = if (hasFreshPlan) fresh.subscriptionTotalBytes else old?.subscriptionTotalBytes,
                    subscriptionUploadBytes = if (hasFreshPlan) fresh.subscriptionUploadBytes else old?.subscriptionUploadBytes,
                    subscriptionDownloadBytes = if (hasFreshPlan) fresh.subscriptionDownloadBytes else old?.subscriptionDownloadBytes,
                    subscriptionExpireAtSeconds = if (hasFreshPlan) fresh.subscriptionExpireAtSeconds else old?.subscriptionExpireAtSeconds,
                    subscriptionFetchedAtMillis = fresh.subscriptionFetchedAtMillis ?: old?.subscriptionFetchedAtMillis,
                    subscriptionUrl = sourceUrl,
                    origin = ServerOrigin.BUILT_IN,
                    isFavorite = old?.isFavorite ?: false
                )
            }
        }

        val refreshed = resultByOutbound.values.toList()
        val previousSelectedOutbound = refreshedOld.firstOrNull { it.id == previousSelection }?.outboundJson
        val selectedRefreshed = previousSelectedOutbound?.let { outbound ->
            refreshed.firstOrNull { it.outboundJson == outbound }?.id
        }
        val combined = manualAndOther + refreshed
        val selection = selectedRefreshed
            ?: previousSelection?.takeIf { id -> combined.any { it.id == id } }
            ?: refreshed.firstOrNull()?.id
        save(context, combined, selection)
        return combined to selection
    }

    /**
     * Marks profiles whose subscription URL belongs to Bepar's built-in feeds.
     * This also migrates records created before origin was stored explicitly.
     */
    @Synchronized
    fun markBuiltInBySubscriptionUrls(context: Context, feedUrls: Set<String>) {
        if (feedUrls.isEmpty()) return
        val current = load(context)
        val updated = current.map { node ->
            if (node.subscriptionUrl in feedUrls && node.origin != ServerOrigin.BUILT_IN) {
                node.copy(origin = ServerOrigin.BUILT_IN)
            } else node
        }
        if (updated != current) save(context, updated, selectedId(context))
    }

    /** Persists a user's favourite marker without changing selection or probe measurements. */
    @Synchronized
    fun setFavorite(context: Context, id: String, favorite: Boolean): List<ServerNode> {
        val current = load(context)
        if (current.none { it.id == id }) return current
        val updated = current.map { node -> if (node.id == id) node.copy(isFavorite = favorite) else node }
        save(context, updated, selectedId(context))
        return updated
    }

    /** Removes every saved profile (manual and automatic). */
    @Synchronized
    fun clearAll(context: Context) {
        save(context, emptyList(), null)
    }

    /** Store only real Xray HTTP-probe measurements. Null means the proxy probe failed. */
    @Synchronized
    fun updatePingMeasurements(
        context: Context,
        values: Map<String, Long?>,
        clearUnmeasured: Boolean = false
    ) {
        if (values.isEmpty() && !clearUnmeasured) return
        val stamp = System.currentTimeMillis()
        val current = load(context)
        val updated = current.map { node ->
            if (values.containsKey(node.id)) {
                node.copy(
                    pingMillis = values[node.id],
                    pingCheckedAtMillis = stamp
                )
            } else if (clearUnmeasured) {
                node.copy(pingMillis = null, pingCheckedAtMillis = null)
            } else node
        }
        save(context, updated, selectedId(context))
    }

    @Synchronized
    fun clearPingMeasurements(context: Context) {
        val current = load(context)
        if (current.isEmpty()) return
        save(context, current.map { it.copy(pingMillis = null, pingCheckedAtMillis = null) }, selectedId(context))
    }

    @Synchronized
    fun select(context: Context, id: String?) {
        save(context, load(context), id)
    }

    @Synchronized
    fun remove(context: Context, id: String): Pair<List<ServerNode>, String?> {
        val current = load(context).filterNot { it.id == id }
        val selection = selectedId(context).let { selected ->
            if (selected == id) current.firstOrNull()?.id else selected
        }
        save(context, current, selection)
        return current to selection
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun key(): SecretKey {
        val keyStore = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        val existing = keyStore.getKey(KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setKeySize(256)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    private fun encrypt(plainText: String): String {
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val cipherText = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
        val combined = cipher.iv + cipherText
        return Base64.encodeToString(combined, Base64.NO_WRAP)
    }

    private fun decrypt(encoded: String): String {
        val combined = Base64.decode(encoded, Base64.NO_WRAP)
        require(combined.size > GCM_IV_BYTES) { "Encrypted profile data is truncated" }
        val iv = combined.copyOfRange(0, GCM_IV_BYTES)
        val cipherText = combined.copyOfRange(GCM_IV_BYTES, combined.size)
        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(GCM_TAG_BITS, iv))
        return cipher.doFinal(cipherText).toString(Charsets.UTF_8)
    }

    fun newId(): String = UUID.randomUUID().toString()

    private fun JSONObject.optLongOrNull(key: String): Long? =
        if (has(key) && !isNull(key)) optLong(key).takeIf { it >= 0L } else null

    private fun JSONObject.putNullableLong(key: String, value: Long?): JSONObject =
        if (value != null && value >= 0L) put(key, value) else put(key, JSONObject.NULL)
}
