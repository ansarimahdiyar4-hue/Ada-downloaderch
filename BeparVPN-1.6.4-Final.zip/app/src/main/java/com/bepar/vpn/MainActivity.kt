package com.bepar.vpn

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.ComponentName
import android.app.StatusBarManager
import android.graphics.drawable.Icon
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationManagerCompat
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.acos
import kotlin.math.sqrt
import kotlin.math.cos
import kotlin.math.sin
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import com.bepar.vpn.core.TunnelProbe
import com.bepar.vpn.core.XrayApi
import com.bepar.vpn.data.AppPreferences
import com.bepar.vpn.data.AutoFeedRefreshScheduler
import com.bepar.vpn.data.BestServerSelector
import com.bepar.vpn.data.ConnectionLogEntry
import com.bepar.vpn.data.ConnectionLogStore
import com.bepar.vpn.data.NodeStore
import com.bepar.vpn.data.RemoteConfigFeedRepository
import com.bepar.vpn.data.RemoteConfigSourceStatus
import com.bepar.vpn.data.ServerNode
import com.bepar.vpn.data.ServerOrigin
import com.bepar.vpn.vpn.BeparVpnService
import com.bepar.vpn.vpn.BeparVpnTileService
import com.bepar.vpn.vpn.ConnectionState
import com.bepar.vpn.vpn.VpnPhase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay

private data class BeparThemePalette(
    val id: String,
    val background: Color,
    val deepBackground: Color,
    val panel: Color,
    val raised: Color,
    val border: Color,
    val accent: Color,
    val accentDeep: Color
)

private object BeparThemes {
    val all = listOf(
        BeparThemePalette("purple", Color(0xFF080411), Color(0xFF10071F), Color(0xFF170D29), Color(0xFF241239), Color(0xFF42245F), Color(0xFFBF55FF), Color(0xFF7624D4)),
        BeparThemePalette("blue", Color(0xFF070B14), Color(0xFF091221), Color(0xFF121B2B), Color(0xFF1A2638), Color(0xFF29384D), Color(0xFF2694FF), Color(0xFF1268F5)),
        BeparThemePalette("emerald", Color(0xFF04110E), Color(0xFF071B16), Color(0xFF0D241D), Color(0xFF14372B), Color(0xFF245744), Color(0xFF37D9A0), Color(0xFF139B71)),
        BeparThemePalette("rose", Color(0xFF15070F), Color(0xFF210B17), Color(0xFF2A1020), Color(0xFF3A172C), Color(0xFF64314C), Color(0xFFFF5FA2), Color(0xFFD52E79)),
        BeparThemePalette("amber", Color(0xFF130D05), Color(0xFF211506), Color(0xFF2B1C0A), Color(0xFF3B2810), Color(0xFF63471F), Color(0xFFFFBB55), Color(0xFFD88920)),
        BeparThemePalette("ice", Color(0xFF061018), Color(0xFF0A1B28), Color(0xFF102635), Color(0xFF193746), Color(0xFF2B5367), Color(0xFF59D8F5), Color(0xFF269ABF))
    )
    fun fromId(id: String): BeparThemePalette = all.firstOrNull { it.id == id } ?: all.first()
    fun label(id: String): String = when (id) {
        "purple" -> if (activeLanguage == "fa") "کهکشانی بنفش" else "Cosmic Purple"
        "blue" -> if (activeLanguage == "fa") "سایبر آبی" else "Cyber Blue"
        "emerald" -> if (activeLanguage == "fa") "زمردی" else "Emerald"
        "rose" -> if (activeLanguage == "fa") "رز نئونی" else "Neon Rose"
        "amber" -> if (activeLanguage == "fa") "کهربایی" else "Amber"
        else -> if (activeLanguage == "fa") "یخی" else "Arctic Ice"
    }
}

private var activePalette by mutableStateOf(BeparThemes.fromId("purple"))
private var activeLanguage by mutableStateOf("fa")
private val Night: Color get() = activePalette.background
private val DeepBlue: Color get() = activePalette.deepBackground
private val Panel: Color get() = activePalette.panel
private val PanelRaised: Color get() = activePalette.raised
private val PanelBorder: Color get() = activePalette.border
private val Cyan: Color get() = activePalette.accent
private val Blue: Color get() = activePalette.accentDeep
private val Mint = Color(0xFF26DE79)
private val Muted = Color(0xFFAAA1BD)
private val Danger = Color(0xFFFF6178)
private val Warning = Color(0xFFFFC46B)

private val faUiText = mapOf(
    "Home" to "خانه", "Servers" to "سرورها", "Logs" to "گزارش‌ها", "Settings" to "تنظیمات",
    "SECURE CONNECTION" to "اتصال امن", "Connection logs" to "گزارش اتصال", "events" to "رویداد",
    "Disconnect" to "قطع اتصال", "Cancel" to "لغو",
    "Tap to Connect" to "برای اتصال لمس کنید", "Connected" to "متصل هستید", "Connecting…" to "در حال اتصال…",
    "Switching server…" to "در حال تغییر سرور…", "Connection failed" to "اتصال ناموفق بود", "Not connected" to "متصل نیست",
    "Tap to connect automatically" to "برای اتصال خودکار لمس کنید", "Server" to "سرور", "Selected server" to "سرور انتخاب‌شده",
    "Change" to "تغییر", "Auto • best available" to "خودکار • بهترین سرور", "No server selected" to "سروری انتخاب نشده",
    "Add a server profile" to "یک پروفایل سرور اضافه کنید", "Updates sources, tests servers and verifies internet" to "منابع را به‌روز و سرورها را آزمایش می‌کند",
    "SERVERS" to "سرورها", "PROTOCOL" to "پروتکل", "USAGE" to "مصرف", "Refresh plan" to "به‌روزرسانی اشتراک",
    "AUTO SERVER" to "سرور خودکار", "THIS SESSION" to "این نشست", "Session traffic · estimate" to "ترافیک این نشست · تخمینی",
    "AUTO" to "خودکار", "MANUAL" to "دستی", "All servers" to "همه سرورها", "Add server" to "افزودن سرور",
    "App servers" to "سرورهای بپر", "Manual servers" to "سرورهای دستی", "No app servers yet" to "هنوز سرور برنامه دریافت نشده",
    "No manual servers yet" to "هنوز کانفیگ دستی اضافه نشده", "App-managed public feed servers" to "سرورهای دریافت‌شده از منابع خودکار برنامه",
    "Your imported configurations stay here" to "کانفیگ‌هایی که خودت وارد می‌کنی اینجا نگه‌داری می‌شوند",
    "No servers" to "سروری وجود ندارد", "AUTO SOURCES" to "منابع خودکار", "sources ready" to "منبع آماده",
    "Search servers" to "جستجوی سرورها", "All" to "همه", "Favorites" to "علاقه‌مندی‌ها",
    "Sort by" to "مرتب‌سازی", "Lowest latency" to "کمترین تأخیر", "Name A–Z" to "نام از الف تا ی",
    "Protocol" to "پروتکل", "No favorite servers" to "هنوز سرور علاقه‌مندی ثبت نشده",
    "No matching servers" to "سروری با این جستجو پیدا نشد", "Favorite server" to "سرور علاقه‌مندی",
    "Updating" to "در حال به‌روزرسانی", "Refresh" to "تازه‌سازی", "Cached · retry" to "ذخیره‌شده · تلاش مجدد",
    "Unavailable" to "در دسترس نیست", "Pending" to "در انتظار", "Last update" to "آخرین به‌روزرسانی",
    "Server list will be downloaded on first Auto connect." to "فهرست سرورها هنگام اولین اتصال خودکار دریافت می‌شود.",
    "Server link or configuration" to "لینک یا کانفیگ سرور", "From file" to "از فایل", "Importing…" to "در حال وارد کردن…",
    "Import" to "وارد کردن", "ACTIVE" to "فعال", "Test latency + download" to "تست تأخیر و دانلود",
    "Testing…" to "در حال آزمایش…", "Recent activity" to "فعالیت‌های اخیر", "Clear" to "پاک کردن",
    "No activity yet" to "هنوز فعالیتی ثبت نشده", "CONNECTION" to "اتصال", "Auto reconnect" to "اتصال مجدد خودکار",
    "Restore after network changes" to "بازیابی اتصال پس از تغییر شبکه", "Connect on app start" to "اتصال هنگام اجرای برنامه",
    "Uses Auto or your selected server" to "استفاده از حالت خودکار یا سرور انتخابی", "Operator compatibility" to "سازگاری با اپراتور",
    "Adapts to Hamrah-e Aval, Irancell, Rightel, Shatel, Wi-Fi…" to "تنظیم اتصال برای اپراتورها و وای‌فای",
    "DNS server" to "سرور DNS", "Apps that bypass VPN" to "برنامه‌های خارج از VPN", "None — every app uses the VPN" to "هیچ‌کدام؛ همه برنامه‌ها از VPN استفاده می‌کنند",
    "Choose" to "انتخاب", "SERVERS" to "سرورها", "Auto-update servers" to "به‌روزرسانی خودکار سرورها",
    "Refresh the public lists in the background" to "به‌روزرسانی فهرست‌های عمومی در پس‌زمینه", "Update interval" to "بازه به‌روزرسانی",
    "Android may delay background runs" to "ممکن است اندروید اجرای پس‌زمینه را به تأخیر بیندازد", "Servers per source" to "تعداد سرور از هر منبع",
    "Keep a balanced set of candidates; Auto verifies real Xray reachability" to "مجموعه‌ای متعادل از سرورها نگه‌داری می‌شود؛ حالت خودکار اتصال واقعی Xray را می‌سنجد", "TCP screening timeout" to "مهلت بررسی TCP",
    "Skip servers slower than this (TCP connect)" to "سرورهای کندتر از این مقدار نادیده گرفته می‌شوند", "Clear all servers" to "حذف همه سرورها",
    "Remove every saved server from this device" to "تمام سرورهای ذخیره‌شده از دستگاه حذف می‌شوند", "PERMISSIONS" to "دسترسی‌ها",
    "VPN access" to "دسترسی VPN", "Required" to "ضروری", "Allowed" to "مجاز است", "Allow" to "اجازه دادن",
    "Notifications" to "اعلان‌ها", "Optional" to "اختیاری", "Enable" to "فعال‌سازی", "ANDROID" to "اندروید",
    "Quick Settings switch" to "کلید تنظیمات سریع", "Connect from the notification shade" to "اتصال از پنل اعلان‌ها",
    "Battery optimization" to "بهینه‌سازی باتری", "Keep the tunnel alive in the background" to "فعال نگه داشتن تونل در پس‌زمینه",
    "Always-on VPN" to "VPN همیشه‌فعال", "Android system setting" to "تنظیمات سیستمی اندروید", "Notification settings" to "تنظیمات اعلان‌ها",
    "Manage alerts" to "مدیریت هشدارها", "App permissions" to "مجوزهای برنامه", "ABOUT" to "درباره برنامه",
    "Application" to "برنامه", "Version" to "نسخه", "Saved servers" to "سرورهای ذخیره‌شده", "Engine" to "موتور اتصال",
    "Auto sources" to "منابع خودکار", "Kept per source" to "نگهداری از هر منبع", "Refresh" to "به‌روزرسانی",
    "Appearance" to "ظاهر برنامه", "Personalization" to "شخصی‌سازی", "Theme" to "قالب رنگی", "Language" to "زبان",
    "Choose the app color palette" to "رنگ و حال‌وهوای برنامه را انتخاب کنید", "Choose the display language" to "زبان نمایش برنامه را انتخاب کنید",
    "Start screen" to "صفحه آغازین", "Choose which screen opens first" to "مشخص کنید برنامه با کدام صفحه باز شود",
    "Default start screen" to "صفحه پیش‌فرض شروع", "Persian" to "فارسی", "English" to "انگلیسی",
    "Saved" to "ذخیره شد", "Home screen" to "خانه", "Server list" to "فهرست سرورها", "Connection history" to "تاریخچه اتصال",
    "Fast • Secure • Unlimited" to "سریع • امن • نامحدود",
    "CONNECTION" to "اتصال", "PERMISSIONS" to "دسترسی‌ها", "ANDROID" to "اندروید", "APPEARANCE" to "ظاهر",
    "Connecting" to "در حال اتصال", "Reconnecting" to "اتصال مجدد", "Connection error" to "خطای اتصال", "Disconnected" to "قطع‌شده",
    "DNS server" to "سرور DNS", "Standard" to "استاندارد", "Anti-filter" to "ضد فیلترینگ", "Strong" to "قوی", "Auto" to "خودکار",
    "No limit" to "بدون محدودیت", "Session time" to "مدت این نشست", "No server" to "بدون سرور",
    "Download sample unavailable" to "نمونه دانلود در دسترس نیست", "Server link or configuration" to "لینک یا کانفیگ سرور",
    "Upload" to "آپلود", "Download" to "دانلود", "VPN traffic • Xray" to "ترافیک VPN • موتور Xray",
    "From file" to "از فایل", "Search apps" to "جستجوی برنامه‌ها", "Checked apps connect directly, outside the tunnel." to "برنامه‌های انتخاب‌شده بدون عبور از تونل متصل می‌شوند.",
    "Apps that bypass VPN" to "برنامه‌های خارج از VPN", "Save" to "ذخیره", "Delete profile?" to "حذف پروفایل؟",
    "Clear all servers?" to "همه سرورها حذف شوند؟", "Every saved server, including ones you added yourself, is removed from this device. Auto sources can download new ones." to "تمام سرورهای ذخیره‌شده از این دستگاه حذف می‌شوند. منابع خودکار می‌توانند سرورهای جدید دریافت کنند.",
    "Delete" to "حذف", "Keep Bepar VPN running" to "فعال نگه داشتن بپر وی‌پی‌ان", "Allow notifications" to "اجازه اعلان‌ها",
    "Disable battery saver" to "غیرفعال کردن محدودیت باتری", "Get started" to "شروع کنید", "One tap. Fastest working server." to "یک لمس؛ سریع‌ترین سرور قابل‌اتصال.",
    "Auto mode" to "حالت خودکار", "Collects public servers, tests them and keeps only one that really has internet." to "سرورهای عمومی را جمع‌آوری و آزمایش می‌کند و سرور دارای اینترنت را انتخاب می‌کند.",
    "Your own servers" to "سرورهای اختصاصی شما", "Import VLESS, VMess, Trojan, Shadowsocks links or a subscription URL." to "لینک‌های VLESS، VMess، Trojan، Shadowsocks یا لینک اشتراک را وارد کنید.",
    "Private by design" to "حریم خصوصی", "Profiles are encrypted on this device. No accounts, no tracking." to "پروفایل‌ها روی این دستگاه رمزگذاری می‌شوند؛ بدون حساب کاربری و ردیابی.",
    "SECURING THE TUNNEL" to "در حال ایمن‌سازی تونل", "FINDING THE FASTEST ROUTE" to "در حال یافتن سریع‌ترین مسیر", "READY" to "آماده",
    "Engine" to "موتور اتصال", "Application" to "برنامه", "Saved servers" to "سرورهای ذخیره‌شده", "Auto sources" to "منابع خودکار",
    "Quick Settings switch" to "کلید تنظیمات سریع", "Battery optimization" to "بهینه‌سازی باتری", "Always-on VPN" to "VPN همیشه‌فعال",
    "Notification settings" to "تنظیمات اعلان‌ها", "App permissions" to "مجوزهای برنامه", "Quick Settings" to "تنظیمات سریع",
    "Open" to "باز کردن", "Add" to "افزودن", "Enable" to "فعال‌سازی", "Optional" to "اختیاری", "Required" to "ضروری",
    "Connect from the notification shade" to "اتصال از پنل اعلان‌ها", "Keep the tunnel alive in the background" to "فعال نگه داشتن تونل در پس‌زمینه",
    "Android system setting" to "تنظیمات سیستمی اندروید", "Manage alerts" to "مدیریت هشدارها", "App permissions" to "مجوزهای برنامه",
    "Start screen" to "صفحه آغازین", "Choose which screen opens first" to "انتخاب صفحه‌ای که با اجرای برنامه باز می‌شود",
    "Appearance" to "ظاهر برنامه", "Choose the app color palette" to "رنگ و جلوه بصری برنامه را انتخاب کنید", "Choose the display language" to "زبان نمایش را انتخاب کنید",
    "Home screen" to "صفحه خانه", "Server list" to "فهرست سرورها", "Connection history" to "تاریخچه اتصال",
    "Provider quota" to "سهمیه ارائه‌دهنده", "Plan data left" to "حجم باقی‌مانده اشتراک", "Provider expiry" to "انقضای سرویس", "Time left" to "زمان باقی‌مانده",
    "Unlimited" to "نامحدود", "Not provided" to "ارائه نشده", "No expiry" to "بدون انقضا", "Expired" to "منقضی‌شده",
    "Done" to "انجام شد", "Later" to "بعداً", "Disable" to "غیرفعال‌سازی", "No server" to "بدون سرور",
    "Tap to Connect" to "برای اتصال لمس کنید", "Add a server profile" to "افزودن پروفایل سرور",
    "VPN is connected" to "VPN متصل است", "VPN connected" to "VPN متصل شد", "Connecting to server" to "در حال اتصال به سرور",
    "VPN disconnected" to "VPN قطع شد", "Reconnect" to "اتصال مجدد", "Connection failed" to "اتصال ناموفق بود",
    "Manual only" to "فقط دستی"
)

private fun uiText(value: String): String {
    if (activeLanguage != "fa") return value
    faUiText[value]?.let { return it }
    Regex("^(\\d+) min$").matchEntire(value)?.let { return "${it.groupValues[1]} دقیقه" }
    Regex("^(\\d+) h$").matchEntire(value)?.let { return "${it.groupValues[1]} ساعت" }
    Regex("^(\\d+) ms$").matchEntire(value)?.let { return "${it.groupValues[1]} میلی‌ثانیه" }
    Regex("^(\\d+) app\\(s\\) connect directly$").matchEntire(value)?.let { return "${it.groupValues[1]} برنامه مستقیماً متصل می‌شوند" }
    Regex("^(\\d+) public feeds$").matchEntire(value)?.let { return "${it.groupValues[1]} منبع عمومی" }
    Regex("^(\\d+) profiles$").matchEntire(value)?.let { return "${it.groupValues[1]} پروفایل" }
    Regex("^Every (\\d+ min|\\d+ h)$").matchEntire(value)?.let { return "هر ${uiText(it.groupValues[1])}" }
    return value
}

class MainActivity : ComponentActivity() {
    private val quickConnectRequest = mutableStateOf(false)

    companion object {
        const val ACTION_QUICK_CONNECT = "com.bepar.vpn.action.QUICK_CONNECT"
    }

    // The system splash (logo on the app's night background) stays up until Compose has drawn
    // its first frame, so the user never sees the plain black window between tap and UI.
    private var firstFrameReady = false

    override fun onCreate(savedInstanceState: Bundle?) {
        val launchedAt = android.os.SystemClock.uptimeMillis()
        val splash = installSplashScreen()
        splash.setKeepOnScreenCondition {
            !firstFrameReady && android.os.SystemClock.uptimeMillis() - launchedAt < 1500L
        }
        super.onCreate(savedInstanceState)
        quickConnectRequest.value = intent?.action == ACTION_QUICK_CONNECT
        activePalette = BeparThemes.fromId(AppPreferences.themeId(this))
        activeLanguage = AppPreferences.language(this)
        window.statusBarColor = android.graphics.Color.rgb(8, 4, 17)
        window.navigationBarColor = android.graphics.Color.rgb(8, 4, 17)
        WindowCompat.getInsetsController(window, window.decorView).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
        if (AppPreferences.isVpnActive(this)) {
            ConnectionState.update(VpnPhase.CONNECTED, "VPN is connected")
        }
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Cyan,
                    onPrimary = Color(0xFF090512),
                    secondary = Mint,
                    background = Night,
                    surface = Panel,
                    surfaceVariant = PanelRaised,
                    onSurface = Color(0xFFF4F7FC),
                    onSurfaceVariant = Muted,
                    error = Danger
                )
            ) {
                CompositionLocalProvider(LocalLayoutDirection provides (if (activeLanguage == "fa") LayoutDirection.Rtl else LayoutDirection.Ltr)) {
                    BeparApp(
                        launchQuickConnect = quickConnectRequest.value,
                        onQuickConnectConsumed = { quickConnectRequest.value = false },
                        onFirstFrame = { firstFrameReady = true }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent.action == ACTION_QUICK_CONNECT) quickConnectRequest.value = true
    }
}

private const val AUTO_ID = "__auto__"

private enum class AppTab { HOME, PROFILES, LOGS, SETTINGS }

private fun tabIndex(name: String): Int = runCatching { AppTab.valueOf(name).ordinal }.getOrDefault(0)

@Composable
private fun BeparApp(launchQuickConnect: Boolean, onQuickConnectConsumed: () -> Unit, onFirstFrame: () -> Unit = {}) {
    val context = LocalContext.current
    LaunchedEffect(Unit) { onFirstFrame() }
    val scope = rememberCoroutineScope()
    val vpnState by ConnectionState.state.collectAsState()
    var profiles by remember { mutableStateOf(NodeStore.load(context)) }
    var selectedId by remember { mutableStateOf(NodeStore.selectedId(context)) }
    var activeTab by remember { mutableStateOf(AppPreferences.startTab(context)) }
    var themeId by remember { mutableStateOf(AppPreferences.themeId(context)) }
    var language by remember { mutableStateOf(AppPreferences.language(context)) }
    var startTab by remember { mutableStateOf(AppPreferences.startTab(context)) }
    var importText by rememberSaveable { mutableStateOf("") }
    var isImporting by remember { mutableStateOf(false) }
    var showImport by rememberSaveable { mutableStateOf(false) }
    var deleteTarget by remember { mutableStateOf<ServerNode?>(null) }
    var pendingNodeId by remember { mutableStateOf<String?>(null) }
    var permissionRevision by remember { mutableIntStateOf(0) }
    var autoReconnect by remember { mutableStateOf(AppPreferences.autoReconnect(context)) }
    var dnsHost by remember { mutableStateOf(AppPreferences.dnsHost(context)) }
    var compatMode by remember { mutableStateOf(AppPreferences.compatMode(context)) }
    var feedStatuses by remember { mutableStateOf(RemoteConfigFeedRepository.sourceStatuses(context)) }
    val feedRefreshRevision by RemoteConfigFeedRepository.refreshEvents.collectAsState()
    var isRefreshingFeeds by remember { mutableStateOf(false) }
    var autoMode by remember { mutableStateOf(AppPreferences.autoMode(context)) }
    var autoUpdate by remember { mutableStateOf(AppPreferences.autoUpdate(context)) }
    var updateInterval by remember { mutableIntStateOf(AppPreferences.updateIntervalMinutes(context)) }
    var serversPerSource by remember { mutableIntStateOf(AppPreferences.serversPerSource(context)) }
    var maxPing by remember { mutableIntStateOf(AppPreferences.maxPingMillis(context)) }
    var connectOnStart by remember { mutableStateOf(AppPreferences.connectOnStart(context)) }
    var bypassApps by remember { mutableStateOf(AppPreferences.bypassApps(context)) }
    var showBypassDialog by remember { mutableStateOf(false) }
    var showClearDialog by remember { mutableStateOf(false) }
    val firstRun = remember { !AppPreferences.landingSeen(context) }
    // The welcome screen (globe) is shown only on the very first launch, never again.
    var showLanding by rememberSaveable { mutableStateOf(firstRun && !launchQuickConnect) }
    // Every later launch gets a short branded loading screen instead.
    var showSplash by rememberSaveable { mutableStateOf(!firstRun && !launchQuickConnect) }
    var showSetup by rememberSaveable { mutableStateOf(false) }
    val batteryLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { permissionRevision++ }

    fun startSelectedNode(nodeId: String) {
        val intent = Intent(context, BeparVpnService::class.java).apply {
            if (nodeId == AUTO_ID) {
                action = BeparVpnService.ACTION_CONNECT_BEST
            } else {
                action = BeparVpnService.ACTION_CONNECT
                putExtra(BeparVpnService.EXTRA_NODE_ID, nodeId)
            }
        }
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (error: Exception) {
            Toast.makeText(context, error.message ?: "Could not start the VPN service.", Toast.LENGTH_LONG).show()
        }
    }

    val vpnPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        val nodeId = pendingNodeId
        pendingNodeId = null
        permissionRevision++
        if (result.resultCode == Activity.RESULT_OK) {
            if (!nodeId.isNullOrBlank()) startSelectedNode(nodeId)
            else Toast.makeText(context, "VPN access is ready.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(context, "VPN permission was not granted.", Toast.LENGTH_LONG).show()
        }
    }

    fun requestVpnPermission(forNodeId: String? = null) {
        pendingNodeId = forNodeId
        val prepareIntent = VpnService.prepare(context)
        if (prepareIntent == null) {
            val nodeId = pendingNodeId
            pendingNodeId = null
            if (!nodeId.isNullOrBlank()) startSelectedNode(nodeId)
            else Toast.makeText(context, "VPN access is already enabled.", Toast.LENGTH_SHORT).show()
        } else {
            vpnPermissionLauncher.launch(prepareIntent)
        }
    }

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        permissionRevision++
        if (!granted) Toast.makeText(context, "Notifications disabled.", Toast.LENGTH_SHORT).show()
    }

    fun connect() {
        val id = selectedId
        if (id.isNullOrBlank() || profiles.none { it.id == id }) {
            Toast.makeText(context, "Add a server first.", Toast.LENGTH_SHORT).show()
            activeTab = AppTab.PROFILES.name
            return
        }
        // VPN approval is mandatory. Notification permission is optional and is
        // deliberately requested only from Settings so it never blocks connection.
        requestVpnPermission(id)
    }

    // Auto: the VPN service refreshes the public feeds, ranks servers, starts the best
    // ones and VERIFIES real internet through the tunnel, skipping dead servers.
    fun connectToBestServer() {
        if (vpnState.phase == VpnPhase.CONNECTING || vpnState.phase == VpnPhase.RECONNECTING) return
        requestVpnPermission(AUTO_ID)
    }

    fun refreshAllSources() {
        if (isRefreshingFeeds) return
        scope.launch {
            isRefreshingFeeds = true
            try {
                val network = withContext(Dispatchers.IO) {
                    BestServerSelector.findPhysicalNetwork(context)
                }
                val result = withContext(Dispatchers.IO) {
                    RemoteConfigFeedRepository.refreshAll(context, network)
                }
                profiles = NodeStore.load(context)
                selectedId = NodeStore.selectedId(context)
                feedStatuses = RemoteConfigFeedRepository.sourceStatuses(context)
                val message = if (result.hasSuccess) {
                    "Updated ${result.successfulSources}/${RemoteConfigFeedRepository.sources.size} sources • ${result.importedProfiles} candidate profiles saved."
                } else {
                    "No source returned usable profiles. Existing saved servers were kept."
                }
                Toast.makeText(context, message, Toast.LENGTH_LONG).show()
            } catch (error: Exception) {
                Toast.makeText(context, error.message ?: "Could not refresh server sources.", Toast.LENGTH_LONG).show()
            } finally {
                isRefreshingFeeds = false
                feedStatuses = RemoteConfigFeedRepository.sourceStatuses(context)
            }
        }
    }

    fun refreshSubscriptionPlan() {
        val url = profiles.firstOrNull { it.id == selectedId }?.subscriptionUrl
        if (url.isNullOrBlank()) {
            Toast.makeText(context, "This profile has no subscription URL.", Toast.LENGTH_SHORT).show()
            return
        }
        scope.launch {
            try {
                val previousSelection = selectedId
                val refreshed = withContext(Dispatchers.IO) { XrayApi.importConfig(url) }
                val sourceUrl = refreshed.nodes.firstOrNull()?.subscriptionUrl
                    ?: throw IllegalStateException("The subscription URL could not be identified.")
                val (updated, selected) = NodeStore.replaceSubscription(context, sourceUrl, refreshed.nodes)
                profiles = updated
                selectedId = selected
                if (selected != null && selected != previousSelection &&
                    (vpnState.phase == VpnPhase.CONNECTED || vpnState.phase == VpnPhase.CONNECTING || vpnState.phase == VpnPhase.RECONNECTING)
                ) {
                    startSelectedNode(selected)
                }
                if (refreshed.subscriptionInfoAvailable) {
                    Toast.makeText(context, "Plan details updated.", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "Provider did not return plan details.", Toast.LENGTH_LONG).show()
                }
            } catch (error: Exception) {
                Toast.makeText(context, error.message ?: "Could not refresh subscription.", Toast.LENGTH_LONG).show()
            }
        }
    }

    LaunchedEffect(launchQuickConnect) {
        if (launchQuickConnect) {
            onQuickConnectConsumed()
            connectToBestServer()
        }
    }

    fun requestQuickSettingsTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            val statusBar = context.getSystemService(StatusBarManager::class.java)
            if (statusBar == null) {
                Toast.makeText(context, "Quick Settings tile is not supported on this device.", Toast.LENGTH_LONG).show()
            } else {
                runCatching {
                    statusBar.requestAddTileService(
                        ComponentName(context, BeparVpnTileService::class.java),
                        "Bepar VPN",
                        Icon.createWithResource(context, R.drawable.ic_qs_bepar_vpn),
                        context.mainExecutor
                    ) { result ->
                        val message = when (result) {
                            StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED -> "Bepar VPN tile added."
                            StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ALREADY_ADDED -> "Bepar VPN tile is already added."
                            else -> "Quick Settings tile was not added."
                        }
                        Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
                    }
                }.onFailure {
                    Toast.makeText(context, it.message ?: "Could not request the Quick Settings tile.", Toast.LENGTH_LONG).show()
                }
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            Toast.makeText(context, "Open Quick Settings, tap Edit, then add Bepar VPN.", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(context, "Quick Settings tiles require Android 7.0 or later.", Toast.LENGTH_LONG).show()
        }
    }

    fun disconnect() {
        val intent = Intent(context, BeparVpnService::class.java).apply {
            action = BeparVpnService.ACTION_DISCONNECT
        }
        context.startService(intent)
    }

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                try {
                    importText = withContext(Dispatchers.IO) { readConfigFile(context, uri) }
                    showImport = true
                } catch (error: Exception) {
                    Toast.makeText(context, error.message ?: "Could not read this file.", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun importProfiles() {
        if (isImporting || importText.isBlank()) return
        isImporting = true
        scope.launch {
            try {
                val imported = withContext(Dispatchers.IO) { XrayApi.importConfig(importText) }
                val (updated, selected) = NodeStore.add(context, imported.nodes, ServerOrigin.MANUAL)
                profiles = updated
                selectedId = selected
                importText = ""
                showImport = false
                val message = if (imported.subscriptionInfoAvailable) {
                    "Added ${imported.nodes.size} profile(s) with plan details."
                } else {
                    "Added ${imported.nodes.size} profile(s)."
                }
                Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
            } catch (error: Exception) {
                Toast.makeText(context, error.message?.take(220) ?: "Could not import this configuration.", Toast.LENGTH_LONG).show()
            } finally {
                isImporting = false
            }
        }
    }

    val selectedNode = profiles.firstOrNull { it.id == selectedId }
    val isVpnBusy = vpnState.phase == VpnPhase.CONNECTING || vpnState.phase == VpnPhase.RECONNECTING
    var logEntries by remember { mutableStateOf(ConnectionLogStore.load(context)) }
    var sessionUsage by remember { mutableStateOf(AppPreferences.sessionUsage(context)) }

    var startupHandled by rememberSaveable { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        if (startupHandled) return@LaunchedEffect
        startupHandled = true
        if (launchQuickConnect || !AppPreferences.connectOnStart(context)) return@LaunchedEffect
        if (AppPreferences.isVpnActive(context) || AppPreferences.isVpnConnecting(context)) return@LaunchedEffect
        // Without an earlier VPN approval Android needs a dialog; never pop one up on launch.
        if (VpnService.prepare(context) != null) return@LaunchedEffect
        if (AppPreferences.autoMode(context)) {
            startSelectedNode(AUTO_ID)
        } else {
            NodeStore.selectedId(context)?.let { startSelectedNode(it) }
        }
    }
    LaunchedEffect(feedRefreshRevision) {
        if (feedRefreshRevision > 0L) {
            profiles = NodeStore.load(context)
            selectedId = NodeStore.selectedId(context)
            feedStatuses = RemoteConfigFeedRepository.sourceStatuses(context)
        }
    }
    LaunchedEffect(Unit) {
        feedStatuses = RemoteConfigFeedRepository.sourceStatuses(context)
        if (AppPreferences.isVpnActive(context)) {
            ConnectionState.update(VpnPhase.CONNECTED, "VPN is connected")
        }
    }
    LaunchedEffect(vpnState.phase) {
        if (vpnState.phase == VpnPhase.CONNECTED || vpnState.phase == VpnPhase.ERROR) {
            profiles = NodeStore.load(context)
            selectedId = NodeStore.selectedId(context)
        }
    }
    LaunchedEffect(vpnState.phase) {
        while (true) {
            sessionUsage = AppPreferences.sessionUsage(context)
            delay(1_500)
        }
    }

    LaunchedEffect(vpnState.phase, vpnState.message) {
        val eventText = when (vpnState.phase) {
            VpnPhase.CONNECTED -> "VPN connected"
            VpnPhase.CONNECTING -> "Connecting to server"
            VpnPhase.RECONNECTING -> "Reconnecting"
            VpnPhase.DISCONNECTED -> "VPN disconnected"
            VpnPhase.ERROR -> vpnState.message.ifBlank { "Connection failed" }
        }
        ConnectionLogStore.record(context, vpnState.phase.name, eventText)
        logEntries = ConnectionLogStore.load(context)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepBlue, Night, Color(0xFF050912))))
    ) {
        AuroraBackground(
            tint = when (vpnState.phase) {
                VpnPhase.CONNECTED -> Mint
                VpnPhase.CONNECTING, VpnPhase.RECONNECTING -> Warning
                VpnPhase.ERROR -> Danger
                VpnPhase.DISCONNECTED -> Cyan
            }
        )
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = { BeparBottomBar(activeTab) { activeTab = it.name } }
        ) { padding ->
            AnimatedContent(
                targetState = activeTab,
                modifier = Modifier.fillMaxSize().padding(padding),
                label = "screen-transition",
                transitionSpec = {
                    // Keep navigation deliberately light: no large slide/scale layers or long overlap.
                    fadeIn(tween(110, easing = LinearEasing)) togetherWith
                        fadeOut(tween(70, easing = LinearEasing))
                }
            ) { tab ->
                val selectedTab = runCatching { AppTab.valueOf(tab) }.getOrDefault(AppTab.HOME)
                when (selectedTab) {
                    AppTab.HOME -> HomeScreen(
                        state = vpnState,
                        selectedNode = selectedNode,
                        profileCount = profiles.size,
                        sessionUsage = sessionUsage,
                        onConnect = ::connect,
                        onDisconnect = ::disconnect,
                        onBestConnect = ::connectToBestServer,
                        autoMode = autoMode,
                        onAutoModeChange = {
                            autoMode = it
                            AppPreferences.setAutoMode(context, it)
                        },
                        onRefreshPlan = ::refreshSubscriptionPlan,
                        onChooseProfile = { activeTab = AppTab.PROFILES.name }
                    )
                    AppTab.PROFILES -> ProfilesScreen(
                        profiles = profiles,
                        selectedId = selectedId,
                        feedStatuses = feedStatuses,
                        lastRefreshAt = RemoteConfigFeedRepository.lastSuccessfulRefresh(context),
                        isRefreshingFeeds = isRefreshingFeeds,
                        onRefreshFeeds = ::refreshAllSources,
                        showImport = showImport,
                        importText = importText,
                        isImporting = isImporting,
                        onToggleImport = { showImport = !showImport },
                        onImportText = { importText = it },
                        onImport = ::importProfiles,
                        onPickFile = { fileLauncher.launch(arrayOf("*/*")) },
                        onSelect = { id ->
                            val changed = id != selectedId
                            selectedId = id
                            NodeStore.select(context, id)
                            if (changed && (vpnState.phase == VpnPhase.CONNECTED || isVpnBusy)) {
                                startSelectedNode(id)
                                Toast.makeText(context, "Switching to selected server…", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onDelete = { deleteTarget = it },
                        onFavoriteChange = { node ->
                            profiles = NodeStore.setFavorite(context, node.id, !node.isFavorite)
                        }
                    )
                    AppTab.LOGS -> LogsScreen(
                        state = vpnState,
                        selectedNode = selectedNode,
                        entries = logEntries,
                        onClear = {
                            ConnectionLogStore.clear(context)
                            logEntries = emptyList()
                        }
                    )
                    AppTab.SETTINGS -> SettingsScreen(
                        themeId = themeId,
                        onThemeChange = {
                            themeId = it
                            AppPreferences.setThemeId(context, it)
                            activePalette = BeparThemes.fromId(it)
                        },
                        language = language,
                        onLanguageChange = {
                            language = it
                            AppPreferences.setLanguage(context, it)
                            activeLanguage = it
                        },
                        startTab = startTab,
                        onStartTabChange = {
                            startTab = it
                            AppPreferences.setStartTab(context, it)
                            Toast.makeText(context, if (language == "fa") "صفحه آغازین ذخیره شد." else "Start screen saved.", Toast.LENGTH_SHORT).show()
                        },
                        profileCount = profiles.size,
                        permissionRevision = permissionRevision,
                        autoReconnect = autoReconnect,
                        onAutoReconnectChange = {
                            autoReconnect = it
                            AppPreferences.setAutoReconnect(context, it)
                        },
                        compatMode = compatMode,
                        onCompatChange = {
                            compatMode = it
                            AppPreferences.setCompatMode(context, it)
                            Toast.makeText(context, "Saved. It applies the next time you connect.", Toast.LENGTH_SHORT).show()
                        },
                        dnsHost = dnsHost,
                        onDnsChange = {
                            dnsHost = it
                            AppPreferences.setDnsHost(context, it)
                            Toast.makeText(context, "DNS saved. Disconnect and reconnect to apply it to the Android tunnel.", Toast.LENGTH_LONG).show()
                        },
                        onRequestVpnPermission = { requestVpnPermission() },
                        onRequestNotifications = {
                            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            } else {
                                Toast.makeText(context, "Notifications are already allowed.", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onOpenVpnSettings = {
                            val action = if (Build.VERSION.SDK_INT >= 24) Settings.ACTION_VPN_SETTINGS else Settings.ACTION_SETTINGS
                            runCatching { context.startActivity(Intent(action)) }
                                .onFailure { Toast.makeText(context, "Android VPN settings are not available on this device.", Toast.LENGTH_LONG).show() }
                        },
                        onOpenNotificationSettings = {
                            val intent = if (Build.VERSION.SDK_INT >= 26) {
                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            } else {
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${context.packageName}"))
                            }
                            runCatching { context.startActivity(intent) }
                                .onFailure { Toast.makeText(context, "Could not open notification settings.", Toast.LENGTH_SHORT).show() }
                        },
                        onOpenAppSettings = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${context.packageName}"))
                            context.startActivity(intent)
                        },
                        onAddQuickTile = ::requestQuickSettingsTile,
                        autoUpdate = autoUpdate,
                        onAutoUpdateChange = {
                            autoUpdate = it
                            AppPreferences.setAutoUpdate(context, it)
                            AutoFeedRefreshScheduler.schedule(context)
                        },
                        updateInterval = updateInterval,
                        onUpdateIntervalChange = {
                            updateInterval = it
                            AppPreferences.setUpdateIntervalMinutes(context, it)
                            AutoFeedRefreshScheduler.schedule(context)
                        },
                        serversPerSource = serversPerSource,
                        onServersPerSourceChange = {
                            serversPerSource = it
                            AppPreferences.setServersPerSource(context, it)
                            Toast.makeText(context, "Saved. Tap Refresh in Servers to apply it now.", Toast.LENGTH_LONG).show()
                        },
                        maxPing = maxPing,
                        onMaxPingChange = {
                            maxPing = it
                            AppPreferences.setMaxPingMillis(context, it)
                            Toast.makeText(context, "Saved. Tap Refresh in Servers to apply it now.", Toast.LENGTH_LONG).show()
                        },
                        connectOnStart = connectOnStart,
                        onConnectOnStartChange = {
                            connectOnStart = it
                            AppPreferences.setConnectOnStart(context, it)
                        },
                        bypassCount = bypassApps.size,
                        onChooseBypassApps = { showBypassDialog = true },
                        onClearServers = { showClearDialog = true },
                        onOpenBatterySettings = {
                            val direct = Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                android.net.Uri.parse("package:${context.packageName}")
                            )
                            runCatching { context.startActivity(direct) }.onFailure {
                                runCatching { context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                                    .onFailure { Toast.makeText(context, "Battery settings are not available on this device.", Toast.LENGTH_LONG).show() }
                            }
                        }
                    )
                }
            }
        }
        AnimatedVisibility(
            visible = showLanding,
            enter = fadeIn(tween(1)),
            exit = fadeOut(tween(520)) + scaleOut(tween(520, easing = FastOutSlowInEasing), targetScale = 1.08f)
        ) {
            LandingScreen(firstRun = firstRun) {
                AppPreferences.setLandingSeen(context)
                showLanding = false
                if (!AppPreferences.setupPrompted(context)) showSetup = true
            }
        }
        AnimatedVisibility(
            visible = showSplash,
            enter = fadeIn(tween(1)),
            exit = fadeOut(tween(460)) + scaleOut(tween(460, easing = FastOutSlowInEasing), targetScale = 1.1f)
        ) {
            SplashScreen { showSplash = false }
        }
    }

    if (showSetup) {
        // Re-evaluated whenever a permission screen returns.
        val revision = permissionRevision
        val notificationsOn = remember(revision) { NotificationManagerCompat.from(context).areNotificationsEnabled() }
        val batteryUnrestricted = remember(revision) {
            val pm = context.getSystemService(PowerManager::class.java)
            pm?.isIgnoringBatteryOptimizations(context.packageName) ?: true
        }
        AlertDialog(
            onDismissRequest = {},
            containerColor = Panel,
            title = { Text(uiText("Keep Bepar VPN running"), color = Color.White, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                    Text(
                        "Two quick settings stop Android from cutting your connection in the background.",
                        color = Muted, fontSize = 13.sp
                    )
                    SetupRow(
                        title = "Allow notifications",
                        body = "Shows the connection status and a Disconnect button.",
                        done = notificationsOn,
                        action = "Allow"
                    ) {
                        if (Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) {
                            notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                        } else {
                            val intent = if (Build.VERSION.SDK_INT >= 26) {
                                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, context.packageName)
                            } else {
                                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:${context.packageName}"))
                            }
                            runCatching { batteryLauncher.launch(intent) }
                        }
                    }
                    SetupRow(
                        title = "Disable battery saver",
                        body = "Set Bepar VPN to Unrestricted so the tunnel is not stopped when the screen is off.",
                        done = batteryUnrestricted,
                        action = "Disable"
                    ) {
                        val direct = Intent(
                            Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                            android.net.Uri.parse("package:${context.packageName}")
                        )
                        runCatching { batteryLauncher.launch(direct) }.onFailure {
                            runCatching { batteryLauncher.launch(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    AppPreferences.setSetupPrompted(context)
                    showSetup = false
                }) { Text(uiText(if (notificationsOn && batteryUnrestricted) "Done" else "Later"), color = Cyan, fontWeight = FontWeight.Bold) }
            }
        )
    }

    if (showBypassDialog) {
        BypassAppsDialog(
            initial = bypassApps,
            onDismiss = { showBypassDialog = false },
            onSave = { chosen ->
                bypassApps = chosen
                AppPreferences.setBypassApps(context, chosen)
                showBypassDialog = false
                Toast.makeText(context, "Saved. Disconnect and reconnect to apply.", Toast.LENGTH_LONG).show()
            }
        )
    }

    if (showClearDialog) {
        AlertDialog(
            onDismissRequest = { showClearDialog = false },
            containerColor = Panel,
            title = { Text(uiText("Clear all servers?"), color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text(uiText("Every saved server, including ones you added yourself, is removed from this device. Auto sources can download new ones."), color = Muted) },
            confirmButton = {
                TextButton(onClick = {
                    if (vpnState.phase == VpnPhase.CONNECTED || isVpnBusy) disconnect()
                    NodeStore.clearAll(context)
                    profiles = emptyList()
                    selectedId = null
                    showClearDialog = false
                    Toast.makeText(context, "All servers removed.", Toast.LENGTH_SHORT).show()
                }) { Text(uiText("Clear"), color = Danger) }
            },
            dismissButton = { TextButton(onClick = { showClearDialog = false }) { Text(uiText("Cancel"), color = Muted) } }
        )
    }

    if (deleteTarget != null) {
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            containerColor = Panel,
            title = { Text(uiText("Delete profile?"), color = Color.White, fontWeight = FontWeight.Bold) },
            text = { Text(if (activeLanguage == "fa") "«${deleteTarget?.name}» از این دستگاه حذف شود؟" else "Remove ‘${deleteTarget?.name}’ from this device?", color = Muted) },
            confirmButton = {
                TextButton(onClick = {
                    val target = deleteTarget
                    if (target != null) {
                        val wasSelected = target.id == selectedId
                        val (updated, selected) = NodeStore.remove(context, target.id)
                        profiles = updated
                        selectedId = selected
                        if (wasSelected && (vpnState.phase == VpnPhase.CONNECTED || isVpnBusy)) {
                            if (selected != null) startSelectedNode(selected) else disconnect()
                        }
                    }
                    deleteTarget = null
                }) { Text(uiText("Delete"), color = Danger) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text(uiText("Cancel"), color = Muted) } }
        )
    }
}

@Composable
private fun SetupRow(title: String, body: String, done: Boolean, action: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = .05f)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(uiText(title), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(uiText(body), color = Muted, fontSize = 11.sp, lineHeight = 15.sp)
        }
        Spacer(Modifier.width(8.dp))
        if (done) {
            AppIcon("check", Mint, Modifier.size(22.dp), 2.2f)
        } else {
            TextButton(onClick = onClick) { Text(action, color = Cyan, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun BeparBottomBar(activeTab: String, onTab: (AppTab) -> Unit) {
    Surface(color = Panel.copy(alpha = .97f), shadowElevation = 16.dp, tonalElevation = 0.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            BottomItem("home", uiText("Home"), AppTab.HOME, activeTab, onTab)
            BottomItem("servers", uiText("Servers"), AppTab.PROFILES, activeTab, onTab)
            BottomItem("file", uiText("Logs"), AppTab.LOGS, activeTab, onTab)
            BottomItem("settings", uiText("Settings"), AppTab.SETTINGS, activeTab, onTab)
        }
    }
}

@Composable
private fun BottomItem(icon: String, label: String, tab: AppTab, activeTab: String, onTab: (AppTab) -> Unit) {
    val selected = activeTab == tab.name
    val tint by animateColorAsState(if (selected) Cyan else Muted, label = "nav-tint")
    val lift by animateFloatAsState(
        if (selected) 1f else 0f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "nav-lift"
    )
    val navInteraction = remember { MutableInteractionSource() }
    val navPressed by navInteraction.collectIsPressedAsState()
    val navPress by animateFloatAsState(
        if (navPressed) .90f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "nav-press"
    )
    Column(
        modifier = Modifier
            .graphicsLayer(scaleX = navPress, scaleY = navPress)
            .clip(RoundedCornerShape(15.dp))
            .background(
                Brush.verticalGradient(listOf(Cyan.copy(alpha = .20f * lift), Color.Transparent)),
                RoundedCornerShape(15.dp)
            )
            .clickable(interactionSource = navInteraction, indication = null, role = Role.Tab) { onTab(tab) }
            .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        // Glowing indicator that grows out of the top edge of the active tab.
        Box(
            Modifier
                .width((20f * lift).coerceIn(0f, 26f).dp)
                .height(3.dp)
                .graphicsLayer(alpha = lift.coerceIn(0f, 1f))
                .background(Brush.horizontalGradient(listOf(Cyan, Mint)), CircleShape)
        )
        AppIcon(
            icon, tint,
            Modifier.size(22.dp).graphicsLayer(
                scaleX = 1f + .16f * lift,
                scaleY = 1f + .16f * lift,
                translationY = -2.5f * lift
            )
        )
        Text(label, color = tint, fontSize = 10.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium)
    }
}

@Composable
private fun ScreenColumn(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(17.dp),
        content = content
    )
}

@Composable
private fun BrandHeader(title: String) {
    Row(Modifier.fillMaxWidth().padding(bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(uiText(title), fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, letterSpacing = (-.55).sp)
            if (title == "Bepar VPN") Text(uiText("SECURE CONNECTION"), fontSize = 9.sp, color = Muted, letterSpacing = 1.7.sp)
        }
        LogoMark(Modifier.size(46.dp))
    }
}

/**
 * Orbit Shield mark: an abstract shield/check protected by a moving orbital ring.
 * It deliberately uses no alphabetic character, so the brand mark remains language-neutral.
 */
@Composable
private fun LogoMark(modifier: Modifier = Modifier) {
    val pulse by rememberInfiniteTransition(label = "logo-orbit").animateFloat(
        .42f, 1f,
        infiniteRepeatable(tween(1850, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "logo-orbit-pulse"
    )
    BoxWithConstraints(modifier) {
        val corner = maxWidth * .30f
        val shape = RoundedCornerShape(corner)
        Canvas(
            Modifier.fillMaxSize()
                .shadow(12.dp, shape, ambientColor = Cyan, spotColor = Blue)
                .background(Brush.linearGradient(listOf(Cyan, Blue)), shape)
                .glowBorder(Color.White, corner, 3600)
        ) {
            val k = size.minDimension / 100f
            drawRoundRect(
                Brush.verticalGradient(listOf(Color.White.copy(alpha = .22f), Color.Transparent), endY = size.height * .55f),
                cornerRadius = CornerRadius(corner.toPx())
            )
            // A tilted orbit suggests a fast, globally connected route.
            drawOval(
                color = Color.White.copy(alpha = .22f * pulse),
                topLeft = Offset(15f * k, 24f * k),
                size = Size(70f * k, 50f * k),
                style = Stroke(width = 2.2f * k)
            )
            val shield = Path().apply {
                moveTo(50f * k, 23f * k)
                lineTo(75f * k, 33f * k)
                lineTo(72f * k, 60f * k)
                cubicTo(70f * k, 72f * k, 60f * k, 80f * k, 50f * k, 85f * k)
                cubicTo(40f * k, 80f * k, 30f * k, 72f * k, 28f * k, 60f * k)
                lineTo(25f * k, 33f * k)
                close()
            }
            val shieldStroke = Stroke(width = 5.2f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
            drawPath(shield, Color(0xFF08234A).copy(alpha = .38f), style = Stroke(width = 8.5f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawPath(shield, Color.White, style = shieldStroke)
            val check = Path().apply {
                moveTo(38f * k, 53f * k)
                lineTo(46f * k, 61f * k)
                lineTo(63f * k, 43f * k)
            }
            drawPath(check, Color.White, style = Stroke(width = 7f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
            val node = Offset(78f * k, 24f * k)
            drawCircle(Mint.copy(alpha = .28f * pulse), 10f * k * (.86f + .22f * pulse), node)
            drawCircle(Mint, 4.6f * k, node)
        }
    }
}

@Composable
private fun HomeScreen(
    state: com.bepar.vpn.vpn.VpnUiState,
    selectedNode: ServerNode?,
    profileCount: Int,
    sessionUsage: AppPreferences.SessionUsage?,
    onConnect: () -> Unit,
    onDisconnect: () -> Unit,
    onBestConnect: () -> Unit,
    autoMode: Boolean,
    onAutoModeChange: (Boolean) -> Unit,
    onRefreshPlan: () -> Unit,
    onChooseProfile: () -> Unit
) {
    val connected = state.phase == VpnPhase.CONNECTED
    val busy = state.phase == VpnPhase.CONNECTING || state.phase == VpnPhase.RECONNECTING
    val statusColor = when (state.phase) {
        VpnPhase.CONNECTED -> Mint
        VpnPhase.CONNECTING, VpnPhase.RECONNECTING -> Warning
        VpnPhase.ERROR -> Danger
        VpnPhase.DISCONNECTED -> Muted
    }
    val action = when {
        connected -> "Disconnect"
        busy -> "Cancel"
        else -> "Tap to Connect"
    }

    ScreenColumn {
        BrandHeader("Bepar VPN")
        Card(
            modifier = Modifier.fillMaxWidth().entrance(0).glowBorder(statusColor, 30.dp),
            shape = RoundedCornerShape(30.dp),
            colors = CardDefaults.cardColors(containerColor = Color.Transparent),
            border = BorderStroke(1.dp, Color.White.copy(alpha = .075f))
        ) {
            Box(Modifier.background(Brush.verticalGradient(listOf(PanelRaised, Panel, DeepBlue)))) {
                Canvas(Modifier.matchParentSize()) {
                    val dot = 1.2.dp.toPx()
                    for (row in 0..8) {
                        for (col in 0..18) {
                            val x = size.width * (col + .5f) / 19f
                            val y = size.height * (.08f + row * .055f)
                            drawCircle(Cyan.copy(alpha = .07f), dot, Offset(x, y))
                        }
                    }
                    drawCircle(Blue.copy(alpha = .055f), size.width * .48f, Offset(size.width * .5f, size.height * .34f))
                }
                val globeSpin by rememberInfiniteTransition(label = "home-globe")
                    .animateFloat(0f, 360f, infiniteRepeatable(tween(32000, easing = LinearEasing)), label = "home-globe-spin")
                WireGlobe(
                    Modifier.matchParentSize().padding(horizontal = 6.dp, vertical = 30.dp).graphicsLayer(alpha = if (connected) .55f else .28f),
                    globeSpin,
                    if (connected) Mint else Cyan
                )
                TrafficWave(
                    tint = if (connected) Mint else if (busy) Warning else Cyan,
                    active = connected,
                    busy = busy,
                    modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(86.dp)
                )
                Column(
                    Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 21.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(9.dp)
                ) {
                    ModeSelector(autoMode, enabled = !connected && !busy, onChange = onAutoModeChange)
                    StatusPill(uiText(statusLabel(state.phase)), statusColor)
                    PowerButton(
                        active = connected,
                        busy = busy,
                        onClick = {
                            when {
                                connected || busy -> onDisconnect()
                                autoMode -> onBestConnect()
                                else -> onConnect()
                            }
                        }
                    )
                    Text(
                        uiText(when (state.phase) {
                            VpnPhase.CONNECTED -> "Connected"
                            VpnPhase.CONNECTING -> "Connecting…"
                            VpnPhase.RECONNECTING -> "Switching server…"
                            VpnPhase.ERROR -> "Connection failed"
                            VpnPhase.DISCONNECTED -> "Not connected"
                        }),
                        color = if (connected) Mint else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 21.sp,
                        textAlign = TextAlign.Center
                    )
                    Text(
                        if (busy && state.message.isNotBlank()) state.message
                        else if (connected) uiText(state.message.ifBlank { action })
                        else if (autoMode) uiText("Tap to connect automatically") else uiText(action),
                        color = if (connected || busy) Muted else Cyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        maxLines = 2
                    )
                    if (state.phase == VpnPhase.ERROR) {
                        Text(state.message, color = Danger, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 2)
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().entrance(1), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(uiText(if (autoMode && !connected) "Server" else "Selected server"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
            Text(uiText("Change"), color = Cyan, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.clickable(onClick = onChooseProfile))
        }
        Card(
            modifier = Modifier.fillMaxWidth().entrance(2).clickable(onClick = onChooseProfile),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Panel),
            border = BorderStroke(1.dp, PanelBorder.copy(alpha = .62f))
        ) {
            Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(45.dp).background(PanelRaised, CircleShape), contentAlignment = Alignment.Center) {
                    AppIcon("server", Cyan, Modifier.size(23.dp))
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        uiText(if (autoMode && !connected) "Auto • best available" else selectedNode?.name ?: "No server selected"),
                        color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1
                    )
                    Text(
                        if (autoMode && !connected) uiText("Updates sources, tests servers and verifies internet")
                        else selectedNode?.let { "${it.protocol.uppercase()}  •  ${it.host}" } ?: uiText("Add a server profile"),
                        color = Muted, fontSize = 11.sp, maxLines = 1
                    )
                }
                AppIcon("chevron", Muted, Modifier.size(20.dp))
            }
        }

        Row(Modifier.entrance(3), horizontalArrangement = Arrangement.spacedBy(11.dp)) {
            MiniInfoCard(Modifier.weight(1f), "SERVERS", profileCount.toString(), "servers")
            MiniInfoCard(Modifier.weight(1f), "PROTOCOL", selectedNode?.protocol?.uppercase() ?: "—", "shield")
        }
        Box(Modifier.entrance(4)) { SessionAndPlanCard(sessionUsage, selectedNode, onRefreshPlan) }
    }
}

@Composable
private fun SessionAndPlanCard(
    session: AppPreferences.SessionUsage?,
    node: ServerNode?,
    onRefreshPlan: () -> Unit
) {
    val total = node?.subscriptionTotalBytes
    val upload = node?.subscriptionUploadBytes
    val download = node?.subscriptionDownloadBytes
    val hasCounters = upload != null && download != null
    val hasQuota = total != null && total > 0L && hasCounters
    val used = if (hasCounters) saturatingAdd(upload ?: 0L, download ?: 0L) else null
    val remaining = if (hasQuota) (total!! - (used ?: 0L)).coerceAtLeast(0L) else null
    val isCommunityAutoFeed = node?.subscriptionUrl?.let { sourceUrl ->
        RemoteConfigFeedRepository.sources.any { it.url == sourceUrl }
    } == true
    val expirySeconds = node?.subscriptionExpireAtSeconds
    val expiryMillis = expirySeconds
        ?.takeIf { it in 1L..(Long.MAX_VALUE / 1_000L) }
        ?.times(1_000L)
    val timeLeft = expiryMillis?.let { (it - System.currentTimeMillis()).coerceAtLeast(0L) }
    val progress = if (hasQuota && used != null && total != null && total > 0L) (used.toDouble() / total.toDouble()).toFloat().coerceIn(0f, 1f) else 0f

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(19.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, PanelBorder.copy(alpha = .58f))
    ) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(uiText("USAGE"), color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.weight(1f))
                if (node?.subscriptionUrl != null && !isCommunityAutoFeed) {
                    TextButton(onClick = onRefreshPlan, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 5.dp, vertical = 0.dp)) {
                        Text(uiText("Refresh plan"), color = Cyan, fontSize = 10.sp)
                    }
                } else {
                    Text(uiText(if (isCommunityAutoFeed) "AUTO SERVER" else "THIS SESSION"), color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(uiText("Upload"), color = Muted, fontSize = 10.sp)
                    Text(session?.let { formatBytes(it.uploadBytes) } ?: "—", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(uiText("Download"), color = Muted, fontSize = 10.sp)
                    Text(session?.let { formatBytes(it.downloadBytes) } ?: "—", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(uiText("Session time"), color = Muted, fontSize = 10.sp)
                    Text(session?.let { formatDuration(it.durationMillis) } ?: "—", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
            }
            Text(
                uiText("VPN traffic • Xray") + ": " + (session?.let { formatBytes(it.bytes) } ?: "—"),
                color = Muted, fontSize = 9.sp
            )
            Divider(color = Color.White.copy(alpha = .07f))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(uiText(if (isCommunityAutoFeed) "Provider quota" else "Plan data left"), color = Muted, fontSize = 10.sp)
                    Text(
                        when {
                            remaining != null -> formatBytes(remaining)
                            total == 0L -> "Unlimited"
                            else -> "Not provided"
                        },
                        color = if (remaining == null && total != 0L) Muted else Mint,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(uiText(if (isCommunityAutoFeed) "Provider expiry" else "Time left"), color = Muted, fontSize = 10.sp)
                    Text(
                        when {
                            expirySeconds == null -> "Not provided"
                            expirySeconds == 0L -> "No expiry"
                            timeLeft == 0L -> "Expired"
                            else -> formatRemainingTime(timeLeft ?: 0L)
                        },
                        color = if (timeLeft == 0L) Danger else Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
            if (hasQuota) {
                Canvas(Modifier.fillMaxWidth().height(5.dp)) {
                    drawRoundRect(PanelRaised, cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2f))
                    drawRoundRect(Mint, size = Size(size.width * progress, size.height), cornerRadius = androidx.compose.ui.geometry.CornerRadius(size.height / 2f))
                }
                Text(if (activeLanguage == "fa") "${formatBytes(used ?: 0L)} مصرف از ${formatBytes(total!!)}" else "${formatBytes(used ?: 0L)} used of ${formatBytes(total!!)}", color = Muted, fontSize = 9.sp)
            } else if (hasCounters && total == 0L) {
                Text(if (activeLanguage == "fa") "${formatBytes(used ?: 0L)} مصرف · طرح نامحدود" else "${formatBytes(used ?: 0L)} used · Unlimited plan", color = Muted, fontSize = 9.sp)
            } else if (hasCounters && total == null) {
                Text(if (activeLanguage == "fa") "${formatBytes(used ?: 0L)} مصرف · سقف حجم مشخص نیست" else "${formatBytes(used ?: 0L)} used · quota limit not provided", color = Muted, fontSize = 9.sp)
            } else if (total != null && total > 0L && !hasCounters) {
                Text(if (activeLanguage == "fa") "حجم ${formatBytes(total)} · اطلاعات مصرف موجود نیست" else "Quota ${formatBytes(total)} · usage not provided", color = Muted, fontSize = 9.sp)
            }
            if (node?.subscriptionFetchedAtMillis != null && (total != null || hasCounters || expirySeconds != null)) {
                Text(if (activeLanguage == "fa") "به‌روزرسانی ${formatLogTime(node.subscriptionFetchedAtMillis)}" else "Updated ${formatLogTime(node.subscriptionFetchedAtMillis)}", color = Muted, fontSize = 9.sp)
            }
        }
    }
}

private fun saturatingAdd(left: Long, right: Long): Long =
    if (Long.MAX_VALUE - left < right) Long.MAX_VALUE else left + right

private fun formatBytes(bytes: Long): String {
    if (bytes < 0L) return "—"
    val units = listOf("B", "KB", "MB", "GB", "TB")
    var value = bytes.toDouble()
    var unit = 0
    while (value >= 1024.0 && unit < units.lastIndex) {
        value /= 1024.0
        unit++
    }
    return if (unit == 0) "${value.toLong()} ${units[unit]}" else String.format(java.util.Locale.US, "%.1f %s", value, units[unit])
}

private fun formatDuration(durationMillis: Long): String {
    val totalSeconds = durationMillis / 1_000L
    val hours = totalSeconds / 3_600L
    val minutes = (totalSeconds % 3_600L) / 60L
    val seconds = totalSeconds % 60L
    return when {
        hours > 0L -> "${hours}h ${minutes}m"
        minutes > 0L -> "${minutes}m ${seconds}s"
        else -> "${seconds}s"
    }
}

private fun formatRemainingTime(millis: Long): String {
    val totalMinutes = millis / 60_000L
    val days = totalMinutes / 1_440L
    val hours = (totalMinutes % 1_440L) / 60L
    val minutes = totalMinutes % 60L
    return when {
        days > 0L -> "${days}d ${hours}h"
        hours > 0L -> "${hours}h ${minutes}m"
        else -> "${minutes}m"
    }
}

@Composable
private fun StatusPill(label: String, tint: Color) {
    Surface(shape = CircleShape, color = tint.copy(alpha = .10f), border = BorderStroke(1.dp, tint.copy(alpha = .30f))) {
        Row(Modifier.padding(horizontal = 13.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            Box(Modifier.size(7.dp).background(tint, CircleShape))
            Text(uiText(label), color = tint, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ModeSelector(autoMode: Boolean, enabled: Boolean, onChange: (Boolean) -> Unit) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .clip(shape)
            .background(Color.White.copy(alpha = .06f))
            .border(1.dp, Color.White.copy(alpha = .08f), shape)
            .padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        listOf(true to uiText("AUTO"), false to uiText("MANUAL")).forEach { (isAuto, label) ->
            val selected = autoMode == isAuto
            val bg by animateColorAsState(if (selected) Cyan.copy(alpha = .22f) else Color.Transparent, label = "mode-bg")
            val fg by animateColorAsState(if (selected) Color.White else Muted, label = "mode-fg")
            Row(
                Modifier
                    .clip(RoundedCornerShape(13.dp))
                    .background(bg)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        enabled = enabled,
                        role = Role.Tab
                    ) { onChange(isAuto) }
                    .padding(horizontal = 18.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (isAuto) AppIcon("bolt", if (selected) Cyan else Muted, Modifier.size(15.dp))
                Text(label, color = fg, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            }
        }
    }
}

/**
 * Animated power button.
 *  - press: soft spring squish
 *  - connecting: three staggered ripples + a comet arc orbiting the ring, icon breathes
 *  - connected: ring turns green with a one-shot shockwave, then a calm glow
 *  - idle: very slow breathing glow so the button feels alive
 */
/** Wireframe globe with orbiting nodes; real 3D projection (depth fades the back side). */
/** Cities (lat, lon in degrees) the globe links with glowing data arcs. */
private val GlobeCities = listOf(
    35.7f to 51.4f, 51.5f to -0.1f, 40.7f to -74.0f, 1.3f to 103.8f,
    -33.9f to 151.2f, 35.7f to 139.7f, 25.2f to 55.3f, -23.5f to -46.6f
)

/**
 * Real 3D globe: shaded sphere, fibonacci dot-matrix surface, graticule that fades on the far side,
 * atmosphere rim, pulsing city nodes and great-circle arcs with data packets travelling along them.
 * [rotation] is the spin in degrees; everything is drawn in the draw phase (no recomposition).
 */
@Composable
private fun WireGlobe(modifier: Modifier, rotation: Float, tint: Color) {
    val dots = remember {
        val n = 420
        val golden = (PI * (3.0 - sqrt(5.0))).toFloat()
        FloatArray(n * 3).also { a ->
            for (i in 0 until n) {
                val y = 1f - 2f * (i + .5f) / n
                val rad = sqrt(1f - y * y)
                val th = golden * i
                a[i * 3] = cos(th) * rad; a[i * 3 + 1] = y; a[i * 3 + 2] = sin(th) * rad
            }
        }
    }
    val cities = remember {
        GlobeCities.map { (lat, lon) ->
            val la = Math.toRadians(lat.toDouble()); val lo = Math.toRadians(lon.toDouble())
            floatArrayOf((cos(la) * sin(lo)).toFloat(), sin(la).toFloat(), (cos(la) * cos(lo)).toFloat())
        }
    }
    val pulse by rememberInfiniteTransition(label = "globe-fx")
        .animateFloat(0f, 1f, infiniteRepeatable(tween(3400, easing = LinearEasing)), label = "globe-pulse")

    Canvas(modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val r = size.minDimension / 2f * .88f
        val ca = cos(Math.toRadians(rotation.toDouble())).toFloat()
        val sa = sin(Math.toRadians(rotation.toDouble())).toFloat()
        val tilt = Math.toRadians(-16.0)
        val ct = cos(tilt).toFloat()
        val st = sin(tilt).toFloat()
        val out = FloatArray(3)
        // Spin around the vertical axis, then tilt the axis toward the viewer. out = (x, y, depth).
        fun proj(x: Float, y: Float, z: Float, scale: Float = 1f) {
            val x1 = x * ca + z * sa
            val z1 = -x * sa + z * ca
            val y2 = y * ct - z1 * st
            val z2 = y * st + z1 * ct
            out[0] = c.x + x1 * r * scale; out[1] = c.y - y2 * r * scale; out[2] = z2
        }

        // Outer atmosphere glow.
        drawCircle(
            Brush.radialGradient(listOf(tint.copy(alpha = .20f), Color.Transparent), center = c, radius = r * 1.5f),
            radius = r * 1.5f, center = c
        )
        // Sphere body, lit from the upper left.
        drawCircle(
            Brush.radialGradient(
                listOf(tint.copy(alpha = .26f), DeepBlue.copy(alpha = .78f), Color(0xFF050912).copy(alpha = .92f)),
                center = Offset(c.x - r * .35f, c.y - r * .40f), radius = r * 1.25f
            ),
            radius = r, center = c
        )

        // Graticule: meridians and parallels, bright on the near side, ghosted on the far side.
        fun line(samples: Int, point: (Int) -> Triple<Float, Float, Float>) {
            var px = 0f; var py = 0f; var pz = 0f
            for (i in 0..samples) {
                val (x, y, z) = point(i)
                proj(x, y, z)
                if (i > 0) {
                    val d = (out[2] + pz) / 2f
                    drawLine(
                        tint.copy(alpha = if (d > 0f) .10f + .20f * d else .035f),
                        Offset(px, py), Offset(out[0], out[1]), strokeWidth = .9.dp.toPx()
                    )
                }
                px = out[0]; py = out[1]; pz = out[2]
            }
        }
        for (m in 0 until 12) {
            val lon = Math.toRadians(m * 30.0)
            line(36) { i ->
                val la = Math.toRadians(-90.0 + i * 5.0)
                Triple((cos(la) * sin(lon)).toFloat(), sin(la).toFloat(), (cos(la) * cos(lon)).toFloat())
            }
        }
        for (lat in intArrayOf(-60, -30, 0, 30, 60)) {
            val la = Math.toRadians(lat.toDouble())
            line(48) { i ->
                val lo = Math.toRadians(i * 7.5)
                Triple((cos(la) * sin(lo)).toFloat(), sin(la).toFloat(), (cos(la) * cos(lo)).toFloat())
            }
        }

        // Dot-matrix surface.
        for (i in 0 until dots.size / 3) {
            proj(dots[i * 3], dots[i * 3 + 1], dots[i * 3 + 2])
            val d = out[2]
            if (d > 0f) {
                drawCircle(tint.copy(alpha = .16f + .62f * d), (.7f + 1.0f * d).dp.toPx(), Offset(out[0], out[1]))
            } else if (d > -.25f) {
                drawCircle(tint.copy(alpha = .05f), .6.dp.toPx(), Offset(out[0], out[1]))
            }
        }

        // Atmosphere rim + specular edge.
        drawCircle(
            Brush.radialGradient(
                0f to Color.Transparent, .80f to Color.Transparent,
                .96f to tint.copy(alpha = .38f), 1f to Color.Transparent,
                center = c, radius = r * 1.10f
            ),
            radius = r * 1.10f, center = c
        )
        drawCircle(tint.copy(alpha = .30f), r, c, style = Stroke(1.2.dp.toPx()))

        // Data arcs between consecutive cities with a packet running along each.
        for (i in 0 until cities.size - 1) {
            val a = cities[i]; val b = cities[i + 1]
            val dot = (a[0] * b[0] + a[1] * b[1] + a[2] * b[2]).coerceIn(-.999f, .999f)
            val om = acos(dot)
            val so = sin(om)
            fun arc(t: Float) {
                val k1 = sin((1f - t) * om) / so
                val k2 = sin(t * om) / so
                val lift = 1f + .20f * sin(t * PI.toFloat())
                proj((a[0] * k1 + b[0] * k2), (a[1] * k1 + b[1] * k2), (a[2] * k1 + b[2] * k2), lift)
            }
            var px = 0f; var py = 0f; var pd = 0f
            for (j in 0..24) {
                arc(j / 24f)
                if (j > 0 && (out[2] + pd) / 2f > 0f) {
                    drawLine(Mint.copy(alpha = .10f + .28f * (out[2] + pd) / 2f), Offset(px, py), Offset(out[0], out[1]), strokeWidth = 1.dp.toPx(), cap = StrokeCap.Round)
                }
                px = out[0]; py = out[1]; pd = out[2]
            }
            val t = (pulse + i * .21f) % 1f
            arc(t)
            if (out[2] > 0f) {
                val pk = Offset(out[0], out[1])
                drawCircle(Mint.copy(alpha = .35f), 6.dp.toPx(), pk)
                drawCircle(Color.White, 2.2.dp.toPx(), pk)
            }
        }
        // City nodes with expanding pulse rings.
        cities.forEachIndexed { i, v ->
            proj(v[0], v[1], v[2])
            if (out[2] > 0f) {
                val o = Offset(out[0], out[1])
                val t = (pulse * 1.0f + i * .125f) % 1f
                drawCircle(Mint.copy(alpha = (1f - t) * .55f * out[2]), (3f + 9f * t).dp.toPx(), o, style = Stroke(1.dp.toPx()))
                drawCircle(Mint, (2.2f + 1.4f * out[2]).dp.toPx(), o)
                drawCircle(Color.White.copy(alpha = .9f), 1.1.dp.toPx(), o)
            }
        }
    }
}

@Composable
private fun PowerButton(active: Boolean, busy: Boolean, onClick: () -> Unit) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val pressScale by animateFloatAsState(
        if (pressed) .92f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press-scale"
    )

    val infinite = rememberInfiniteTransition(label = "power-fx")
    val ripple by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(2100, easing = LinearEasing)), label = "ripple")
    val orbit by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "orbit")
    val breathe by infinite.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breathe"
    )

    val tint by animateColorAsState(
        when {
            active -> Mint
            busy -> Warning
            else -> Cyan
        },
        animationSpec = tween(520), label = "power-tint"
    )
    val tiltX by animateFloatAsState(
        if (pressed) 16f else 0f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "tilt-x"
    )
    val flip = remember { Animatable(0f) }
    val camera = 14f * LocalDensity.current.density
    val busyAmount by animateFloatAsState(if (busy) 1f else 0f, tween(420), label = "busy-amount")
    val activeAmount by animateFloatAsState(if (active) 1f else 0f, tween(650), label = "active-amount")

    // One-shot effects when the state flips.
    val burst = remember { Animatable(1f) }
    val iconPop = remember { Animatable(1f) }
    LaunchedEffect(active) {
        if (active) {
            launch { burst.snapTo(0f); burst.animateTo(1f, tween(1000, easing = FastOutSlowInEasing)) }
            launch { flip.snapTo(0f); flip.animateTo(360f, tween(950, easing = FastOutSlowInEasing)) }
        }
        iconPop.snapTo(.78f)
        iconPop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
    }
    LaunchedEffect(busy) {
        if (busy) {
            iconPop.snapTo(.86f)
            iconPop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow))
        }
    }

    Box(
        Modifier
            .size(214.dp)
            .graphicsLayer(scaleX = pressScale, scaleY = pressScale),
        contentAlignment = Alignment.Center
    ) {
        OrbitSatellites(tint, active, busy, front = false, modifier = Modifier.fillMaxSize())
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val radius = 76.dp.toPx()

            // Idle / connected glow that gently breathes.
            val glowAlpha = (.07f + .07f * breathe) * (1f - busyAmount) + .10f * busyAmount
            drawCircle(
                Brush.radialGradient(
                    listOf(tint.copy(alpha = glowAlpha * 2.6f), Color.Transparent),
                    center = center, radius = radius * 1.45f
                ),
                radius = radius * 1.45f, center = center
            )

            // Connecting ripples: three rings expanding and fading, staggered.
            if (busyAmount > .01f) {
                repeat(3) { i ->
                    val t = (ripple + i / 3f) % 1f
                    drawCircle(
                        tint.copy(alpha = (1f - t) * .34f * busyAmount),
                        radius = radius * (1.0f + .42f * t),
                        center = center,
                        style = Stroke(width = (3.5f * (1f - t) + .8f).dp.toPx())
                    )
                }
            }

            // Connected shockwave.
            if (burst.value < 1f) {
                val t = burst.value
                drawCircle(
                    Mint.copy(alpha = (1f - t) * .55f),
                    radius = radius * (1.0f + .55f * t),
                    center = center,
                    style = Stroke(width = (7f * (1f - t) + 1f).dp.toPx())
                )
                // Sparks flying outward.
                repeat(16) { i ->
                    val ang = Math.toRadians(i * 360.0 / 16 + 8.0)
                    val dist = radius * (1.05f + 1.0f * t)
                    drawCircle(
                        Mint.copy(alpha = (1f - t) * .9f),
                        (3.4f * (1f - t) + .8f).dp.toPx(),
                        Offset(center.x + (cos(ang) * dist).toFloat(), center.y + (sin(ang) * dist).toFloat())
                    )
                }
            }

            // Soft contact shadow on the "floor" for depth.
            drawOval(
                Brush.radialGradient(
                    listOf(Color.Black.copy(alpha = .45f), Color.Transparent),
                    center = Offset(center.x, center.y + radius * 1.12f), radius = radius * .9f
                ),
                topLeft = Offset(center.x - radius * .85f, center.y + radius * 1.0f),
                size = Size(radius * 1.7f, radius * .3f)
            )

            // Button body.
            drawCircle(
                Brush.radialGradient(listOf(PanelRaised, Panel), center = center, radius = radius),
                radius = radius, center = center
            )
            if (activeAmount > .01f) {
                drawCircle(
                    Brush.radialGradient(
                        listOf(Mint.copy(alpha = .20f * activeAmount), Color.Transparent),
                        center = center, radius = radius
                    ),
                    radius = radius, center = center
                )
            }

            // Ring: solid when idle/connected, comet arc orbiting while connecting.
            val ringWidth = 4.dp.toPx()
            drawCircle(tint.copy(alpha = .22f + .50f * (1f - busyAmount)), radius, center, style = Stroke(ringWidth))
            if (busyAmount > .01f) {
                rotate(orbit, center) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(Color.Transparent, tint.copy(alpha = busyAmount), Color.Transparent),
                            center = center
                        ),
                        startAngle = -10f,
                        sweepAngle = 110f,
                        useCenter = false,
                        topLeft = Offset(center.x - radius, center.y - radius),
                        size = Size(radius * 2f, radius * 2f),
                        style = Stroke(ringWidth * 1.6f, cap = StrokeCap.Round)
                    )
                }
            }
        }

        // Hit target + icon.
        Box(
            Modifier
                .size(118.dp)
                .graphicsLayer(
                    rotationX = tiltX,
                    rotationY = flip.value + (breathe - .5f) * 9f,
                    cameraDistance = camera
                )
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(PanelRaised, DeepBlue)), CircleShape)
                .clickable(interactionSource = interaction, indication = null, role = Role.Button, onClick = onClick)
                .semantics { contentDescription = if (active) "Disconnect VPN" else "Connect VPN" },
            contentAlignment = Alignment.Center
        ) {
            Canvas(Modifier.fillMaxSize()) {
                // Specular highlight + bevelled rim = glassy 3D button face.
                drawCircle(
                    Brush.radialGradient(
                        listOf(Color.White.copy(alpha = .24f), Color.Transparent),
                        center = Offset(size.width * .32f, size.height * .26f), radius = size.width * .62f
                    )
                )
                drawCircle(
                    Brush.linearGradient(
                        listOf(Color.White.copy(alpha = .45f), Color.Transparent, Color.Black.copy(alpha = .5f)),
                        start = Offset(0f, 0f), end = Offset(size.width, size.height)
                    ),
                    style = Stroke(2.5.dp.toPx())
                )
            }
            AppIcon(
                "power", tint,
                Modifier
                    .size(56.dp)
                    .graphicsLayer(
                        scaleX = iconPop.value * (1f + .05f * breathe * busyAmount),
                        scaleY = iconPop.value * (1f + .05f * breathe * busyAmount),
                        alpha = 1f - .25f * breathe * busyAmount
                    ),
                1.25f + .35f * activeAmount
            )
        }
        OrbitSatellites(tint, active, busy, front = true, modifier = Modifier.fillMaxSize())
    }
}

/** Landing / splash. First launch: full welcome with a Get started button. Later launches: short branded splash. */
@Composable
private fun LandingScreen(firstRun: Boolean, onFinish: () -> Unit) {
    val reveal = remember { Animatable(0f) }
    val textReveal = remember { Animatable(0f) }
    val infinite = rememberInfiniteTransition(label = "landing-fx")
    val float by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(3200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "float")
    val ring by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(2600, easing = LinearEasing)), label = "landing-ring")
    val spin by infinite.animateFloat(0f, 360f, infiniteRepeatable(tween(26000, easing = LinearEasing)), label = "landing-spin")
    LaunchedEffect(Unit) {
        launch {
            delay(320)
            textReveal.animateTo(1f, tween(800, easing = FastOutSlowInEasing))
        }
        reveal.animateTo(1f, tween(1000, easing = FastOutSlowInEasing))
        if (!firstRun) {
            delay(900)
            onFinish()
        }
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepBlue, Night, Night)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        AuroraBackground(Cyan)
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height * .30f)
            repeat(3) { i ->
                val t = (ring + i / 3f) % 1f
                drawCircle(Cyan.copy(alpha = (1f - t) * .16f), size.width * (.20f + .42f * t), c, style = Stroke(1.5.dp.toPx()))
            }
            drawCircle(Cyan.copy(alpha = .05f), size.width * .75f, Offset(size.width, 0f))
        }
        Column(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing).padding(horizontal = 28.dp, vertical = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Scrollable content so small screens never push the button out of view.
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Spacer(Modifier.height(if (firstRun) 8.dp else 90.dp))
                Box(
                    Modifier
                        .size(if (firstRun) 264.dp else 290.dp)
                        .graphicsLayer(
                            alpha = reveal.value,
                            scaleX = .6f + .4f * reveal.value,
                            scaleY = .6f + .4f * reveal.value,
                            translationY = -16f * float,
                            rotationX = 10f * (float - .5f),
                            cameraDistance = 14f * LocalDensity.current.density
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Canvas(Modifier.fillMaxSize()) {
                        val haloR = size.minDimension * (.52f + .06f * float)
                        drawCircle(
                            Brush.radialGradient(
                                listOf(Cyan.copy(alpha = .30f + .10f * float), Color.Transparent),
                                center = center, radius = haloR
                            ),
                            radius = haloR, center = center
                        )
                    }
                    OrbitSatellites(Cyan, active = true, busy = false, front = false, modifier = Modifier.fillMaxSize())
                    WireGlobe(Modifier.fillMaxSize().padding(if (firstRun) 14.dp else 18.dp), spin, Cyan)
                    LogoMark(Modifier.size(64.dp))
                    OrbitSatellites(Cyan, active = true, busy = false, front = true, modifier = Modifier.fillMaxSize())
                }
                Spacer(Modifier.height(18.dp))
                val shimmerX = -200f + 900f * ring
                Text(
                    "Bepar VPN",
                    style = TextStyle(
                        brush = Brush.linearGradient(
                            listOf(Color.White, Cyan, Color.White),
                            start = Offset(shimmerX, 0f),
                            end = Offset(shimmerX + 360f, 0f)
                        ),
                        fontSize = 32.sp,
                        fontWeight = FontWeight.ExtraBold,
                        letterSpacing = (-.8).sp
                    ),
                    modifier = Modifier.graphicsLayer(alpha = textReveal.value, translationY = (1f - textReveal.value) * 28f)
                )
                Spacer(Modifier.height(6.dp))
                Text(
                    uiText("One tap. Fastest working server."), color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.graphicsLayer(alpha = textReveal.value, translationY = (1f - textReveal.value) * 18f)
                )
                if (firstRun) {
                    Spacer(Modifier.height(20.dp))
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        LandingPoint("bolt", uiText("Auto mode"), uiText("Collects public servers, tests them and keeps only one that really has internet."), Modifier.entrance(5))
                        LandingPoint("server", uiText("Your own servers"), uiText("Import VLESS, VMess, Trojan, Shadowsocks links or a subscription URL."), Modifier.entrance(7))
                        LandingPoint("settings", uiText("Private by design"), uiText("Profiles are encrypted on this device. No accounts, no tracking."), Modifier.entrance(9))
                    }
                    Spacer(Modifier.height(12.dp))
                }
            }
            if (firstRun) {
                Spacer(Modifier.height(10.dp))
                GlowButton(
                    text = uiText("Get started"),
                    onClick = onFinish,
                    modifier = Modifier.fillMaxWidth().height(56.dp).graphicsLayer(alpha = textReveal.value, translationY = (1f - textReveal.value) * 24f)
                )
            } else {
                CircularProgressIndicator(Modifier.size(22.dp).graphicsLayer(alpha = reveal.value), color = Cyan, strokeWidth = 2.dp)
                Spacer(Modifier.height(24.dp))
            }
        }
    }
}

/** Short branded loading screen shown on every launch after the first one. */
@Composable
private fun SplashScreen(onFinish: () -> Unit) {
    val progress = remember { Animatable(0f) }
    val pop = remember { Animatable(0f) }
    var stage by remember { mutableIntStateOf(0) }
    val infinite = rememberInfiniteTransition(label = "splash-fx")
    val ring by infinite.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "splash-ring")
    LaunchedEffect(Unit) {
        launch { pop.animateTo(1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)) }
        launch {
            delay(420); stage = 1
            delay(480); stage = 2
        }
        progress.animateTo(1f, tween(1250, easing = FastOutSlowInEasing))
        delay(120)
        onFinish()
    }
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(DeepBlue, Night, Night)))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) {
        AuroraBackground(Cyan)
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height * .42f)
            repeat(3) { i ->
                val t = (ring + i / 3f) % 1f
                drawCircle(Cyan.copy(alpha = (1f - t) * .18f), size.width * (.16f + .46f * t), c, style = Stroke(1.5.dp.toPx()))
            }
        }
        Column(
            Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.safeDrawing),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Box(
                Modifier
                    .size(220.dp)
                    .graphicsLayer(
                        alpha = pop.value.coerceIn(0f, 1f),
                        scaleX = .5f + .5f * pop.value,
                        scaleY = .5f + .5f * pop.value
                    ),
                contentAlignment = Alignment.Center
            ) {
                OrbitSatellites(Cyan, active = true, busy = false, front = false, modifier = Modifier.fillMaxSize())
                LogoMark(Modifier.size(84.dp))
                OrbitSatellites(Cyan, active = true, busy = false, front = true, modifier = Modifier.fillMaxSize())
            }
            Spacer(Modifier.height(14.dp))
            val shimmerX = -200f + 900f * ring
            Text(
                "Bepar VPN",
                style = TextStyle(
                    brush = Brush.linearGradient(
                        listOf(Color.White, Cyan, Color.White),
                        start = Offset(shimmerX, 0f),
                        end = Offset(shimmerX + 360f, 0f)
                    ),
                    fontSize = 32.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = (-.8).sp
                )
            )
            Spacer(Modifier.height(6.dp))
            AnimatedContent(
                targetState = stage,
                transitionSpec = {
                    (fadeIn(tween(260, delayMillis = 80)) + slideInVertically(tween(300)) { it / 2 }) togetherWith
                        (fadeOut(tween(140)) + slideOutVertically(tween(220)) { -it / 2 })
                },
                label = "splash-stage"
            ) { current ->
                Text(
                    uiText(when (current) {
                        0 -> "SECURING THE TUNNEL"
                        1 -> "FINDING THE FASTEST ROUTE"
                        else -> "READY"
                    }),
                    color = if (current == 2) Mint else Muted,
                    fontSize = 11.sp,
                    letterSpacing = 2.sp
                )
            }
            Spacer(Modifier.height(34.dp))
            Canvas(Modifier.width(160.dp).height(5.dp)) {
                val radius = CornerRadius(size.height / 2f)
                drawRoundRect(Color.White.copy(alpha = .09f), cornerRadius = radius)
                val filled = size.width * progress.value
                drawRoundRect(
                    brush = Brush.horizontalGradient(listOf(Cyan, Mint)),
                    size = Size(filled, size.height),
                    cornerRadius = radius
                )
                if (progress.value in .02f..0.98f) {
                    // Glowing head on the leading edge of the bar.
                    drawCircle(Mint.copy(alpha = .35f), size.height * 2.2f, Offset(filled, size.height / 2f))
                    drawCircle(Color.White.copy(alpha = .95f), size.height * .55f, Offset(filled, size.height / 2f))
                }
            }
        }
    }
}

/** Primary call-to-action: gradient pill with a travelling light sweep, breathing glow and spring press. */
@Composable
private fun GlowButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        if (pressed) .96f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "cta-press"
    )
    val infinite = rememberInfiniteTransition(label = "cta-fx")
    val sweep by infinite.animateFloat(
        -.5f, 1.5f,
        infiniteRepeatable(tween(2800, easing = LinearEasing)),
        label = "cta-sweep"
    )
    val shape = RoundedCornerShape(19.dp)
    Box(
        modifier
            .graphicsLayer(scaleX = scale, scaleY = scale)
            .shadow(14.dp, shape, ambientColor = Cyan, spotColor = Cyan)
            .clip(shape)
            .background(Brush.horizontalGradient(listOf(Cyan, Blue)))
            .drawWithContent {
                drawContent()
                val w = size.width
                drawRect(
                    Brush.linearGradient(
                        listOf(Color.Transparent, Color.White.copy(alpha = .32f), Color.Transparent),
                        start = Offset(w * (sweep - .2f), 0f),
                        end = Offset(w * (sweep + .2f), size.height)
                    )
                )
            }
            .clickable(interactionSource = interaction, indication = null, role = Role.Button, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp, letterSpacing = .3.sp)
    }
}

@Composable
private fun LandingPoint(icon: String, title: String, body: String, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = .05f)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(40.dp).background(Cyan.copy(alpha = .12f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
            AppIcon(icon, Cyan, Modifier.size(21.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(body, color = Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun MiniInfoCard(modifier: Modifier, label: String, value: String, icon: String) {
    Card(modifier, shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .45f))) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(uiText(label), color = Muted, fontSize = 10.sp)
                Text(value, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            }
            AppIcon(icon, Cyan, Modifier.size(24.dp))
        }
    }
}

@Composable
private fun ProfilesScreen(
    profiles: List<ServerNode>,
    selectedId: String?,
    feedStatuses: List<RemoteConfigSourceStatus>,
    lastRefreshAt: Long,
    isRefreshingFeeds: Boolean,
    onRefreshFeeds: () -> Unit,
    showImport: Boolean,
    importText: String,
    isImporting: Boolean,
    onToggleImport: () -> Unit,
    onImportText: (String) -> Unit,
    onImport: () -> Unit,
    onPickFile: () -> Unit,
    onSelect: (String) -> Unit,
    onDelete: (ServerNode) -> Unit,
    onFavoriteChange: (ServerNode) -> Unit
) {
    // Built-in rows are identified by persisted origin. Exact feed URL matching also
    // migrates profiles saved by earlier app versions that did not store an origin.
    val builtInUrls = remember { RemoteConfigFeedRepository.sources.map { it.url }.toSet() }
    val builtInProfiles = remember(profiles, builtInUrls) {
        profiles.filter { it.origin == ServerOrigin.BUILT_IN || it.subscriptionUrl in builtInUrls }
    }
    val manualProfiles = remember(profiles, builtInUrls) {
        profiles.filterNot { it.origin == ServerOrigin.BUILT_IN || it.subscriptionUrl in builtInUrls }
    }
    var sourceTab by rememberSaveable { mutableStateOf("app") }
    val isAppTab = sourceTab == "app"
    val visibleProfiles = if (isAppTab) builtInProfiles else manualProfiles
    var searchQuery by rememberSaveable { mutableStateOf("") }
    var favoritesOnly by rememberSaveable { mutableStateOf(false) }
    var sortMode by rememberSaveable { mutableStateOf("latency") }
    var sortMenuExpanded by remember { mutableStateOf(false) }
    val filteredProfiles = remember(visibleProfiles, searchQuery, favoritesOnly, sortMode) {
        val query = searchQuery.trim()
        val filtered = visibleProfiles.filter { node ->
            (!favoritesOnly || node.isFavorite) && (query.isBlank() ||
                node.name.contains(query, ignoreCase = true) ||
                node.host.contains(query, ignoreCase = true) ||
                node.protocol.contains(query, ignoreCase = true))
        }
        when (sortMode) {
            "name" -> filtered.sortedWith(compareBy<ServerNode> { it.name.lowercase() })
            "protocol" -> filtered.sortedWith(compareBy<ServerNode> { it.protocol.lowercase() }.thenBy { it.name.lowercase() })
            else -> filtered.sortedWith(compareBy<ServerNode> { it.pingMillis ?: Long.MAX_VALUE }.thenBy { it.name.lowercase() })
        }
    }

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item(key = "brand-header") {
            BrandHeader("Servers")
        }
        item(key = "source-tabs") {
            ProfileSourceTabs(
                selected = sourceTab,
                appCount = builtInProfiles.size,
                manualCount = manualProfiles.size,
                onSelect = { sourceTab = it }
            )
        }

        if (isAppTab) {
            item(key = "app-description") {
                Text(uiText("App-managed public feed servers"), color = Muted, fontSize = 11.sp)
            }
            item(key = "auto-sources") {
                AutoSourcesCard(
                    statuses = feedStatuses,
                    lastRefreshAt = lastRefreshAt,
                    refreshing = isRefreshingFeeds,
                    onRefresh = onRefreshFeeds
                )
            }
        } else {
            item(key = "manual-description") {
                Text(uiText("Your imported configurations stay here"), color = Muted, fontSize = 11.sp)
            }
            item(key = "add-server") {
                Card(
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onToggleImport),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = PanelRaised),
                    border = BorderStroke(1.dp, Cyan.copy(alpha = .22f))
                ) {
                    Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Cyan.copy(alpha = .10f), RoundedCornerShape(13.dp)), contentAlignment = Alignment.Center) {
                            AppIcon("plus", Cyan, Modifier.size(22.dp))
                        }
                        Spacer(Modifier.width(12.dp))
                        Text(uiText("Add server"), color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        AppIcon(if (showImport) "close" else "chevron", Cyan, Modifier.size(20.dp))
                    }
                }
            }
            if (showImport) {
                item(key = "import-card") {
                    ImportCard(
                        value = importText,
                        importing = isImporting,
                        onValueChange = onImportText,
                        onImport = {
                            sourceTab = "manual"
                            onImport()
                        },
                        onPickFile = {
                            sourceTab = "manual"
                            onPickFile()
                        }
                    )
                }
            }
        }

        item(key = "server-search") {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                label = { Text(uiText("Search servers")) },
                textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        TextButton(onClick = { searchQuery = "" }) { Text("×", color = Muted, fontSize = 18.sp) }
                    }
                },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = PanelBorder,
                    focusedLabelColor = Cyan,
                    unfocusedLabelColor = Muted,
                    cursorColor = Cyan
                )
            )
        }
        item(key = "server-list-controls") {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                TextButton(
                    onClick = { favoritesOnly = !favoritesOnly },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 7.dp)
                ) {
                    Text(
                        text = if (favoritesOnly) "★ ${uiText("Favorites")}" else "☆ ${uiText("All")} / ${uiText("Favorites")}",
                        color = if (favoritesOnly) Color(0xFFFFD166) else Muted,
                        fontSize = 11.sp,
                        fontWeight = if (favoritesOnly) FontWeight.Bold else FontWeight.Medium
                    )
                }
                Spacer(Modifier.weight(1f))
                Box {
                    TextButton(onClick = { sortMenuExpanded = true }) {
                        Text("${uiText("Sort by")}: ${uiText(when (sortMode) { "name" -> "Name A–Z"; "protocol" -> "Protocol"; else -> "Lowest latency" })} ▾", color = Cyan, fontSize = 10.sp)
                    }
                    DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                        listOf("latency" to "Lowest latency", "name" to "Name A–Z", "protocol" to "Protocol").forEach { (key, label) ->
                            DropdownMenuItem(
                                text = { Text(uiText(label)) },
                                onClick = { sortMode = key; sortMenuExpanded = false }
                            )
                        }
                    }
                }
            }
        }

        item(key = "list-heading") {
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    uiText(if (isAppTab) "App servers" else "Manual servers"),
                    color = Color.White,
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                Text("${filteredProfiles.size}/${visibleProfiles.size}", color = Muted, fontSize = 12.sp)
            }
        }

        if (filteredProfiles.isEmpty()) {
            item(key = "empty-state") {
                EmptyState(
                    uiText(if (favoritesOnly) "No favorite servers" else if (searchQuery.isNotBlank()) "No matching servers" else "No servers"),
                    uiText(if (favoritesOnly) "No favorite servers" else if (isAppTab) "No app servers yet" else "No manual servers yet")
                )
            }
        } else {
            items(
                items = filteredProfiles,
                key = { it.id },
                contentType = { "server-profile" }
            ) { node ->
                ProfileCard(
                    node = node,
                    selected = node.id == selectedId,
                    favorite = node.isFavorite,
                    onSelect = { onSelect(node.id) },
                    onDelete = { onDelete(node) },
                    onToggleFavorite = { onFavoriteChange(node) }
                )
            }
        }
        item(key = "bottom-space") { Spacer(Modifier.height(4.dp)) }
    }
}

@Composable
private fun ProfileSourceTabs(
    selected: String,
    appCount: Int,
    manualCount: Int,
    onSelect: (String) -> Unit
) {
    val shape = RoundedCornerShape(16.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Panel)
            .border(1.dp, PanelBorder.copy(alpha = .75f), shape)
            .padding(4.dp),
        horizontalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        listOf(
            Triple("app", uiText("App servers"), appCount),
            Triple("manual", uiText("Manual servers"), manualCount)
        ).forEach { (key, title, count) ->
            val active = selected == key
            Row(
                Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (active) Cyan.copy(alpha = .20f) else Color.Transparent)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                        role = Role.Tab
                    ) { onSelect(key) }
                    .padding(horizontal = 8.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    title,
                    color = if (active) Color.White else Muted,
                    fontSize = 11.sp,
                    fontWeight = if (active) FontWeight.Bold else FontWeight.Medium,
                    maxLines = 1
                )
                Spacer(Modifier.width(6.dp))
                Box(
                    Modifier
                        .clip(CircleShape)
                        .background(if (active) Cyan.copy(alpha = .22f) else Color.White.copy(alpha = .07f))
                        .padding(horizontal = 7.dp, vertical = 2.dp)
                ) {
                    Text(count.toString(), color = if (active) Cyan else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun AutoSourcesCard(
    statuses: List<RemoteConfigSourceStatus>,
    lastRefreshAt: Long,
    refreshing: Boolean,
    onRefresh: () -> Unit
) {
    val available = statuses.count { it.lastSuccessAt > 0L && it.lastError == null }
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Panel),
        border = BorderStroke(1.dp, PanelBorder.copy(alpha = .65f))
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(uiText("AUTO SOURCES"), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = .8.sp)
                    Text("$available/${statuses.size} sources ready", color = Muted, fontSize = 10.sp)
                }
                TextButton(onClick = onRefresh, enabled = !refreshing) {
                    if (refreshing) CircularProgressIndicator(Modifier.size(15.dp), color = Cyan, strokeWidth = 2.dp)
                    else AppIcon("refresh", Cyan, Modifier.size(17.dp))
                    Spacer(Modifier.width(5.dp))
                    Text(uiText(if (refreshing) "Updating" else "Refresh"), color = Cyan, fontSize = 11.sp)
                }
            }
            statuses.forEach { status ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    val healthy = status.lastSuccessAt > 0L && status.lastError == null
                    val hasCached = status.lastSuccessAt > 0L
                    Box(Modifier.size(7.dp).background(if (healthy) Mint else Warning, CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text(status.title, color = Color.White, fontSize = 10.sp, modifier = Modifier.weight(1f), maxLines = 1)
                    Text(
                        uiText(when {
                            healthy -> "${status.profileCount} profiles"
                            hasCached -> "Cached · retry"
                            status.lastError != null -> "Unavailable"
                            else -> "Pending"
                        }),
                        color = if (healthy) Muted else Warning,
                        fontSize = 9.sp
                    )
                }
            }
            Text(
                if (lastRefreshAt > 0L) (if (activeLanguage == "fa") "آخرین به‌روزرسانی ${formatLogTime(lastRefreshAt)}" else "Last update ${formatLogTime(lastRefreshAt)}")
                else uiText("Server list will be downloaded on first Auto connect."),
                color = Muted,
                fontSize = 9.sp
            )
        }
    }
}

@Composable
private fun ImportCard(value: String, importing: Boolean, onValueChange: (String) -> Unit, onImport: () -> Unit, onPickFile: () -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder)) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                modifier = Modifier.fillMaxWidth(),
                minLines = 3,
                maxLines = 6,
                shape = RoundedCornerShape(14.dp),
                label = { Text(uiText("Server link or configuration")) },
                placeholder = { Text("vless://…", style = TextStyle(textDirection = TextDirection.Ltr)) },
                textStyle = TextStyle(color = Color.White, fontSize = 12.sp, textDirection = TextDirection.Ltr),
                keyboardOptions = KeyboardOptions(autoCorrect = false)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                Button(
                    onClick = onPickFile,
                    modifier = Modifier.weight(1f).height(47.dp),
                    shape = RoundedCornerShape(13.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PanelRaised, contentColor = Color.White)
                ) {
                    AppIcon("file", Color.White, Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text(uiText("From file"), fontSize = 12.sp)
                }
                Button(
                    onClick = onImport,
                    enabled = value.isNotBlank() && !importing,
                    modifier = Modifier.weight(1f).height(47.dp),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    if (importing) CircularProgressIndicator(Modifier.size(17.dp), color = Color(0xFF06121B), strokeWidth = 2.dp)
                    else AppIcon("check", Color(0xFF06121B), Modifier.size(17.dp))
                    Spacer(Modifier.width(7.dp)); Text(if (importing) "Importing…" else "Import", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun ProfileCard(
    node: ServerNode,
    selected: Boolean,
    favorite: Boolean,
    onSelect: () -> Unit,
    onDelete: () -> Unit,
    onToggleFavorite: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onSelect),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = if (selected) PanelRaised else Panel),
        border = BorderStroke(1.dp, if (selected) Cyan.copy(alpha = .55f) else PanelBorder.copy(alpha = .55f))
    ) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 13.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(if (selected) Cyan.copy(alpha = .13f) else PanelRaised, CircleShape), contentAlignment = Alignment.Center) {
                AppIcon(if (selected) "check" else "server", if (selected) Mint else Cyan, Modifier.size(21.dp))
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(node.name, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, fontSize = 13.sp)
                Text(
                    listOfNotNull(node.protocol.uppercase(), nodeLocationHint(node.name), node.host.takeIf { it.isNotBlank() }).joinToString("  •  "),
                    color = Muted, maxLines = 1, fontSize = 10.sp
                )
            }
            node.pingMillis?.let { ms ->
                Text(
                    "$ms ms",
                    color = if (ms < 300L) Mint else if (ms < 700L) Warning else Danger,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.width(8.dp))
            }
            if (selected) Text(uiText("ACTIVE"), color = Mint, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            TextButton(
                onClick = onToggleFavorite,
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(if (favorite) "★" else "☆", color = if (favorite) Color(0xFFFFD166) else Muted, fontSize = 19.sp)
            }
            TextButton(onClick = onDelete, contentPadding = PaddingValues(horizontal = 4.dp, vertical = 2.dp)) {
                Text("×", color = Danger, fontSize = 20.sp)
            }
        }
    }
}

@Composable
private fun LogsScreen(
    state: com.bepar.vpn.vpn.VpnUiState,
    selectedNode: ServerNode?,
    entries: List<ConnectionLogEntry>,
    onClear: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isTesting by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    var testOk by remember { mutableStateOf<Boolean?>(null) }
    var testLatency by remember { mutableStateOf<Long?>(null) }
    var testDownloadMbps by remember { mutableStateOf<Double?>(null) }

    ScreenColumn {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(uiText("Connection logs"), fontSize = 24.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
                Text(if (activeLanguage == "fa") "${entries.size} رویداد" else "${entries.size} events", fontSize = 10.sp, color = Muted)
            }
            LogoMark(Modifier.size(42.dp))
        }
        Card(shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(statusLabel(state.phase), when (state.phase) {
                        VpnPhase.CONNECTED -> Mint
                        VpnPhase.CONNECTING, VpnPhase.RECONNECTING -> Warning
                        VpnPhase.ERROR -> Danger
                        VpnPhase.DISCONNECTED -> Muted
                    })
                    Spacer(Modifier.weight(1f))
                    Text(selectedNode?.name ?: uiText("No server"), color = Color.White, fontSize = 11.sp, maxLines = 1)
                }
                Button(
                    onClick = {
                        if (isTesting) return@Button
                        isTesting = true
                        testResult = null
                        scope.launch {
                            val result = withContext(Dispatchers.IO) { TunnelProbe.run() }
                            testOk = result.reachable
                            testResult = result.detail
                            testLatency = result.latencyMillis
                            testDownloadMbps = result.downloadMbps
                            isTesting = false
                        }
                    },
                    enabled = state.phase == VpnPhase.CONNECTED && !isTesting,
                    modifier = Modifier.fillMaxWidth().height(46.dp),
                    shape = RoundedCornerShape(13.dp)
                ) {
                    if (isTesting) CircularProgressIndicator(Modifier.size(17.dp), color = Color(0xFF06121B), strokeWidth = 2.dp)
                    else AppIcon("activity", Color(0xFF06121B), Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp)); Text(uiText(if (isTesting) "Testing…" else "Test latency + download"), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
                testResult?.let { message ->
                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text(message, color = if (testOk == true) Mint else Warning, fontSize = 11.sp)
                        val metrics = listOfNotNull(
                            testLatency?.let { "Latency ${it} ms" },
                            testDownloadMbps?.let { "Download sample ${String.format(java.util.Locale.US, "%.2f", it)} Mbps" }
                        )
                        if (metrics.isNotEmpty()) Text(metrics.joinToString("  •  "), color = Color.White, fontSize = 10.sp)
                        if (testOk == true && testDownloadMbps == null) Text(uiText("Download sample unavailable"), color = Muted, fontSize = 9.sp)
                    }
                }
            }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(uiText("Recent activity"), color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = onClear, enabled = entries.isNotEmpty()) { Text(uiText("Clear"), color = Danger, fontSize = 11.sp) }
        }
        if (entries.isEmpty()) {
            EmptyState(uiText("No activity yet"), "")
        } else {
            Card(shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .6f))) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    entries.forEachIndexed { index, entry ->
                        Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                val color = when (entry.phase) {
                                    "CONNECTED" -> Mint
                                    "ERROR" -> Danger
                                    "CONNECTING", "RECONNECTING" -> Warning
                                    else -> Muted
                                }
                                Box(Modifier.size(10.dp).background(color, CircleShape))
                                if (index < entries.lastIndex) Box(Modifier.width(1.dp).height(27.dp).background(PanelBorder))
                            }
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                                Text(uiText(entry.message.ifBlank { entry.phase.lowercase().replaceFirstChar { c -> c.uppercase() } }), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                Text(formatLogTime(entry.timestamp), color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatLogTime(timestamp: Long): String =
    java.text.SimpleDateFormat("MMM d, HH:mm:ss", java.util.Locale.US).format(java.util.Date(timestamp))

private fun startTabLabel(tab: String): String = when (tab) {
    "PROFILES" -> uiText("Server list")
    "LOGS" -> uiText("Connection history")
    "SETTINGS" -> uiText("Settings")
    else -> uiText("Home screen")
}

@Composable
private fun SettingsScreen(
    themeId: String,
    onThemeChange: (String) -> Unit,
    language: String,
    onLanguageChange: (String) -> Unit,
    startTab: String,
    onStartTabChange: (String) -> Unit,
    profileCount: Int,
    permissionRevision: Int,
    autoReconnect: Boolean,
    onAutoReconnectChange: (Boolean) -> Unit,
    compatMode: String,
    onCompatChange: (String) -> Unit,
    dnsHost: String,
    onDnsChange: (String) -> Unit,
    onRequestVpnPermission: () -> Unit,
    onRequestNotifications: () -> Unit,
    onOpenVpnSettings: () -> Unit,
    onOpenNotificationSettings: () -> Unit,
    onOpenAppSettings: () -> Unit,
    onAddQuickTile: () -> Unit,
    autoUpdate: Boolean,
    onAutoUpdateChange: (Boolean) -> Unit,
    updateInterval: Int,
    onUpdateIntervalChange: (Int) -> Unit,
    serversPerSource: Int,
    onServersPerSourceChange: (Int) -> Unit,
    maxPing: Int,
    onMaxPingChange: (Int) -> Unit,
    connectOnStart: Boolean,
    onConnectOnStartChange: (Boolean) -> Unit,
    bypassCount: Int,
    onChooseBypassApps: () -> Unit,
    onClearServers: () -> Unit,
    onOpenBatterySettings: () -> Unit
) {
    val context = LocalContext.current
    @Suppress("UNUSED_VARIABLE") val permissionStateRevision = permissionRevision
    val vpnPermissionGranted = VpnService.prepare(context) == null
    val notificationsGranted = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    var dnsMenuExpanded by remember { mutableStateOf(false) }

    ScreenColumn {
        BrandHeader("Settings")
        Text(uiText("Appearance").uppercase(), color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Card(modifier = Modifier.fillMaxWidth().entrance(0), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .65f))) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                SettingDropdownRow(
                    title = "Theme",
                    subtitle = "Choose the app color palette",
                    valueLabel = BeparThemes.label(themeId),
                    options = AppPreferences.THEME_OPTIONS.map { BeparThemes.label(it) to it },
                    onSelect = onThemeChange
                )
                Divider(color = Color.White.copy(alpha = .07f))
                SettingDropdownRow(
                    title = "Language",
                    subtitle = "Choose the display language",
                    valueLabel = if (language == "fa") "فارسی" else "English",
                    options = listOf("فارسی" to "fa", "English" to "en"),
                    onSelect = onLanguageChange
                )
                Divider(color = Color.White.copy(alpha = .07f))
                SettingDropdownRow(
                    title = "Start screen",
                    subtitle = "Choose which screen opens first",
                    valueLabel = startTabLabel(startTab),
                    options = AppPreferences.START_TAB_OPTIONS.map { startTabLabel(it) to it },
                    onSelect = onStartTabChange
                )
            }
        }

        Text(uiText("CONNECTION"), color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Card(modifier = Modifier.fillMaxWidth().entrance(1), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .6f))) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                SettingSwitchRow("Auto reconnect", "Restore after network changes", autoReconnect, onAutoReconnectChange)
                Divider(color = Color.White.copy(alpha = .07f))
                SettingSwitchRow("Connect on app start", "Uses Auto or your selected server", connectOnStart, onConnectOnStartChange)
                Divider(color = Color.White.copy(alpha = .07f))
                SettingDropdownRow(
                    title = "Operator compatibility",
                    subtitle = "Adapts to Hamrah-e Aval, Irancell, Rightel, Shatel, Wi-Fi…",
                    valueLabel = compatLabel(compatMode),
                    options = AppPreferences.COMPAT_MODES.map { compatLabel(it) to it },
                    onSelect = onCompatChange
                )
                Divider(color = Color.White.copy(alpha = .07f))
                Row(Modifier.fillMaxWidth().padding(vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(uiText("DNS server"), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(dnsHost, color = Muted, fontSize = 10.sp)
                    }
                    Box {
                        TextButton(onClick = { dnsMenuExpanded = true }) { Text(uiText(dnsLabel(dnsHost)), color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold) }
                        DropdownMenu(expanded = dnsMenuExpanded, onDismissRequest = { dnsMenuExpanded = false }) {
                            AppPreferences.DNS_OPTIONS.forEach { dns ->
                                DropdownMenuItem(text = { Text("${uiText(dnsLabel(dns))}  •  $dns") }, onClick = { dnsMenuExpanded = false; onDnsChange(dns) })
                            }
                        }
                    }
                }
                Divider(color = Color.White.copy(alpha = .07f))
                ActionSettingRow(
                    "Apps that bypass VPN",
                    if (bypassCount == 0) "None — every app uses the VPN" else "$bypassCount app(s) connect directly",
                    "Choose",
                    onChooseBypassApps
                )
            }
        }

        Text(uiText("SERVERS"), color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Card(modifier = Modifier.fillMaxWidth().entrance(2), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .6f))) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                SettingSwitchRow("Auto-update servers", "Refresh the public lists in the background", autoUpdate, onAutoUpdateChange)
                Divider(color = Color.White.copy(alpha = .07f))
                SettingDropdownRow(
                    title = "Update interval",
                    subtitle = "Android may delay background runs",
                    valueLabel = intervalLabel(updateInterval),
                    options = AppPreferences.UPDATE_INTERVAL_OPTIONS.map { intervalLabel(it) to it },
                    onSelect = onUpdateIntervalChange
                )
                Divider(color = Color.White.copy(alpha = .07f))
                SettingDropdownRow(
                    title = "Servers per source",
                    subtitle = "Auto checks each profile through the real Xray outbound",
                    valueLabel = serversPerSource.toString(),
                    options = AppPreferences.SERVERS_PER_SOURCE_OPTIONS.map { it.toString() to it },
                    onSelect = onServersPerSourceChange
                )
                Divider(color = Color.White.copy(alpha = .07f))
                SettingDropdownRow(
                    title = "TCP screening timeout",
                    subtitle = "Lightweight feed filter only; Auto runs the real Xray probe",
                    valueLabel = pingLimitLabel(maxPing),
                    options = AppPreferences.MAX_PING_OPTIONS.map { pingLimitLabel(it) to it },
                    onSelect = onMaxPingChange
                )
                Divider(color = Color.White.copy(alpha = .07f))
                ActionSettingRow("Clear all servers", "Remove every saved server from this device", "Clear", onClearServers)
            }
        }

        Text(uiText("PERMISSIONS"), color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Card(modifier = Modifier.fillMaxWidth().entrance(3), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .6f))) {
            Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                PermissionRow("VPN access", "Required", vpnPermissionGranted, if (vpnPermissionGranted) "Allowed" else "Allow", onRequestVpnPermission)
                Divider(color = Color.White.copy(alpha = .07f))
                PermissionRow("Notifications", "Optional", notificationsGranted, if (notificationsGranted) "Allowed" else "Enable", onRequestNotifications)
            }
        }

        Text(uiText("ANDROID"), color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Card(modifier = Modifier.fillMaxWidth().entrance(4), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .6f))) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp)) {
                ActionSettingRow("Quick Settings switch", "Connect from the notification shade", "Add", onAddQuickTile)
                Divider(color = Color.White.copy(alpha = .07f))
                ActionSettingRow("Battery optimization", "Keep the tunnel alive in the background", "Open", onOpenBatterySettings)
                Divider(color = Color.White.copy(alpha = .07f))
                ActionSettingRow("Always-on VPN", "Android system setting", "Open", onOpenVpnSettings)
                Divider(color = Color.White.copy(alpha = .07f))
                ActionSettingRow("Notification settings", "Manage alerts", "Open", onOpenNotificationSettings)
                Divider(color = Color.White.copy(alpha = .07f))
                ActionSettingRow("App permissions", "Android app details", "Open", onOpenAppSettings)
            }
        }

        Text(uiText("ABOUT"), color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Card(modifier = Modifier.fillMaxWidth().entrance(5), shape = RoundedCornerShape(19.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .6f))) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
                SettingRow("Application", "Bepar VPN")
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("Version", BuildConfig.VERSION_NAME)
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("Saved servers", profileCount.toString())
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("Engine", "Xray / libXray")
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("Auto sources", "4 public feeds")
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("Kept per source", "$serversPerSource profiles • ${pingLimitLabel(maxPing)} TCP")
                Divider(color = Color.White.copy(alpha = .07f))
                SettingRow("Refresh", if (autoUpdate) "Every ${intervalLabel(updateInterval)}" else "Manual only")
            }
        }
        Text(
            if (activeLanguage == "fa") "پروفایل‌ها روی همین دستگاه رمزگذاری می‌شوند. سرورهای عمومی توسط اشخاص ثالث اداره می‌شوند و ممکن است فراداده اتصال را ببینند. برای ورود بانکی یا اطلاعات حساس از سرورهای ناشناس استفاده نکنید."
            else "Profiles are encrypted on this device. Public community servers are run by third parties; their operators may observe connection metadata. Do not use unknown free nodes for banking or sensitive credentials.",
            color = Muted, fontSize = 10.sp, lineHeight = 15.sp
        )
    }
}

@Composable
private fun SettingSwitchRow(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(uiText(title), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(uiText(subtitle), color = Muted, fontSize = 10.sp)
        }
        Switch(checked = checked, onCheckedChange = onCheckedChange)
    }
}

@Composable
private fun <T> SettingDropdownRow(
    title: String,
    subtitle: String,
    valueLabel: String,
    options: List<Pair<String, T>>,
    onSelect: (T) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
            Text(uiText(title), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(uiText(subtitle), color = Muted, fontSize = 10.sp)
        }
        Box {
            TextButton(onClick = { expanded = true }) {
                Text(uiText(valueLabel), color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
            DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                options.forEach { option ->
                    DropdownMenuItem(
                        text = { Text(uiText(option.first)) },
                        onClick = {
                            expanded = false
                            onSelect(option.second)
                        }
                    )
                }
            }
        }
    }
}

private data class LaunchableApp(val packageName: String, val label: String)

/** Split-tunneling picker: checked apps skip the VPN the next time the tunnel is built. */
@Composable
private fun BypassAppsDialog(initial: Set<String>, onDismiss: () -> Unit, onSave: (Set<String>) -> Unit) {
    val context = LocalContext.current
    var apps by remember { mutableStateOf<List<LaunchableApp>?>(null) }
    var checked by remember { mutableStateOf(initial) }
    var query by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        apps = withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            pm.queryIntentActivities(launcher, 0)
                .map { info -> LaunchableApp(info.activityInfo.packageName, info.loadLabel(pm).toString()) }
                .filter { it.packageName != context.packageName }
                .distinctBy { it.packageName }
                .sortedBy { it.label.lowercase() }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text(uiText("Apps that bypass VPN"), color = Color.White, fontWeight = FontWeight.Bold) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(uiText("Checked apps connect directly, outside the tunnel."), color = Muted, fontSize = 12.sp)
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp),
                    label = { Text(uiText("Search apps")) },
                    textStyle = TextStyle(color = Color.White, fontSize = 13.sp)
                )
                val list = apps
                if (list == null) {
                    Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                        CircularProgressIndicator(color = Cyan, strokeWidth = 2.dp)
                    }
                } else {
                    val visible = list.filter { query.isBlank() || it.label.contains(query, ignoreCase = true) }
                    LazyColumn(Modifier.fillMaxWidth().heightIn(max = 340.dp)) {
                        items(visible, key = { it.packageName }) { app ->
                            val isChecked = app.packageName in checked
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        checked = if (isChecked) checked - app.packageName else checked + app.packageName
                                    }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(
                                    checked = isChecked,
                                    onCheckedChange = { on ->
                                        checked = if (on) checked + app.packageName else checked - app.packageName
                                    },
                                    colors = CheckboxDefaults.colors(checkedColor = Cyan)
                                )
                                Spacer(Modifier.width(6.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(app.label, color = Color.White, fontSize = 13.sp, maxLines = 1)
                                    Text(app.packageName, color = Muted, fontSize = 9.sp, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(checked) }) { Text(uiText("Save"), color = Cyan, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(uiText("Cancel"), color = Muted) } }
    )
}

@Composable
private fun PermissionRow(title: String, description: String, granted: Boolean, actionLabel: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).background((if (granted) Mint else Warning).copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) {
            AppIcon(if (granted) "check" else "shield", if (granted) Mint else Warning, Modifier.size(18.dp))
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(uiText(title), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(uiText(description), color = Muted, fontSize = 10.sp)
        }
        TextButton(onClick = onClick) { Text(uiText(actionLabel), color = if (granted) Mint else Cyan, fontSize = 11.sp) }
    }
}

@Composable
private fun ActionSettingRow(title: String, description: String, actionLabel: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(uiText(title), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(uiText(description), color = Muted, fontSize = 10.sp)
        }
        TextButton(onClick = onClick) { Text(uiText(actionLabel), color = Cyan, fontSize = 11.sp) }
    }
}

@Composable
private fun SettingRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(uiText(label), color = Muted, fontSize = 11.sp)
        Text(uiText(value), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Medium, textAlign = TextAlign.End)
    }
}

@Composable
private fun EmptyState(title: String, subtitle: String) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = Panel), border = BorderStroke(1.dp, PanelBorder.copy(alpha = .50f))) {
        Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
            AppIcon("server", Cyan, Modifier.size(34.dp))
            Text(uiText(title), color = Color.White, fontWeight = FontWeight.Bold)
            if (subtitle.isNotBlank()) Text(uiText(subtitle), color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center, lineHeight = 17.sp)
        }
    }
}

@Composable
private fun AppIcon(name: String, tint: Color, modifier: Modifier = Modifier, strokeMultiplier: Float = 1f) {
    Canvas(modifier) {
        val unit = size.minDimension
        val stroke = unit * .085f * strokeMultiplier
        val left = (size.width - unit) / 2f
        val top = (size.height - unit) / 2f
        fun point(x: Float, y: Float) = Offset(left + unit * x, top + unit * y)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(tint, point(x1, y1), point(x2, y2), stroke, StrokeCap.Round)
        when (name) {
            "power" -> {
                val ring = Path().apply {
                    moveTo(point(.69f, .23f).x, point(.69f, .23f).y)
                    cubicTo(point(.81f, .32f).x, point(.81f, .32f).y, point(.88f, .46f).x, point(.88f, .46f).y, point(.88f, .60f).x, point(.88f, .60f).y)
                    cubicTo(point(.88f, .81f).x, point(.88f, .81f).y, point(.71f, .94f).x, point(.71f, .94f).y, point(.5f, .94f).x, point(.5f, .94f).y)
                    cubicTo(point(.29f, .94f).x, point(.29f, .94f).y, point(.12f, .81f).x, point(.12f, .81f).y, point(.12f, .60f).x, point(.12f, .60f).y)
                    cubicTo(point(.12f, .46f).x, point(.12f, .46f).y, point(.19f, .32f).x, point(.19f, .32f).y, point(.31f, .23f).x, point(.31f, .23f).y)
                }
                drawPath(ring, tint, style = Stroke(stroke * 1.15f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                line(.5f, .07f, .5f, .52f)
            }
            "home" -> {
                val p = Path().apply { moveTo(point(.12f, .45f).x, point(.12f, .45f).y); lineTo(point(.5f, .13f).x, point(.5f, .13f).y); lineTo(point(.88f, .45f).x, point(.88f, .45f).y); lineTo(point(.88f, .87f).x, point(.88f, .87f).y); lineTo(point(.59f, .87f).x, point(.59f, .87f).y); lineTo(point(.59f, .61f).x, point(.59f, .61f).y); lineTo(point(.41f, .61f).x, point(.41f, .61f).y); lineTo(point(.41f, .87f).x, point(.41f, .87f).y); lineTo(point(.12f, .87f).x, point(.12f, .87f).y); close() }
                drawPath(p, tint, style = Stroke(stroke, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            }
            "servers", "server" -> {
                listOf(.18f, .48f, .78f).forEach { y ->
                    drawRoundRect(tint, point(.16f, y), Size(unit * .68f, unit * .19f), androidx.compose.ui.geometry.CornerRadius(unit * .045f), style = Stroke(stroke))
                    drawCircle(tint, unit * .025f, point(.27f, y + .095f))
                    line(.39f, y + .095f, .73f, y + .095f)
                }
            }
            "activity" -> {
                val p = Path().apply {
                    moveTo(point(.10f, .55f).x, point(.10f, .55f).y)
                    lineTo(point(.29f, .55f).x, point(.29f, .55f).y)
                    lineTo(point(.40f, .25f).x, point(.40f, .25f).y)
                    lineTo(point(.57f, .78f).x, point(.57f, .78f).y)
                    lineTo(point(.69f, .48f).x, point(.69f, .48f).y)
                    lineTo(point(.90f, .48f).x, point(.90f, .48f).y)
                }
                drawPath(p, tint, style = Stroke(stroke, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
            }
            "settings" -> {
                val gear = Path()
                repeat(8) { tooth ->
                    val centerAngle = -Math.PI / 2.0 + tooth * Math.PI / 4.0
                    val points = listOf(
                        (-12.0 to .34f), (-7.0 to .46f), (7.0 to .46f), (12.0 to .34f)
                    )
                    points.forEachIndexed { index, (offset, radius) ->
                        val angle = centerAngle + Math.toRadians(offset)
                        val x = .5f + kotlin.math.cos(angle).toFloat() * radius
                        val y = .5f + kotlin.math.sin(angle).toFloat() * radius
                        if (tooth == 0 && index == 0) gear.moveTo(point(x, y).x, point(x, y).y)
                        else gear.lineTo(point(x, y).x, point(x, y).y)
                    }
                }
                gear.close()
                drawPath(gear, tint, style = Stroke(stroke * .9f, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                drawCircle(tint, unit * .145f, point(.5f, .5f), style = Stroke(stroke * .95f))
            }
            "shield" -> {
                val p = Path().apply {
                    moveTo(point(.5f, .08f).x, point(.5f, .08f).y)
                    lineTo(point(.84f, .22f).x, point(.84f, .22f).y)
                    lineTo(point(.80f, .58f).x, point(.80f, .58f).y)
                    lineTo(point(.5f, .91f).x, point(.5f, .91f).y)
                    lineTo(point(.20f, .58f).x, point(.20f, .58f).y)
                    lineTo(point(.16f, .22f).x, point(.16f, .22f).y)
                    close()
                }
                drawPath(p, tint, style = Stroke(stroke, cap = StrokeCap.Round, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                line(.34f, .49f, .46f, .61f)
                line(.46f, .61f, .68f, .37f)
            }
            "bolt" -> {
                val p = Path().apply {
                    moveTo(point(.55f, .06f).x, point(.55f, .06f).y)
                    lineTo(point(.23f, .55f).x, point(.23f, .55f).y)
                    lineTo(point(.46f, .55f).x, point(.46f, .55f).y)
                    lineTo(point(.39f, .94f).x, point(.39f, .94f).y)
                    lineTo(point(.78f, .40f).x, point(.78f, .40f).y)
                    lineTo(point(.55f, .40f).x, point(.55f, .40f).y)
                    close()
                }
                drawPath(p, tint)
            }
            "chevron" -> { line(.36f, .18f, .66f, .50f); line(.66f, .50f, .36f, .82f) }
            "plus" -> { line(.5f, .16f, .5f, .84f); line(.16f, .5f, .84f, .5f) }
            "close" -> { line(.22f, .22f, .78f, .78f); line(.78f, .22f, .22f, .78f) }
            "check" -> { line(.18f, .52f, .41f, .74f); line(.41f, .74f, .83f, .27f) }
            "file" -> {
                val p = Path().apply {
                    moveTo(point(.25f, .10f).x, point(.25f, .10f).y)
                    lineTo(point(.61f, .10f).x, point(.61f, .10f).y)
                    lineTo(point(.78f, .28f).x, point(.78f, .28f).y)
                    lineTo(point(.78f, .90f).x, point(.78f, .90f).y)
                    lineTo(point(.25f, .90f).x, point(.25f, .90f).y)
                    close()
                }
                drawPath(p, tint, style = Stroke(stroke, join = androidx.compose.ui.graphics.StrokeJoin.Round))
                line(.61f, .10f, .61f, .29f); line(.61f, .29f, .78f, .29f)
                line(.36f, .49f, .66f, .49f); line(.36f, .66f, .66f, .66f)
            }
        }
    }
}

private fun statusLabel(phase: VpnPhase): String = when (phase) {
    VpnPhase.CONNECTED -> "Connected"
    VpnPhase.CONNECTING -> "Connecting"
    VpnPhase.RECONNECTING -> "Reconnecting"
    VpnPhase.ERROR -> "Connection error"
    VpnPhase.DISCONNECTED -> "Disconnected"
}

private fun nodeLocationHint(name: String): String? {
    var index = 0
    while (index < name.length) {
        val first = Character.codePointAt(name, index)
        val nextIndex = index + Character.charCount(first)
        if (nextIndex >= name.length) break
        val second = Character.codePointAt(name, nextIndex)
        if (first in 0x1F1E6..0x1F1FF && second in 0x1F1E6..0x1F1FF) {
            val code = "${(first - 0x1F1E6 + 'A'.code).toChar()}${(second - 0x1F1E6 + 'A'.code).toChar()}"
            val country = java.util.Locale("", code).getDisplayCountry(java.util.Locale.US)
            if (country.isNotBlank()) return country
        }
        index = nextIndex
    }
    return null
}

private fun dnsLabel(host: String): String = when (host) {
    "8.8.8.8" -> "Google"
    "9.9.9.9" -> "Quad9"
    "94.140.14.14" -> "AdGuard"
    "208.67.222.222" -> "OpenDNS"
    else -> "Cloudflare"
}

private fun compatLabel(mode: String): String = when (mode) {
    "standard" -> "Standard"
    "fragment" -> "Anti-filter"
    "strong" -> "Strong"
    else -> "Auto"
}

private fun intervalLabel(minutes: Int): String =
    if (minutes >= 60 && minutes % 60 == 0) "${minutes / 60} h" else "$minutes min"

private fun pingLimitLabel(millis: Int): String =
    if (millis == 0) "No limit" else "$millis ms"

private fun readConfigFile(context: android.content.Context, uri: android.net.Uri): String {
    val maxBytes = 15 * 1024 * 1024
    val input = context.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Could not open the selected file.")
    val output = java.io.ByteArrayOutputStream()
    input.use { stream ->
        val buffer = ByteArray(8192)
        var total = 0
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            total += count
            require(total <= maxBytes) { "Configuration file exceeds the 15 MB limit." }
            output.write(buffer, 0, count)
        }
    }
    return output.toString(Charsets.UTF_8.name())
}
