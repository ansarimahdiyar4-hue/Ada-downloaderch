package com.bepar.vpn.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import org.json.JSONObject
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.concurrent.Callable
import java.util.concurrent.ExecutorCompletionService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class ServerProbeResult(
    val node: ServerNode,
    val reachable: Boolean,
    val latencyMillis: Long?
)

data class BestServerSelection(
    val node: ServerNode,
    val measuredLatencyMillis: Long?,
    val testedServers: Int,
    val usedFallback: Boolean
)

/**
 * Best-effort server selection based on TCP handshake time.
 * This ranks reachable TCP endpoints; it is not a bandwidth or full Xray throughput test.
 * UDP-only protocols cannot be ranked by this check and use the saved profile as fallback.
 */
object BestServerSelector {
    private const val CONNECT_TIMEOUT_MS = 1_800
    private const val TOTAL_BUDGET_MS = 5_000
    private const val MAX_CANDIDATES = 80
    private const val PROBE_THREADS = 24

    // Feed pruning (see probeGroups): many candidates, short budget, many threads.
    const val FEED_BUDGET_MS = 8_000L
    const val FEED_CONFIRM_BUDGET_MS = 3_000L
    private const val FEED_PROBE_THREADS = 24

    /**
     * Fair sample for native libXray pingBatch checks. A profile is tested through its full
     * outbound configuration, so TCP, WebSocket, gRPC, Reality and UDP transports are eligible.
     */
    fun sampleForXray(
        profiles: List<ServerNode>,
        preferredId: String? = null,
        maxCandidates: Int = 60
    ): List<ServerNode> {
        if (profiles.isEmpty() || maxCandidates <= 0) return emptyList()
        val preferred = profiles.firstOrNull { it.id == preferredId }
        val groups = profiles.groupBy { it.subscriptionUrl ?: "__manual__" }.values.toList()
        val fairSample = buildList {
            var row = 0
            while (size < maxCandidates && groups.any { row < it.size }) {
                groups.forEach { group ->
                    if (size < maxCandidates) group.getOrNull(row)?.let(::add)
                }
                row++
            }
        }
        return (listOfNotNull(preferred) + fairSample)
            .distinctBy { it.id }
            .take(maxCandidates)
    }

    fun findPhysicalNetwork(context: Context): Network? {
        val manager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return null
        val active = manager.activeNetwork
        val activeCapabilities = active?.let(manager::getNetworkCapabilities)
        if (active != null && activeCapabilities != null &&
            activeCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
            activeCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) &&
            activeCapabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        ) return active

        return manager.allNetworks.asSequence()
            .mapNotNull { network ->
                val capabilities = manager.getNetworkCapabilities(network) ?: return@mapNotNull null
                if (!capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) ||
                    !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
                ) return@mapNotNull null
                network to capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
            }
            .sortedByDescending { it.second }
            .map { it.first }
            .firstOrNull()
    }

    /**
     * Reachable servers sorted by TCP latency (fastest first), at most [limit].
     * When nothing answers, falls back to the saved/first profile so Auto still tries something.
     */
    fun rank(
        profiles: List<ServerNode>,
        preferredId: String?,
        physicalNetwork: Network? = null,
        limit: Int = 6
    ): List<ServerProbeResult> {
        if (profiles.isEmpty()) return emptyList()
        val preferred = profiles.firstOrNull { it.id == preferredId } ?: profiles.first()
        val results = probeCandidates(profiles, physicalNetwork)
        val reachable = results.filter { it.reachable && it.latencyMillis != null }
            .sortedBy { it.latencyMillis }
            .take(limit)
        return reachable.ifEmpty { listOf(ServerProbeResult(preferred, true, null)) }
    }

    fun select(
        profiles: List<ServerNode>,
        preferredId: String?,
        physicalNetwork: Network? = null,
        requirePhysicalNetwork: Boolean = false
    ): BestServerSelection? {
        if (profiles.isEmpty()) return null
        val preferred = profiles.firstOrNull { it.id == preferredId } ?: profiles.first()
        if (requirePhysicalNetwork && physicalNetwork == null) {
            return BestServerSelection(preferred, null, 0, true)
        }

        val results = probeCandidates(profiles, physicalNetwork)
        val fastest = results.filter { it.reachable && it.latencyMillis != null }
            .minByOrNull { it.latencyMillis!! }
        return if (fastest != null) {
            BestServerSelection(fastest.node, fastest.latencyMillis, results.size, false)
        } else {
            BestServerSelection(preferred, null, results.size, true)
        }
    }

    /** TCP port of a node if it can be checked with a TCP connect; null for UDP-only or unparsable nodes. */
    private fun eligiblePort(node: ServerNode): Int? {
        if (node.protocol.lowercase() in UDP_ONLY_PROTOCOLS) return null
        if (isUdpTransport(node.outboundJson)) return null
        val port = extractPort(node.outboundJson)
        return if (node.host.isBlank() || port == null || port !in 1..65535) null else port
    }

    /**
     * Probes many candidates at once, grouped by feed. The candidates of all groups are shuffled and
     * interleaved, so a time cut-off treats every feed alike. Returns, per group, only the servers that
     * answered, sorted by TCP connect time (lowest ping first). UDP-only servers are not testable and
     * are left out.
     */
    fun probeGroups(
        groups: Map<String, List<ServerNode>>,
        physicalNetwork: Network?,
        connectTimeoutMs: Int,
        budgetMs: Long = FEED_BUDGET_MS
    ): Map<String, List<ServerProbeResult>> {
        val perGroup = groups.mapValues { (_, nodes) ->
            nodes.shuffled().mapNotNull { node -> eligiblePort(node)?.let { port -> node to port } }
        }
        val queue = ArrayList<Triple<String, ServerNode, Int>>()
        var row = 0
        while (perGroup.values.any { row < it.size }) {
            perGroup.forEach { (key, list) ->
                list.getOrNull(row)?.let { entry -> queue.add(Triple(key, entry.first, entry.second)) }
            }
            row++
        }

        val found = LinkedHashMap<String, MutableList<ServerProbeResult>>()
        groups.keys.forEach { found[it] = mutableListOf() }
        if (queue.isEmpty()) return found

        val pool = Executors.newFixedThreadPool(minOf(FEED_PROBE_THREADS, queue.size)) { task ->
            Thread(task, "bepar-feed-probe").apply { isDaemon = true }
        }
        val completion = ExecutorCompletionService<Pair<String, ServerProbeResult>>(pool)
        val pending = ArrayList<java.util.concurrent.Future<Pair<String, ServerProbeResult>>>()
        try {
            queue.forEach { entry ->
                val key = entry.first
                val node = entry.second
                val port = entry.third
                pending.add(
                    completion.submit(Callable { key to probe(node, port, physicalNetwork, connectTimeoutMs) })
                )
            }
            val deadline = System.nanoTime() + TimeUnit.MILLISECONDS.toNanos(budgetMs)
            var completed = 0
            while (completed < pending.size) {
                val remainingNanos = deadline - System.nanoTime()
                if (remainingNanos <= 0L) break
                val finished = completion.poll(remainingNanos, TimeUnit.NANOSECONDS) ?: break
                completed++
                val outcome = runCatching { finished.get() }.getOrNull() ?: continue
                val result = outcome.second
                if (result.reachable && result.latencyMillis != null) {
                    found[outcome.first]?.add(result)
                }
            }
        } finally {
            pending.forEach { it.cancel(true) }
            pool.shutdownNow()
        }
        return found.mapValues { entry -> entry.value.sortedBy { it.latencyMillis } }
    }

    /** Probes a fair sample of profiles; returns the results that finished within the time budget. */
    private fun probeCandidates(profiles: List<ServerNode>, physicalNetwork: Network?): List<ServerProbeResult> {
        // Public source lists can be hundreds of rows long. Sample fairly across
        // subscriptions first so the first repository cannot monopolize all probes.
        val groups = profiles.groupBy { it.subscriptionUrl ?: "__manual__" }.values.toList()
        val sampled = buildList {
            var row = 0
            while (size < MAX_CANDIDATES && groups.any { row < it.size }) {
                groups.forEach { group ->
                    if (size < MAX_CANDIDATES) group.getOrNull(row)?.let(::add)
                }
                row++
            }
        }
        val candidates = sampled.asSequence()
            .mapNotNull { node -> eligiblePort(node)?.let { port -> node to port } }
            .toList()
        if (candidates.isEmpty()) return emptyList()

        val pool = Executors.newFixedThreadPool(minOf(PROBE_THREADS, candidates.size)) { task ->
            Thread(task, "bepar-server-probe").apply { isDaemon = true }
        }
        val completion = ExecutorCompletionService<ServerProbeResult>(pool)
        val pending = mutableListOf<java.util.concurrent.Future<ServerProbeResult>>()
        val results = mutableListOf<ServerProbeResult>()
        try {
            val started = System.nanoTime()
            candidates.forEach { (node, port) ->
                pending += completion.submit(Callable { probe(node, port, physicalNetwork) })
            }
            var completed = 0
            val deadline = started + TimeUnit.MILLISECONDS.toNanos(TOTAL_BUDGET_MS.toLong())
            while (completed < pending.size) {
                val remainingNanos = deadline - System.nanoTime()
                if (remainingNanos <= 0L) break
                val finished = completion.poll(remainingNanos, TimeUnit.NANOSECONDS) ?: break
                completed++
                runCatching { finished.get() }.getOrNull()?.let(results::add)
            }
        } finally {
            pending.forEach { it.cancel(true) }
            pool.shutdownNow()
        }
        return results
    }

    private fun probe(
        node: ServerNode,
        port: Int,
        physicalNetwork: Network?,
        connectTimeoutMs: Int = CONNECT_TIMEOUT_MS
    ): ServerProbeResult {
        val host = node.host.removePrefix("[").removeSuffix("]")
        return try {
            // Resolve DNS on the physical network as well as routing the TCP socket
            // through it; otherwise an active VPN could hijack the DNS lookup.
            val addresses = if (physicalNetwork != null) {
                physicalNetwork.getAllByName(host)
            } else {
                InetAddress.getAllByName(host)
            }
            // Two addresses are enough to call a host reachable; more only slow down dead ones.
            for (address in addresses.take(2)) {
                val started = System.nanoTime()
                try {
                    val socket = physicalNetwork?.socketFactory?.createSocket() ?: Socket()
                    socket.use {
                        it.tcpNoDelay = true
                        it.connect(InetSocketAddress(address, port), connectTimeoutMs)
                    }
                    val latency = TimeUnit.NANOSECONDS.toMillis(System.nanoTime() - started)
                    return ServerProbeResult(node, true, latency.coerceAtLeast(1L))
                } catch (_: Exception) {
                    // Try the next resolved address before marking the endpoint offline.
                }
            }
            ServerProbeResult(node, false, null)
        } catch (_: Exception) {
            ServerProbeResult(node, false, null)
        }
    }


    private fun isUdpTransport(outboundJson: String): Boolean = runCatching {
        val streamNetwork = JSONObject(outboundJson)
            .optJSONObject("streamSettings")
            ?.optString("network")
            ?.lowercase()
            .orEmpty()
        streamNetwork in UDP_ONLY_TRANSPORTS
    }.getOrDefault(false)

    private fun extractPort(outboundJson: String): Int? {
        return runCatching {
            val root = JSONObject(outboundJson)
            val settings = root.optJSONObject("settings") ?: JSONObject()
            val candidates = buildList {
                settings.optJSONArray("vnext")?.let { array ->
                    for (index in 0 until array.length()) array.optJSONObject(index)?.let(::add)
                }
                settings.optJSONArray("servers")?.let { array ->
                    for (index in 0 until array.length()) array.optJSONObject(index)?.let(::add)
                }
                settings.optJSONObject("server")?.let(::add)
                add(settings)
                add(root)
            }
            candidates.firstNotNullOfOrNull { item ->
                val port = when {
                    item.has("port") -> item.optInt("port", -1)
                    else -> -1
                }
                port.takeIf { it in 1..65535 }
            }
        }.getOrNull()
    }

    private val UDP_ONLY_PROTOCOLS = setOf("hysteria", "hysteria2", "tuic", "wireguard")
    private val UDP_ONLY_TRANSPORTS = setOf("kcp", "quic", "httpupgrade-udp")
}
