package com.bepar.vpn.vpn

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkRequest
import android.net.NetworkCapabilities
import android.net.VpnService
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.content.pm.ServiceInfo
import androidx.core.app.NotificationCompat
import com.bepar.vpn.MainActivity
import com.bepar.vpn.R
import com.bepar.vpn.core.XrayApi
import com.bepar.vpn.core.XrayConfigBuilder
import com.bepar.vpn.core.Tuning
import com.bepar.vpn.core.TunnelProbe
import com.bepar.vpn.core.XrayMetricsReader
import com.bepar.vpn.data.ServerNode
import com.bepar.vpn.data.NodeStore
import com.bepar.vpn.data.AppPreferences
import com.bepar.vpn.data.BestServerSelector
import com.bepar.vpn.data.RemoteConfigFeedRepository
import libXray.DialerController
import libXray.LibXray
import org.json.JSONObject
import java.io.File
import java.util.LinkedHashMap
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledExecutorService
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Android TUN owner. Xray runs in-process through the official libXray AAR;
 * no Windows executable is copied or launched on Android.
 */
private data class AutoCandidate(val node: ServerNode, val latencyMillis: Long?)

class BeparVpnService : VpnService() {
    companion object {
        const val ACTION_CONNECT = "com.bepar.vpn.action.CONNECT"
        const val ACTION_DISCONNECT = "com.bepar.vpn.action.DISCONNECT"
        const val ACTION_CONNECT_BEST = "com.bepar.vpn.action.CONNECT_BEST"
        const val ACTION_TOGGLE_BEST = "com.bepar.vpn.action.TOGGLE_BEST"
        const val EXTRA_NODE_ID = "node_id"
        private const val AUTO_NODE_MARKER = "__BEST_SERVER_SELECTION__"
        private const val AUTO_MAX_ATTEMPTS = 8
        private const val AUTO_FALLBACK_ATTEMPTS = 8

        private const val CHANNEL_ID = "bepar_vpn_connection"
        private const val NOTIFICATION_ID = 4107
    }

    private val worker = Executors.newSingleThreadExecutor()
    private val metricsScheduler: ScheduledExecutorService = Executors.newSingleThreadScheduledExecutor { task ->
        Thread(task, "bepar-xray-metrics").apply { isDaemon = true }
    }
    private val reconnectQueued = AtomicBoolean(false)
    @Volatile private var metricsTask: ScheduledFuture<*>? = null
    @Volatile private var activeMetricsPort: Int = -1
    @Volatile private var lastMetricUpload: Long = -1L
    @Volatile private var lastMetricDownload: Long = -1L
    private val metricsLock = Any()

    @Volatile private var tunDescriptor: ParcelFileDescriptor? = null
    @Volatile private var coreStarted = false
    @Volatile private var coreStartAttempted = false
    @Volatile private var activeConfigJson: String? = null
    @Volatile private var activePhysicalNetwork: Network? = null
    private val physicalNetworks = LinkedHashMap<Network, Boolean>()
    @Volatile private var callbackRegistered = false
    @Volatile private var requestedNodeId: String? = null
    @Volatile private var autoGeneration: Long = 0L
    @Volatile private var preserveSessionOnNextConnect = false

    private var connectivityManager: ConnectivityManager? = null
    private var networkCallback: ConnectivityManager.NetworkCallback? = null

    private val socketController = object : DialerController {
        // gomobile maps Go int to Java long. Android VpnService.protect expects Int.
        override fun protectFd(fd: Long): Boolean {
            return this@BeparVpnService.protect(fd.toInt())
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        connectivityManager = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        // A process restart destroys the in-memory Xray core and TUN descriptor.
        // Clear persisted state rather than showing a stale "connected" status.
        if (AppPreferences.isVpnActive(this) || AppPreferences.isVpnConnecting(this)) {
            AppPreferences.endSession(this)
            AppPreferences.setVpnStatus(this, active = false, connecting = false)
            ConnectionState.update(VpnPhase.DISCONNECTED, "VPN process restarted")
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        // startForegroundService() obliges us to call startForeground() within a few
        // seconds on EVERY path (including early returns/errors) or Android kills the
        // app with ForegroundServiceDidNotStartInTimeException.
        if (intent?.action != ACTION_DISCONNECT) enterForegroundEarly()
        when (intent?.action) {
            ACTION_DISCONNECT -> {
                requestedNodeId = null
                runOnWorker { disconnectInternal(stopService = true) }
                return START_NOT_STICKY
            }
            ACTION_TOGGLE_BEST -> {
                if (AppPreferences.isVpnActive(this) || AppPreferences.isVpnConnecting(this)) {
                    requestedNodeId = null
                    runOnWorker { disconnectInternal(stopService = true) }
                } else {
                    beginConnectBest(startId)
                }
                return START_STICKY
            }
            ACTION_CONNECT_BEST -> {
                beginConnectBest(startId)
                return START_STICKY
            }
            ACTION_CONNECT, null -> {
                val nodeId = intent?.getStringExtra(EXTRA_NODE_ID)
                    ?: NodeStore.selectedId(this)
                if (nodeId.isNullOrBlank()) {
                    AppPreferences.endSession(this)
                    preserveSessionOnNextConnect = false
                    publishState(VpnPhase.ERROR, "Add and select a server profile first.")
                    stopSelf(startId)
                    return START_NOT_STICKY
                }

                beginConnect(nodeId, startId)
                return START_STICKY
            }
            else -> {
                stopSelf(startId)
                return START_NOT_STICKY
            }
        }
    }

    private fun enterForegroundEarly() {
        try {
            startAsForeground("Preparing secure tunnel…")
        } catch (_: Throwable) {
            // Foreground promotion can be refused (e.g. background start limits); never crash.
        }
    }

    /** Runs work on the single worker thread without ever crashing the process. */
    private fun runOnWorker(block: () -> Unit) {
        try {
            worker.execute {
                try {
                    block()
                } catch (error: Throwable) {
                    publishState(VpnPhase.ERROR, error.message?.take(180) ?: "Unexpected error")
                    try { releaseCoreAndTun() } catch (_: Throwable) {}
                    try { stopForeground(true) } catch (_: Throwable) {}
                    stopSelf()
                }
            }
        } catch (_: Throwable) {
            // Executor already shut down (service is being destroyed).
        }
    }

    override fun onBind(intent: Intent?): IBinder? {
        return if (intent?.action == SERVICE_INTERFACE) super.onBind(intent) else null
    }

    override fun onRevoke() {
        requestedNodeId = null
        runOnWorker { disconnectInternal(stopService = true) }
        super.onRevoke()
    }

    override fun onDestroy() {
        requestedNodeId = null
        stopTrafficSampler()
        metricsScheduler.shutdownNow()
        unregisterNetworkCallbackSafely()
        worker.execute {
            AppPreferences.endSession(this)
            releaseCoreAndTun()
            AppPreferences.setVpnStatus(this, active = false, connecting = false)
            val phase = ConnectionState.state.value.phase
            if (phase == VpnPhase.CONNECTED || phase == VpnPhase.CONNECTING || phase == VpnPhase.RECONNECTING) {
                ConnectionState.update(VpnPhase.DISCONNECTED, "VPN service stopped")
            }
            BeparVpnTileService.requestRefresh(this)
        }
        worker.shutdown()
        super.onDestroy()
    }

    /** Establish the Android interface before declaring the system-exempted FGS.
     * Android permits this foreground-service type for an active VPN app. */
    private fun beginConnect(nodeId: String, startId: Int) {
        preserveSessionOnNextConnect = AppPreferences.isVpnActive(this)
        requestedNodeId = nodeId
        try {
            val switchingProfile = tunDescriptor != null
            if (tunDescriptor == null) {
                captureInitialPhysicalNetwork()
                tunDescriptor = establishTun()
            }
            val status = if (switchingProfile) "Switching to selected server…" else "Preparing secure tunnel…"
            publishState(VpnPhase.CONNECTING, status)
            startAsForeground(status)
            runOnWorker { connectNode(nodeId) }
        } catch (error: Throwable) {
            if (requestedNodeId != nodeId) return
            releaseCoreAndTun()
            val reason = error.message?.take(180)?.ifBlank { null } ?: "Could not establish the VPN interface."
            AppPreferences.endSession(this)
            publishState(VpnPhase.ERROR, reason)
            stopSelf(startId)
        }
    }

    private fun beginConnectBest(startId: Int) {
        preserveSessionOnNextConnect = AppPreferences.isVpnActive(this)
        requestedNodeId = AUTO_NODE_MARKER
        try {
            if (tunDescriptor == null) {
                captureInitialPhysicalNetwork()
                tunDescriptor = establishTun()
            }
            val status = "Updating servers and finding the best one…"
            publishState(VpnPhase.CONNECTING, status)
            startAsForeground(status)
            val generation = ++autoGeneration
            runOnWorker { runAutoConnect(generation) }
        } catch (error: Throwable) {
            if (requestedNodeId != AUTO_NODE_MARKER) return
            requestedNodeId = null
            releaseCoreAndTun()
            AppPreferences.endSession(this)
            publishState(
                VpnPhase.ERROR,
                error.message?.take(180) ?: "Could not prepare a secure tunnel."
            )
            stopSelf(startId)
        }
    }

    /**
     * Auto mode refreshes feeds, measures actual proxy latency with libXray pingBatch, then
     * starts Xray and verifies that ordinary HTTPS traffic passes through the Android TUN.
     */
    private fun isCurrentAutoRequest(generation: Long): Boolean =
        requestedNodeId == AUTO_NODE_MARKER && autoGeneration == generation

    private fun runAutoConnect(generation: Long) {
        try {
            val probeNetwork = activePhysicalNetwork ?: BestServerSelector.findPhysicalNetwork(this)
            try {
                RemoteConfigFeedRepository.refreshIfDue(this, probeNetwork)
            } catch (_: Throwable) {
                // Cached profiles remain eligible; every selected candidate is verified below.
            }
            if (!isCurrentAutoRequest(generation)) return
            val profiles = NodeStore.load(this)
            if (profiles.isEmpty()) {
                throw IllegalStateException(
                    "No server profiles were downloaded. Check the network and refresh the public sources, or import a profile."
                )
            }

            val candidates = BestServerSelector.sampleForXray(
                profiles,
                preferredId = NodeStore.selectedId(this)
            )
            if (candidates.isEmpty()) throw IllegalStateException("No supported Xray profiles were found.")

            // A live managed Xray instance blocks libXray pingBatch by design. Stop it before
            // testing candidates; the session is preserved and traffic sampling restarts on success.
            stopTrafficSampler()
            stopCoreOnly()
            val probeDns = dnsForAttempt(0)
            prepareXrayNetwork(probeDns)
            publishState(VpnPhase.CONNECTING, "Testing ${candidates.size} profiles through Xray…")
            updateNotification("Testing real proxy latency…")

            // libXray pingBatch sends an HTTP HEAD through each actual outbound. It is not a TCP
            // port-open check. This must happen before runXray because libXray serializes probes
            // with the managed live-core lifecycle.
            val pingResults = XrayApi.pingOutbounds(candidates, timeoutSeconds = 6) { completed, total ->
                if (isCurrentAutoRequest(generation)) {
                    val message = "Testing proxy $completed/$total…"
                    publishState(VpnPhase.CONNECTING, message)
                    updateNotification(message)
                }
            }
            if (!isCurrentAutoRequest(generation)) return
            NodeStore.updatePingMeasurements(
                this,
                pingResults.associate { it.node.id to it.latencyMillis },
                clearUnmeasured = true
            )

            val passed = pingResults
                .filter { it.success && it.latencyMillis != null }
                .sortedBy { it.latencyMillis }
            val ranked = if (passed.isNotEmpty()) {
                passed.take(AUTO_MAX_ATTEMPTS).map {
                    AutoCandidate(it.node, it.latencyMillis!!)
                }
            } else {
                // Some endpoints reject HEAD while accepting ordinary HTTPS. Do not call these
                // profiles live; try only a small fallback sample and require the full tunnel test.
                val preferred = profiles.firstOrNull { it.id == NodeStore.selectedId(this) }
                (listOfNotNull(preferred) + candidates.filterNot { it.id == preferred?.id })
                    .distinctBy { it.id }
                    .take(AUTO_FALLBACK_ATTEMPTS)
                    .map { AutoCandidate(it, null) }
            }
            if (ranked.isEmpty()) throw IllegalStateException("No candidate profile could be tested.")

            var lastFailure = "The candidate did not pass the HTTPS tunnel test."
            for ((index, candidate) in ranked.withIndex()) {
                if (!isCurrentAutoRequest(generation)) return
                publishState(VpnPhase.CONNECTING, "Verifying server ${index + 1}/${ranked.size} through the VPN…")
                updateNotification("Verifying server ${index + 1}/${ranked.size}…")

                val attempts = tuningLadder(candidate.node).take(3)
                for ((attemptIndex, tuning) in attempts.withIndex()) {
                    try {
                        if (attemptIndex > 0) {
                            publishState(VpnPhase.CONNECTING, "Adapting server ${index + 1} to this network…")
                        }
                        startCore(candidate.node, tuning, attemptIndex)
                        if (!isCurrentAutoRequest(generation)) {
                            stopCoreOnly()
                            return
                        }
                        val probe = TunnelProbe.quickCheck()
                        if (!isCurrentAutoRequest(generation)) {
                            stopCoreOnly()
                            return
                        }
                        if (probe.reachable) {
                            AppPreferences.setLastGoodTuning(this, isCellularNetwork(), tuning.id)
                            val note = candidate.latencyMillis?.let { "Xray $it ms" } ?: "fallback verified"
                            val mode = if (tuning.fragment) " • network-compatible TLS" else ""
                            markConnected(candidate.node, "Connected • $note$mode • HTTPS verified")
                            return
                        }
                        lastFailure = probe.detail
                    } catch (error: Throwable) {
                        lastFailure = error.message?.take(120) ?: "Server failed to start."
                    }
                    if (!isCurrentAutoRequest(generation)) return
                    stopCoreOnly()
                }
            }
            throw IllegalStateException(
                "No profile passed the real VPN data test. Last result: $lastFailure"
            )
        } catch (error: Throwable) {
            if (!isCurrentAutoRequest(generation)) return
            requestedNodeId = null
            releaseCoreAndTun()
            unregisterNetworkCallbackSafely()
            AppPreferences.endSession(this)
            publishState(VpnPhase.ERROR, error.message?.take(180) ?: "Could not select a working server.")
            updateNotification("Connection failed")
            stopForeground(true)
            stopSelf()
        }
    }

    /** Starts the Xray core for [node] on the already-established TUN. Throws on failure. */
    private fun startCore(node: ServerNode, tuning: Tuning = Tuning.STANDARD, dnsRotation: Int = 0) {
        // A profile switch keeps Android's TUN fd but replaces the Xray runtime.
        stopCoreOnly()
        val tun = tunDescriptor
            ?: throw IllegalStateException("The VPN interface is not ready. Try again.")
        val assetDir = prepareGeoAssets()

        // Protect every Xray-created socket so it uses the physical network,
        // not the TUN interface that Xray itself is consuming.
        val dns = dnsForAttempt(dnsRotation)
        prepareXrayNetwork(dns)
        val metricsPort = XrayMetricsReader.allocatePort()

        val config = XrayConfigBuilder.build(
            outboundJson = node.outboundJson,
            tunFd = tun.fd,
            assetDirectory = assetDir.absolutePath,
            dnsHost = dns,
            tuning = tuning,
            mtu = tunMtu,
            metricsPort = metricsPort
        )
        activeConfigJson = config
        activeMetricsPort = metricsPort

        coreStartAttempted = true
        XrayApi.invoke("runXray", JSONObject().put("xrayJson", config))
        coreStarted = true

        // Verify the managed Core state instead of treating an accepted request
        // as proof that a live tunnel is already running.
        val state = XrayApi.invoke("getXrayState").optJSONObject("data")
            ?: throw IllegalStateException("Xray did not return its runtime state.")
        if (!state.optBoolean("running", false)) {
            throw IllegalStateException("The Xray core did not start.")
        }
    }

    private fun markConnected(node: ServerNode, message: String) {
        registerNetworkCallback()
        NodeStore.select(this, node.id)
        if (!preserveSessionOnNextConnect) AppPreferences.beginSession(this)
        preserveSessionOnNextConnect = false
        startTrafficSampler()
        publishState(VpnPhase.CONNECTED, message)
        updateNotification("Connected • ${node.name}")
    }

    private fun connectNode(nodeId: String) {
        if (requestedNodeId != nodeId) return
        try {
            publishState(VpnPhase.CONNECTING, "Checking selected profile through Xray…")
            updateNotification("Checking selected server…")
            val node = NodeStore.load(this).firstOrNull { it.id == nodeId }
                ?: throw IllegalArgumentException("The selected profile could not be found.")

            // A profile switch must stop the previous managed core before pingBatch; libXray
            // intentionally rejects temporary ping cores while a managed runXray instance exists.
            stopCoreOnly()
            prepareXrayNetwork(dnsForAttempt(0))
            val ping = runCatching {
                XrayApi.pingOutbounds(listOf(node), timeoutSeconds = 6).firstOrNull()
            }.getOrNull()
            if (ping != null) NodeStore.updatePingMeasurements(this, mapOf(node.id to ping.latencyMillis))

            val ladder = tuningLadder(node)
            var verified = false
            var usedTuning = ladder.first()
            var lastProbeError = "The tunnel did not pass the HTTPS test."
            for ((attemptIndex, tuning) in ladder.withIndex()) {
                if (requestedNodeId != nodeId) return
                if (attemptIndex > 0) publishState(VpnPhase.CONNECTING, "Adapting to this network…")
                startCore(node, tuning, attemptIndex)
                if (requestedNodeId != nodeId) return
                val probe = TunnelProbe.quickCheck()
                if (requestedNodeId != nodeId) return
                if (probe.reachable) {
                    verified = true
                    usedTuning = tuning
                    AppPreferences.setLastGoodTuning(this, isCellularNetwork(), tuning.id)
                    break
                }
                lastProbeError = probe.detail
                if (attemptIndex < ladder.lastIndex) stopCoreOnly()
            }
            if (!verified) {
                throw IllegalStateException(
                    "Xray started but real HTTPS traffic through the VPN failed: $lastProbeError"
                )
            }
            val pingLabel = ping?.latencyMillis?.let { " • Xray $it ms" }.orEmpty()
            val mode = if (usedTuning.fragment) " • network-compatible TLS" else ""
            markConnected(node, "Connected to ${node.name}$pingLabel$mode • HTTPS verified")
        } catch (error: Throwable) {
            if (requestedNodeId != nodeId) return
            releaseCoreAndTun()
            unregisterNetworkCallbackSafely()
            AppPreferences.endSession(this)
            val reason = error.message?.take(180)?.ifBlank { null } ?: "The VPN tunnel could not be verified."
            publishState(VpnPhase.ERROR, reason)
            updateNotification("Connection failed")
            stopForeground(true)
            stopSelf()
        }
    }

    /** MTU used for the current TUN; picked from the network type when the interface is built. */
    @Volatile private var tunMtu = XrayConfigBuilder.TUN_MTU
    @Volatile private var activeDns: String? = null

    private fun prepareXrayNetwork(dns: String) {
        LibXray.registerDialerController(socketController)
        LibXray.registerListenerController(socketController)
        LibXray.setDNS(socketController, "$dns:53")
        activeDns = dns
    }

    private fun startTrafficSampler() {
        if (activeMetricsPort !in 1..65535) return
        synchronized(metricsLock) {
            metricsTask?.cancel(false)
            lastMetricUpload = -1L
            lastMetricDownload = -1L
            metricsTask = metricsScheduler.scheduleWithFixedDelay(
                { sampleTrafficCounters() }, 1L, 1L, TimeUnit.SECONDS
            )
        }
    }

    private fun sampleTrafficCounters() {
        val port = activeMetricsPort
        if (port !in 1..65535 || !coreStarted) return
        val current = XrayMetricsReader.read(port) ?: return
        synchronized(metricsLock) {
            if (lastMetricUpload < 0L || lastMetricDownload < 0L ||
                current.uploadBytes < lastMetricUpload || current.downloadBytes < lastMetricDownload
            ) {
                lastMetricUpload = current.uploadBytes
                lastMetricDownload = current.downloadBytes
                return
            }
            val uploadDelta = current.uploadBytes - lastMetricUpload
            val downloadDelta = current.downloadBytes - lastMetricDownload
            lastMetricUpload = current.uploadBytes
            lastMetricDownload = current.downloadBytes
            AppPreferences.addSessionTraffic(this, uploadDelta, downloadDelta)
        }
    }

    private fun stopTrafficSampler() {
        synchronized(metricsLock) {
            metricsTask?.cancel(false)
            metricsTask = null
            lastMetricUpload = -1L
            lastMetricDownload = -1L
        }
    }

    private fun isCellularNetwork(): Boolean {
        val manager = connectivityManager ?: return false
        val network = activePhysicalNetwork ?: manager.activeNetwork ?: return false
        val caps = manager.getNetworkCapabilities(network) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) &&
            !caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) &&
            !caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    /**
     * The order in which transport tricks are tried for [node]. Only tricks that can apply to the
     * node are included. The tuning that last worked on this kind of network (mobile data vs
     * Wi-Fi) goes first, so the next connection is usually instant.
     */
    private fun tuningLadder(node: ServerNode): List<Tuning> {
        val canFragment = XrayConfigBuilder.supportsFragment(node.outboundJson)
        val cellular = isCellularNetwork()
        val base = when (AppPreferences.compatMode(this)) {
            "standard" -> listOf(Tuning.STANDARD)
            "fragment" -> listOf(Tuning.FRAGMENT, Tuning.STRONG, Tuning.STANDARD)
            "strong" -> listOf(Tuning.STRONG, Tuning.FRAGMENT, Tuning.STANDARD)
            else -> if (cellular) listOf(Tuning.FRAGMENT, Tuning.STANDARD, Tuning.STRONG)
            else listOf(Tuning.STANDARD, Tuning.FRAGMENT, Tuning.STRONG)
        }
        val remembered = if (AppPreferences.compatMode(this) == "auto")
            Tuning.fromId(AppPreferences.lastGoodTuning(this, cellular)) else null
        val ordered = if (remembered != null && remembered in base) listOf(remembered) + base.filter { it != remembered } else base
        val usable = if (canFragment) ordered else ordered.filter { !it.fragment }.ifEmpty { listOf(Tuning.STANDARD) }
        return usable.distinct()
    }

    private fun dnsForAttempt(rotation: Int): String {
        val options = AppPreferences.DNS_OPTIONS
        val start = options.indexOf(AppPreferences.dnsHost(this)).coerceAtLeast(0)
        return options[(start + rotation) % options.size]
    }

    private fun establishTun(): ParcelFileDescriptor {
        // Mobile networks add tunnelling overhead of their own; a smaller MTU avoids silent packet drops.
        tunMtu = if (isCellularNetwork() || AppPreferences.compatMode(this) == "strong")
            XrayConfigBuilder.TUN_MTU_CELLULAR else XrayConfigBuilder.TUN_MTU
        val builder = Builder()
            .setSession("Bepar VPN")
            .setMtu(tunMtu)
            .addAddress("10.77.0.1", 32)
            .addAddress("fd42:be:77::1", 128)
            .addRoute("0.0.0.0", 0)
            .addRoute("::", 0)
            .addDnsServer(AppPreferences.dnsHost(this))

        // Split tunneling: apps chosen in Settings skip the VPN. This app itself always stays
        // inside the tunnel, because its own traffic is what verifies a server works.
        AppPreferences.bypassApps(this).forEach { pkg ->
            if (pkg == packageName) return@forEach
            try {
                builder.addDisallowedApplication(pkg)
            } catch (_: Throwable) {
                // The app was uninstalled since it was chosen.
            }
        }

        return builder.establish()
            ?: throw IllegalStateException("Android did not allow the VPN interface to be created.")
    }

    private fun prepareGeoAssets(): File {
        val target = File(filesDir, "xray-assets")
        if (!target.exists() && !target.mkdirs()) {
            throw IllegalStateException("Could not create the Xray data directory.")
        }

        listOf("geoip.dat", "geosite.dat").forEach { filename ->
            val output = File(target, filename)
            if (!output.exists() || output.length() == 0L) {
                assets.open(filename).use { input ->
                    output.outputStream().use { out -> input.copyTo(out) }
                }
            }
        }
        return target
    }

    private fun captureInitialPhysicalNetwork() {
        val manager = connectivityManager
        if (manager != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val active = manager.activeNetwork
            val capabilities = active?.let(manager::getNetworkCapabilities)
            if (active != null && capabilities != null &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) &&
                capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            ) {
                synchronized(physicalNetworks) {
                    physicalNetworks[active] = capabilities.hasCapability(
                        NetworkCapabilities.NET_CAPABILITY_VALIDATED
                    )
                    activePhysicalNetwork = active
                }
            }
        }
        updateVpnUnderlyingNetwork()
    }

    /** Tell Android which physical network carries this VPN, especially across Wi-Fi/cellular handoff. */
    private fun updateVpnUnderlyingNetwork() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return
        runCatching {
            val network = activePhysicalNetwork
            setUnderlyingNetworks(if (network == null) null else arrayOf(network))
        }
    }

    private fun registerNetworkCallback() {
        if (callbackRegistered) return
        val manager = connectivityManager ?: return
        val request = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN)
            .build()

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val capabilities = manager.getNetworkCapabilities(network) ?: return
                updatePhysicalNetwork(network, capabilities)
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                updatePhysicalNetwork(network, networkCapabilities)
            }

            override fun onLost(network: Network) {
                val changed = synchronized(physicalNetworks) {
                    physicalNetworks.remove(network)
                    if (activePhysicalNetwork == network) {
                        activePhysicalNetwork = physicalNetworks.entries
                            .maxByOrNull { it.value }
                            ?.key
                        true
                    } else {
                        false
                    }
                }
                if (changed) updateVpnUnderlyingNetwork()
                if (changed && coreStarted) queueReconnect()
            }
        }

        networkCallback = callback
        try {
            manager.registerNetworkCallback(request, callback)
            callbackRegistered = true
        } catch (_: Throwable) {
            // The tunnel remains usable; monitoring is an optional recovery aid.
        }
    }

    private fun updatePhysicalNetwork(network: Network, capabilities: NetworkCapabilities) {
        if (!capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN) ||
            !capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        ) return

        val validated = capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        val changed = synchronized(physicalNetworks) {
            physicalNetworks[network] = validated
            val current = activePhysicalNetwork
            val currentValidated = current?.let { physicalNetworks[it] } ?: false
            if (current == null || (!currentValidated && validated)) {
                activePhysicalNetwork = network
                true
            } else {
                false
            }
        }
        if (changed) updateVpnUnderlyingNetwork()
        if (changed && coreStarted) queueReconnect()
    }

    private fun queueReconnect() {
        if (!AppPreferences.autoReconnect(this)) return
        if (!reconnectQueued.compareAndSet(false, true)) return
        publishState(VpnPhase.RECONNECTING, "Network changed. Restoring connection…")
        updateNotification("Network changed. Restoring connection…")
        runOnWorker {
            try {
                val config = activeConfigJson ?: return@runOnWorker
                if (!coreStarted) return@runOnWorker
                XrayApi.invoke("stopXray")
                coreStarted = false
                coreStartAttempted = false
                LibXray.resetDNS()
                Thread.sleep(350)
                LibXray.setDNS(socketController, "${activeDns ?: AppPreferences.dnsHost(this)}:53")
                coreStartAttempted = true
                XrayApi.invoke("runXray", JSONObject().put("xrayJson", config))
                coreStarted = true
                val state = XrayApi.invoke("getXrayState").optJSONObject("data")
                    ?: throw IllegalStateException("Xray did not return its runtime state after reconnection.")
                if (!state.optBoolean("running", false)) {
                    throw IllegalStateException("Xray did not restart after the network changed.")
                }
                val probe = TunnelProbe.quickCheck()
                if (!probe.reachable) {
                    throw IllegalStateException("The tunnel restarted, but HTTPS verification failed: ${probe.detail}")
                }
                publishState(VpnPhase.CONNECTED, "VPN reconnected • HTTPS verified")
                updateNotification("Connected • Bepar VPN")
            } catch (error: Throwable) {
                releaseCoreAndTun()
                unregisterNetworkCallbackSafely()
                AppPreferences.endSession(this)
                publishState(
                    VpnPhase.ERROR,
                    error.message?.take(180) ?: "Could not reconnect after the network changed."
                )
                updateNotification("Reconnect required")
                stopForeground(true)
                stopSelf()
            } finally {
                reconnectQueued.set(false)
            }
        }
    }

    private fun stopCoreOnly() {
        if (coreStartAttempted || coreStarted) {
            try {
                XrayApi.invoke("stopXray")
            } catch (_: Throwable) {
                // Continue releasing DNS state even if Core shutdown reports an error.
            }
        }
        coreStarted = false
        coreStartAttempted = false
        try {
            LibXray.resetDNS()
        } catch (_: Throwable) {
            // DNS resolver may not have been installed yet.
        }
    }

    private fun releaseCoreAndTun() {
        stopTrafficSampler()
        stopCoreOnly()
        activeMetricsPort = -1
        activeConfigJson = null
        try {
            tunDescriptor?.close()
        } catch (_: Throwable) {
            // Descriptor may already be closed by Android.
        }
        tunDescriptor = null
        runCatching { setUnderlyingNetworks(null) }
    }

    private fun disconnectInternal(stopService: Boolean) {
        requestedNodeId = null
        AppPreferences.endSession(this)
        releaseCoreAndTun()
        unregisterNetworkCallbackSafely()
        publishState(VpnPhase.DISCONNECTED, "VPN disconnected")
        stopForeground(true)
        if (stopService) stopSelf()
    }

    private fun unregisterNetworkCallbackSafely() {
        val manager = connectivityManager
        val callback = networkCallback
        if (callbackRegistered && manager != null && callback != null) {
            try {
                manager.unregisterNetworkCallback(callback)
            } catch (_: Throwable) {
                // No action needed if Android already unregistered the callback.
            }
        }
        callbackRegistered = false
        networkCallback = null
        synchronized(physicalNetworks) {
            physicalNetworks.clear()
            activePhysicalNetwork = null
        }
    }

    private fun publishState(phase: VpnPhase, message: String) {
        val active = phase == VpnPhase.CONNECTED
        val connecting = phase == VpnPhase.CONNECTING || phase == VpnPhase.RECONNECTING
        AppPreferences.setVpnStatus(this, active, connecting)
        ConnectionState.update(phase, message)
        BeparVpnTileService.requestRefresh(this)
    }

    private fun startAsForeground(message: String) {
        val notification = buildNotification(message)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SYSTEM_EXEMPTED
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(message: String) {
        val manager = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(message))
    }

    private fun buildNotification(message: String): Notification {
        val openApp = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val disconnect = PendingIntent.getService(
            this,
            2,
            Intent(this, BeparVpnService::class.java).setAction(ACTION_DISCONNECT),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_qs_bepar_vpn)
            .setContentTitle("Bepar VPN")
            .setContentText(message)
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Disconnect", disconnect)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "VPN connection status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Ongoing notification while the VPN tunnel is active."
            }
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
                .createNotificationChannel(channel)
        }
    }
}
