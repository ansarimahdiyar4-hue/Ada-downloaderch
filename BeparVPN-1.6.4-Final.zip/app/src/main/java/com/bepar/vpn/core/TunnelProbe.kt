package com.bepar.vpn.core

import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * Checks HTTPS reachability and performs a bounded 1 MB download sample while
 * the Android VPN is active. It sends no user data and does not run an upload test.
 */
data class TunnelProbeResult(
    val reachable: Boolean,
    val latencyMillis: Long?,
    val endpoint: String?,
    val detail: String,
    val downloadMbps: Double? = null
)

object TunnelProbe {
    private val endpoints = listOf(
        "https://cp.cloudflare.com/generate_204",
        "https://connectivitycheck.gstatic.com/generate_204",
        "https://www.google.com/generate_204",
        "https://www.cloudflare.com/cdn-cgi/trace",
        "https://api.github.com/zen"
    )

    /** Fast pass/fail check used by Auto mode to reject servers that connect but carry no traffic. */
    fun quickCheck(): TunnelProbeResult {
        var lastError = "No internet through this server."
        for (endpoint in endpoints) {
            var connection: HttpsURLConnection? = null
            val startedAt = System.nanoTime()
            try {
                connection = (URL(endpoint).openConnection() as HttpsURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 3_000
                    readTimeout = 3_000
                    instanceFollowRedirects = false
                    useCaches = false
                    setRequestProperty("Cache-Control", "no-cache")
                    setRequestProperty("User-Agent", "BeparVPN-Android/1.6.4")
                }
                val code = connection.responseCode
                // A successful HTTPS 2xx proves end-to-end TLS traffic through the TUN.
                // Some valid endpoints return 200 rather than 204; do not reject those.
                if (code in 200..299) {
                    return TunnelProbeResult(
                        true, (System.nanoTime() - startedAt) / 1_000_000L,
                        URL(endpoint).host, "Verified"
                    )
                }
                lastError = "Connectivity endpoint returned HTTP $code (expected 204)."
            } catch (error: Exception) {
                lastError = error.message?.take(80) ?: "timeout"
            } finally {
                connection?.disconnect()
            }
        }
        return TunnelProbeResult(false, null, null, lastError)
    }

    fun run(): TunnelProbeResult {
        var lastError = "Could not reach any connectivity-check endpoint."
        for (endpoint in endpoints) {
            var connection: HttpsURLConnection? = null
            val startedAt = System.nanoTime()
            try {
                connection = (URL(endpoint).openConnection() as HttpsURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 5_000
                    readTimeout = 5_000
                    instanceFollowRedirects = false
                    useCaches = false
                    setRequestProperty("Cache-Control", "no-cache")
                    setRequestProperty("User-Agent", "BeparVPN-Android/1.6.4")
                }
                val code = connection.responseCode
                val elapsed = (System.nanoTime() - startedAt) / 1_000_000L
                if (code in 200..299) {
                    val downloadMbps = measureDownloadSampleMbps()
                    return TunnelProbeResult(
                        reachable = true,
                        latencyMillis = elapsed,
                        endpoint = URL(endpoint).host,
                        detail = "HTTPS connectivity through the VPN tunnel was verified.",
                        downloadMbps = downloadMbps
                    )
                }
                lastError = "Connectivity-check endpoint returned HTTP $code"
            } catch (error: Exception) {
                lastError = error.message?.take(120) ?: "The network connectivity test failed."
            } finally {
                connection?.disconnect()
            }
        }
        return TunnelProbeResult(
            reachable = false,
            latencyMillis = null,
            endpoint = null,
            detail = lastError
        )
    }

    /** Downloads at most 1 MB through the current Android VPN route; not an unlimited speed test. */
    private fun measureDownloadSampleMbps(): Double? {
        var connection: HttpsURLConnection? = null
        return try {
            val active = (URL("https://speed.cloudflare.com/__down?bytes=1000000").openConnection() as HttpsURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 7_000
                readTimeout = 12_000
                instanceFollowRedirects = false
                useCaches = false
                setRequestProperty("Cache-Control", "no-cache")
                setRequestProperty("User-Agent", "BeparVPN-Android/1.6.4")
            }
            connection = active
            if (active.responseCode !in 200..299) return null
            val started = System.nanoTime()
            var received = 0L
            active.inputStream.use { input ->
                val buffer = ByteArray(16 * 1024)
                while (received < 1_000_000L) {
                    val count = input.read(buffer, 0, minOf(buffer.size.toLong(), 1_000_000L - received).toInt())
                    if (count < 0) break
                    received += count
                }
            }
            val elapsedNanos = (System.nanoTime() - started).coerceAtLeast(1L)
            if (received < 64 * 1024L) return null
            (received.toDouble() * 8_000.0) / elapsedNanos.toDouble()
        } catch (_: Exception) {
            null
        } finally {
            connection?.disconnect()
        }
    }
}
