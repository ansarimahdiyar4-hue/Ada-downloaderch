# Bepar VPN Android 1.3.0

## UI refresh
- Reworked the home screen around a large animated connect control.
- Added a distinct connected check state and a simpler status hierarchy.
- Updated the dark navy / electric-blue visual system and compact cards.
- Updated the bottom navigation to Home, Servers, Logs, and Settings.
- Simplified labels and removed long helper paragraphs from the main screens.

## App behavior
- Added a local connection activity history with a clear action.
- Kept VPN permission as the required connection gate; notification permission is optional and no longer blocks connection.
- Kept profile import, encrypted local profile storage, DNS selection, automatic network recovery, and live profile switching.
- Updated the in-app version to 1.3.0.

## Validation
- Project structure, XML resources, ZIP integrity, and source-level checks are run before delivery.
- A full Android Gradle build, emulator run, and real-server VPN test still require GitHub Actions and a device with a valid server profile.
