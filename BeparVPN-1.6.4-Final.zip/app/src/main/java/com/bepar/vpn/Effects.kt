package com.bepar.vpn

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/*
 * Visual effects layer for Bepar VPN.
 * Everything here is pure Compose Canvas (no extra dependencies) and is drawn in the
 * draw phase only, so continuous animations never trigger recomposition or layout.
 */

private class Star(val x: Float, val y: Float, val depth: Float, val phase: Float)

/** Full-screen animated backdrop: parallax star field + drifting aurora orbs that take the VPN state colour. */
@Composable
internal fun AuroraBackground(tint: Color, modifier: Modifier = Modifier) {
    val color by animateColorAsState(tint, tween(1100), label = "aurora-tint")
    val infinite = rememberInfiniteTransition(label = "aurora")
    val drift by infinite.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(46000, easing = LinearEasing)), label = "aurora-drift"
    )
    val twinkle by infinite.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(5200, easing = LinearEasing)), label = "aurora-twinkle"
    )
    val stars = remember {
        val rnd = Random(77)
        List(54) { Star(rnd.nextFloat(), rnd.nextFloat(), .25f + rnd.nextFloat() * .75f, rnd.nextFloat() * 6.28f) }
    }
    Canvas(modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Three large soft orbs moving on slow Lissajous paths.
        val orbs = listOf(
            Triple(.82f + .10f * sin(drift), .10f + .06f * cos(drift * 1.0f), .85f),
            Triple(.10f + .08f * cos(drift * 2f), .62f + .08f * sin(drift * 1f), .70f),
            Triple(.60f + .12f * sin(drift * 3f), .98f + .03f * cos(drift * 2f), .62f)
        )
        orbs.forEachIndexed { i, (ox, oy, rr) ->
            val radius = w * rr
            val c = Offset(w * ox, h * oy)
            drawCircle(
                Brush.radialGradient(
                    listOf(color.copy(alpha = if (i == 1) .085f else .12f), Color.Transparent),
                    center = c, radius = radius
                ),
                radius = radius, center = c
            )
        }

        // Parallax stars: nearer stars (depth ~1) drift more and are brighter.
        stars.forEach { s ->
            val dx = sin(drift * 2f * s.depth + s.phase) * 6.dp.toPx() * s.depth
            val dy = cos(drift * 3f * s.depth + s.phase) * 4.dp.toPx() * s.depth
            val tw = .5f + .5f * sin(twinkle + s.phase)
            val a = (.06f + .30f * tw) * s.depth
            drawCircle(
                Color.White.copy(alpha = a),
                radius = (.5f + 1.1f * s.depth).dp.toPx(),
                center = Offset(s.x * w + dx, s.y * h + dy)
            )
        }
    }
}

/**
 * Two tilted orbit rings with data-packet satellites circling the power button.
 * [front] = false draws the half behind the button, true the half in front, which is what
 * makes the rings read as real 3D. Speed eases between idle / connecting / connected.
 */
@Composable
internal fun OrbitSatellites(
    tint: Color,
    active: Boolean,
    busy: Boolean,
    front: Boolean,
    modifier: Modifier = Modifier
) {
    val speedTarget = when {
        busy -> 150f
        active -> 52f
        else -> 22f
    }
    val speed by animateFloatAsState(speedTarget, tween(700), label = "orbit-speed")
    val energy by animateFloatAsState(if (busy) 1f else if (active) .75f else .4f, tween(700), label = "orbit-energy")
    val speedRef = rememberUpdatedState(speed)
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) {
                    angle = (angle + speedRef.value * (now - last) / 1_000_000_000f) % 360f
                }
                last = now
            }
        }
    }

    Canvas(modifier) {
        val c = Offset(size.width / 2f, size.height / 2f)
        val a = size.minDimension / 2f * .96f
        val b = a * .27f

        // (tilt of the ring plane, speed multiplier, satellites on the ring)
        val rings = listOf(
            Triple(-18f, 1.0f, 3),
            Triple(24f, -.7f, 2)
        )
        rings.forEach { (tilt, mult, count) ->
            rotate(tilt, c) {
                if (!front) {
                    // The whole ring outline is drawn once, behind the button.
                    val path = Path()
                    for (step in 0..96) {
                        val t = step / 96f * 2f * PI.toFloat()
                        val x = c.x + a * cos(t)
                        val y = c.y + b * sin(t)
                        if (step == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }
                    drawPath(path, tint.copy(alpha = .13f + .10f * energy), style = Stroke(1.dp.toPx()))
                }
                repeat(count) { i ->
                    val base = Math.toRadians((angle * mult + i * 360f / count).toDouble())
                    val depth = sin(base).toFloat() // >0 = in front of the button
                    if ((depth > 0f) == front) {
                        // Short fading trail behind each satellite.
                        for (k in 0..7) {
                            val tb = base - k * 0.085 * (if (mult < 0) -1 else 1)
                            val tx = c.x + a * cos(tb).toFloat()
                            val ty = c.y + b * sin(tb).toFloat()
                            val fade = 1f - k / 8f
                            drawCircle(
                                tint.copy(alpha = (.55f * fade * energy)),
                                radius = (1.2f + 2.4f * fade).dp.toPx() * (.75f + .25f * (depth + 1f) / 2f),
                                center = Offset(tx, ty)
                            )
                        }
                        val sx = c.x + a * cos(base).toFloat()
                        val sy = c.y + b * sin(base).toFloat()
                        val scale = .7f + .4f * (depth + 1f) / 2f
                        drawCircle(
                            Brush.radialGradient(
                                listOf(tint.copy(alpha = .55f), Color.Transparent),
                                center = Offset(sx, sy), radius = 11.dp.toPx() * scale
                            ),
                            radius = 11.dp.toPx() * scale, center = Offset(sx, sy)
                        )
                        drawCircle(Color.White.copy(alpha = .95f), 2.6f.dp.toPx() * scale, Offset(sx, sy))
                    }
                }
            }
        }
    }
}

/** Layered flowing sine waves, drawn along the bottom of the hero card while connected. */
@Composable
internal fun TrafficWave(tint: Color, active: Boolean, busy: Boolean, modifier: Modifier = Modifier) {
    val amp by animateFloatAsState(if (active) 1f else if (busy) .55f else .22f, tween(900), label = "wave-amp")
    val infinite = rememberInfiniteTransition(label = "wave")
    val phase by infinite.animateFloat(
        0f, (2 * PI).toFloat(),
        infiniteRepeatable(tween(3800, easing = LinearEasing)), label = "wave-phase"
    )
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val layers = listOf(
            Triple(1.0f, .30f, 1.0f),
            Triple(1.6f, .20f, -1.4f),
            Triple(2.3f, .12f, 2.0f)
        )
        layers.forEachIndexed { idx, (freq, alpha, dir) ->
            val path = Path()
            val steps = 48
            for (s in 0..steps) {
                val x = w * s / steps
                val u = s / steps.toFloat()
                // Edges taper to zero so the wave melts into the card.
                val envelope = sin(u * PI.toFloat())
                val y = h * .62f + sin(u * 2f * PI.toFloat() * freq + phase * dir + idx) *
                    h * .20f * amp * envelope
                if (s == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            val fill = Path().apply {
                addPath(path)
                lineTo(w, h)
                lineTo(0f, h)
                close()
            }
            drawPath(
                fill,
                Brush.verticalGradient(
                    listOf(tint.copy(alpha = alpha * .55f * (.4f + .6f * amp)), Color.Transparent),
                    startY = h * .35f, endY = h
                )
            )
            drawPath(path, tint.copy(alpha = alpha * (.4f + .6f * amp)), style = Stroke(1.2.dp.toPx()))
        }
    }
}

/** A light beam that periodically sweeps along the card border, giving a glassy "live" edge. */
internal fun Modifier.glowBorder(tint: Color, corner: Dp, periodMillis: Int = 4200): Modifier = composed {
    val infinite = rememberInfiniteTransition(label = "glow-border")
    val t by infinite.animateFloat(
        -.4f, 1.4f,
        infiniteRepeatable(tween(periodMillis, easing = LinearEasing)), label = "glow-border-t"
    )
    drawWithContent {
        drawContent()
        val w = size.width
        val h = size.height
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Color.Transparent, tint.copy(alpha = .75f), Color.Transparent),
                start = Offset(w * (t - .25f), 0f),
                end = Offset(w * (t + .25f), h)
            ),
            cornerRadius = CornerRadius(corner.toPx()),
            style = Stroke(1.6.dp.toPx())
        )
    }
}

/** Staggered rise/fade/scale-in used by the cards on each screen. */
internal fun Modifier.entrance(index: Int): Modifier = composed {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index * 75L)
        progress.animateTo(1f, tween(560, easing = FastOutSlowInEasing))
    }
    graphicsLayer {
        val p = progress.value
        alpha = p
        translationY = (1f - p) * 36.dp.toPx()
        val s = .95f + .05f * p
        scaleX = s
        scaleY = s
    }
}
