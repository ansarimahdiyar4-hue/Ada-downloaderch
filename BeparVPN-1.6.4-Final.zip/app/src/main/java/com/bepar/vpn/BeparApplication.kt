package com.bepar.vpn

import android.app.Application
import com.bepar.vpn.data.AutoFeedRefreshScheduler
import com.bepar.vpn.data.RemoteConfigFeedRepository

class BeparApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AutoFeedRefreshScheduler.schedule(this)
        if (RemoteConfigFeedRepository.lastSuccessfulRefresh(this) == 0L ||
            RemoteConfigFeedRepository.needsPolicyMigration(this)
        ) {
            AutoFeedRefreshScheduler.enqueueInitialRefresh(this)
        }
    }
}
